package tw.tteia.api;

import android.app.Activity;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;

import org.json.JSONObject;

import tw.tteia.R;
import tw.tteia.WebActivity;
import tw.tteia.jsonConnect;

import static tw.tteia.ConstantUtil.CONFIG_PATH;
import static tw.tteia.ConstantUtil.SERVER_NAME_WEB8;

public class api_user_register extends Thread
{
	private String xid, gcm_id, phoneNumber;
	private jsonConnect json_func = new jsonConnect();
	private Activity activity;
	public api_user_register(Activity activity, String xid, String phoneNumber, String gcm_id)
	{
		this.activity = activity;
		this.xid = xid;
		this.phoneNumber = phoneNumber;
		this.gcm_id = gcm_id;
	}
	@Override
	public void run()
	{
		try
		{
			String jsonURL = SERVER_NAME_WEB8 + "user/api.php?xid=" + xid + "&gcm_id=" + gcm_id + "&phone=" + phoneNumber;
			String requestJSON = json_func.getJson(jsonURL);
			JSONObject obj = new JSONObject(requestJSON);
			String status = obj.getString("status");
			if (status.equals("1"))
			{
				final int user_id = Integer.parseInt(obj.getString("user_id"));
				final String username = obj.getString("username");
				final int r_is_login = Integer.parseInt(obj.getString("type_id"));
				SharedPreferences sp = activity.getSharedPreferences(CONFIG_PATH, 0);
				SharedPreferences.Editor speditor = sp.edit();
				speditor.putInt("is_login", r_is_login);
				speditor.putInt("user_id", user_id);
				speditor.putString("username", username);
				speditor.commit();
				activity.startActivity(new Intent(activity, WebActivity.class));
				activity.finish();
			} else
				alert_error();
		} catch (Exception e)
		{
			alert_error();
		}
		super.run();
	}

	private void alert_error()
	{
		Builder MyAlertDialog = new Builder(activity);
		MyAlertDialog.setTitle("無法取得網路連線");
		MyAlertDialog.setIcon(R.mipmap.icon_80x80);
		MyAlertDialog.setMessage("部份功能必需在網路連線狀態下執行，請確定您是否已連線上網！").setCancelable(false)
				.setPositiveButton("確定", new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int id)
					{
						dialog.cancel();
						activity.finish();
					}
				});
	}
}