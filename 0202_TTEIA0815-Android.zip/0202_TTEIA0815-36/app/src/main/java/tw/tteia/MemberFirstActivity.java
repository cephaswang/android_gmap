package tw.tteia;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static tw.tteia.ConstantUtil.SERVER_NAME_WEB8;

public class MemberFirstActivity extends BaseActivity
{
	private Context context = MemberFirstActivity.this;
	private ListView data_listview;
	private List<Map<String, String>> datalistmap = new ArrayList<Map<String, String>>();
	public Thread imw_thread;
	private Handler mHandler = new Handler();
	public Integer[] mdownMenuIds = { R.mipmap.user_search_icon };
	public String[] mdownMenuNames = { "搜尋"};

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_null);
		setContentView(R.layout.activity_member_first);
		imw.nav_init();
		createdownmenu();
		if (isInternetPresent == 0)
			Toast.makeText(context, "無法連接到網路，請檢查您的連線設定！", Toast.LENGTH_LONG).show();
		else {
			imw_thread = new api_getnews();
			imw_thread.start();
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		switch (keyCode)
		{
			case KeyEvent.KEYCODE_BACK:
				finish();
				return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	private class api_getnews extends Thread
	{
		@Override
		public void run()
		{
			String jsonURL = SERVER_NAME_WEB8 + "index.php?mode=get_area";
			jsonConnect json_func = new jsonConnect();
			try
			{
				String requestJSON = json_func.getJson(jsonURL);
				try
				{
					JSONObject obj = new JSONObject(requestJSON);
					String status = obj.getString("status");
					if (status.equals("0"))
					{
						mHandler.post(new Runnable()
						{
							public void run()
							{
								Toast.makeText(context, "抱歉，目前尚無會員資料", Toast.LENGTH_LONG).show();
							}
						});
					}
					String news_data = obj.getString("outputObject");
					JSONArray DataArray = new JSONArray(news_data);
					for (int i = 0; i < DataArray.length(); i++)
					{
						HashMap<String, String> newsData = new HashMap<String, String>();
						newsData.put("id", DataArray.getJSONObject(i).getString("id"));
						newsData.put("name", DataArray.getJSONObject(i).getString("name"));
						datalistmap.add(newsData);
					}
				} catch (Exception e) {}
			} catch (Exception e) {}
			mHandler.post(new Runnable()
			{
				public void run()
				{
					datalist_init(datalistmap);
				}
			});
			super.run();
		}
	}

	private void datalist_init(final List<Map<String, String>> listmap)
	{
		TextView inone = (TextView) findViewById(R.id.inonetxt);
		inone.setVisibility(View.GONE);
		data_listview = (ListView) findViewById(R.id.news_data);
		data_listview.setAdapter(new BaseAdapter()
		{
			@Override
			public View getView(int position, View convertView, ViewGroup parent)
			{
				// 新建LinearLayout
				View view = getLayoutInflater().inflate(R.layout.member_first_listview, null);
				TextView name = (TextView) view.findViewById(R.id.name);
				name.setText(listmap.get(position).get("name"));
				return view;
			}

			@Override
			public long getItemId(int position)
			{
				return Integer.parseInt(listmap.get(position).get("id"));
			}

			@Override
			public Object getItem(int position)
			{
				return listmap.get(position);
			}

			@Override
			public int getCount()
			{
				return listmap.size();
			}
		});
		data_listview.setOnItemClickListener(new OnItemClickListener()
		{
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id)
			{
				try
				{
					speditor.putString("first_id", String.valueOf(id));
					speditor.putString("first_name", listmap.get(position).get("name"));
					speditor.commit();
					Intent intent = new Intent();
					intent.setClass(maint, MemberSecondActivity.class);
					startActivity(intent);
				} catch (Exception e) {}
			}
		});
		if (listmap.size() == 0)
			Toast.makeText(context, "抱歉，目前尚無會員資料", Toast.LENGTH_LONG).show();
	}

	private void createdownmenu() {
		GridView diingImages = (GridView) findViewById(R.id.bottom_tool);
		diingImages.setAdapter(new ImageAdapter(maint));
		diingImages.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			public void onItemClick(AdapterView parent, View v, int position, long id) {
				// Get the data location of the image
				switch (position) {
					case 0:// 搜尋
						Intent imenu0 = new Intent(maint, SearchActivity.class);
						imenu0.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
						startActivity(imenu0);
						break;
				}
			}
		});
	}

	private class ImageAdapter extends BaseAdapter
	{
		private Context context;
		public ImageAdapter(Context localContext)
		{
			context = localContext;
		}
		public int getCount()
		{
			return mdownMenuIds.length;
		}
		public Object getItem(int position)
		{
			return position;
		}
		public long getItemId(int position)
		{
			return position;
		}
		public View getView(int position, View convertView, ViewGroup parent)
		{
			LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View grid;
			if (convertView == null)
			{
				grid = new View(context);
				grid = inflater.inflate(R.layout.downlist, null);
				ImageView picturesView = (ImageView) grid.findViewById(R.id.dimenuimage);
				TextView textView = (TextView) grid.findViewById(R.id.dgrid_text);
				String finame = mdownMenuNames[position];
				BitmapFactory.Options option = new BitmapFactory.Options();
				option.inSampleSize = 1;
				Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), mdownMenuIds[position]);
				picturesView.setImageBitmap(bitmap);
				textView.setText(finame);
			} else
				grid = (View) convertView;
			return grid;
		}
	}
}
