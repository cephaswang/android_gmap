package tw.tteia;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import org.apache.http.NameValuePair;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static tw.tteia.ConstantUtil.SERVER_NAME_WEB8;

public class UserLoginActivity extends BaseActivity implements OnClickListener
{
	private String username,password;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_user_login);
		imw.nav_init();
		Button btn_login = (Button) findViewById(R.id.btn_login);
		btn_login.setOnClickListener(this);
		if (isInternetPresent == 0)
			alert_error();
	}

	private class changeUser extends AsyncTask<HashMap<String, String>, Void, HashMap<String, String>>
	{
		@Override
		protected HashMap<String, String> doInBackground(HashMap<String, String>... params)
		{
			String jsonURL = SERVER_NAME_WEB8 + "index.php?mode=login&username="+ username +"&password="+password +"&xid=" + xid + "&gcm_id=" + sp.getString("gcm_id","");
			jsonConnect json_func = new jsonConnect();
			List<NameValuePair> postParams = new ArrayList<NameValuePair>();
			String requestJSON = json_func.getjson(jsonURL, postParams);
			HashMap<String, String> dataMap = new HashMap<String, String>();
			try
			{
				JSONObject obj = new JSONObject(requestJSON);
				String status = obj.getString("status");
				dataMap.put("status", status);
				String message = obj.getString("errorMessage");
				dataMap.put("errorMessage", message);
				JSONObject user_Data = new JSONObject( obj.getString("outputObject"));
				if (status.equals("1"))
				{
					// 會員ID
					String id = user_Data.getString("id");
					dataMap.put("id", id);
					// 會員類別
					String type_id = user_Data.getString("type_id");
					dataMap.put("type_id", type_id);
					// 會員帳號
					String username = user_Data.getString("username");
					dataMap.put("username", username);
				}
			} catch (Exception e)
			{
				return null;
			}
			return dataMap;
		}

		@Override
		protected void onPostExecute(HashMap<String, String> result)
		{
			if (result.get("status").equals("0"))
				Toast.makeText(maint, "登入失敗，錯誤訊息(" + result.get("errorMessage") + ")", Toast.LENGTH_SHORT).show();
			else
			{
				Toast.makeText(maint, "登入成功", Toast.LENGTH_SHORT).show();
				speditor.putInt("id", Integer.parseInt(result.get("id")));
				speditor.putInt("is_login", Integer.parseInt(result.get("type_id")));
				speditor.putString("username", result.get("username"));
				speditor.putString("password",password);
				speditor.commit();
				imw.backMain();
			}
			super.onPostExecute(result);
		}
	}

	private void alert_error()
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("連線錯誤");
		builder.setMessage("連線發生錯誤，請確認您的網路狀態。").setCancelable(false)
				.setPositiveButton("確定", new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int id)
					{
						Intent reload = new Intent();
						reload.setClass(maint, getClass());
						startActivity(reload);
						finish();
						dialog.cancel();
					}
				}).setNegativeButton("離開", new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int id)
					{
						Intent backhome = new Intent();
						backhome.setClass(maint, MainActivity.class);
						startActivity(backhome);
						finish();
						dialog.cancel();
					}
				});
		AlertDialog alert = builder.create();
		alert.show();
	}

	@Override
	public void onClick(View v)
	{
		switch (v.getId())
		{
		case R.id.btn_login:
			EditText edit_username = (EditText) findViewById(R.id.username);
			username = edit_username.getText().toString();
			EditText edit_password = (EditText) findViewById(R.id.password);
			password = edit_password.getText().toString();
			if (form_check(username, password) == false)
			{
				HashMap<String, String> formmap = new HashMap<String, String>();
				formmap.put("username", username);
				formmap.put("password", password);
				formmap.put("id", sp.getInt("id", 0) + "");
				formmap.put("xid", sp.getString("xid", ""));
				AsyncTask<HashMap<String, String>, Void, HashMap<String, String>> changeTask = new changeUser();
				changeTask.execute(formmap);
			}
			break;
		}
	}

	private Boolean form_check(String username, String password)
	{
		Boolean isError = false;
		if (username.equals(""))
		{
			isError = true;
			Toast.makeText(maint, "未填寫帳號", Toast.LENGTH_LONG).show();
		}
		if (password.equals(""))
		{
			isError = true;
			Toast.makeText(maint, "未填寫密碼", Toast.LENGTH_LONG).show();
		}
		return isError;
	}
}