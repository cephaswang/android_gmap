package tw.tteia;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Vector;

public class LiteDatabase extends SQLiteOpenHelper
{
	static final int version = 1;
	private int count = 0;
	private int cursor = 0;
	public Hashtable<String, Vector<?>> table = new Hashtable();
	// HashMap<Integer, HashMap> meMap=new HashMap<Integer, HashMap>();
	private HashMap<Integer, HashMap<String, String>> meMap = new HashMap<Integer, HashMap<String, String>>();
	private String[] tablename =
	{ "imw_address", "imw_product_link", "imw_product_type" };
	public LiteDatabase(Context paramContext, String paramString)
	{
		super(paramContext, paramString, null, version); 
	}
	private void InsertData(SQLiteDatabase paramSQLiteDatabase)
	{
		addDefault_other_set(this.tablename[0], paramSQLiteDatabase);
	}

	private void addDefault_other_set(String paramString, SQLiteDatabase paramSQLiteDatabase)
	{

		// 設定預設資料
		/*
		 * if(paramString.equals("imw_imenu_type")){ ArrayList localArrayList =
		 * new ArrayList(); localArrayList.add("insert into " + paramString +
		 * " Values(NULL,'hot','最後歡迎排行');"); localArrayList.add("insert into " +
		 * paramString + " Values(NULL,'all','全部餐點');");
		 * localArrayList.add("insert into " + paramString +
		 * " Values(NULL,'3','前菜');"); localArrayList.add("insert into " +
		 * paramString + " Values(NULL,'4','主菜');");
		 * localArrayList.add("insert into " + paramString +
		 * " Values(NULL,'5','甜點');"); localArrayList.add("insert into " +
		 * paramString + " Values(NULL,'6','飲料');"); mutiexec(localArrayList,
		 * paramSQLiteDatabase);
		 * 
		 * 
		 * }
		 */

	}

	private void mutiexec(ArrayList<String> paramArrayList, SQLiteDatabase paramSQLiteDatabase)
	{
		for (int i = 0;; i++)
		{
			if (i >= paramArrayList.size())
				return;
			paramSQLiteDatabase.execSQL(((String) paramArrayList.get(i)).toString());
		}
	}

	public HashMap getvalue()
	{
		return meMap;
	}

	public String Field(String paramString)
	{
		Vector localVector = (Vector) this.table.get(paramString);
		if (localVector == null)
			return "";
		try
		{
			String str = (String) localVector.elementAt(this.cursor);
			return str;
		} catch (Exception localException)
		{
			localException.printStackTrace();
		}
		return "";
	}

	public String Field_L(String paramString1, String paramString2)
	{
		Vector localVector = (Vector) this.table.get(paramString1);
		if (localVector == null)
			return "";
		try
		{
			String str = new String(
					(byte[]) localVector.elementAt(this.cursor), paramString2);
			return str;
		} catch (Exception localException)
		{
		}
		return "";
	}

	public boolean bof()
	{
		return (this.cursor < 0) || (this.count == 0);
	}

	public void close()
	{
		this.table.clear();
		this.table = null;
	}

	public boolean eof()
	{
		return this.cursor > -1 + recordCount();
	}

	public int execute(String paramString)
	{
		SQLiteDatabase localSQLiteDatabase = getWritableDatabase();

		localSQLiteDatabase.execSQL(paramString);
		localSQLiteDatabase.close();
		return 0;
	}

	public int cleardata(String paramString)
	{
		SQLiteDatabase localSQLiteDatabase = getWritableDatabase();
		String deleteSQL = "DELETE FROM " + paramString;
		localSQLiteDatabase.execSQL(deleteSQL);
		// localSQLiteDatabase.delete(paramString, null, null);
		localSQLiteDatabase.close();
		return 0;
	}

	public void move(int paramInt)
	{
		this.cursor = (paramInt - 1);
	}

	public void moveEnd()
	{
		this.cursor = (-1 + recordCount());
	}

	public void moveFirst()
	{
		this.cursor = 0;
	}

	public void moveNext()
	{
		this.cursor = (1 + this.cursor);
	}

	public void movePrevious()
	{
		this.cursor = (-1 + this.cursor);
	}

	public void onCreate(SQLiteDatabase paramSQLiteDatabase)
	{
		String createName = "";
		// 商品
		String str1 = this.tablename[0];
		paramSQLiteDatabase.execSQL("CREATE TABLE if not exists " + str1 + " ("
				+ " `_id` integer primary key autoincrement,"
				+ " `id` text,"
				+ " `company_name` text,"
				+ " `address` text,"
				+ " `tel_1` text,"
				+ " `fax` text,"
				+ " `lat` text,"
				+ " `lng` text" + ")");

		addDefault_other_set(str1, paramSQLiteDatabase);

		// 商品連結
		String str2 = this.tablename[1];
		paramSQLiteDatabase.execSQL("CREATE TABLE if not exists " + str2 + " ("
				+ " `_id` integer primary key autoincrement,"
				+ " `id` int(10) NOT NULL ,"
				+ " `sequence` int(10) NOT NULL DEFAULT '0',"
				+ " `product_id` int(10) NOT NULL DEFAULT '0',"
				+ " `product_type_id` int(10) NOT NULL DEFAULT '0',"
				+ " `status` varchar(1) NOT NULL DEFAULT '0',"
				+ " `is_delete` varchar(1) NOT NULL DEFAULT '0'" + ")");
		addDefault_other_set(str2, paramSQLiteDatabase);
		// 商品型錄
		String str3 = this.tablename[2];
		paramSQLiteDatabase.execSQL("CREATE TABLE if not exists " + str3 + " ("
				+" `_id` integer primary key autoincrement,"
				+" `id` int(10) NOT NULL,"
				+" `sequence` int(10) DEFAULT '0',"
				+" `parent_id` int(10) DEFAULT '0',"
				+" `name` varchar(255) DEFAULT NULL,"
				+" `meta_title` varchar(255) DEFAULT NULL,"
				+" `meta_description` text,"
				+" `is_href_url` varchar(255) DEFAULT NULL,"
				+" `is_blank` varchar(1) DEFAULT '0',"
				+" `is_href` varchar(1) DEFAULT '0',"
				+" `style` varchar(255) DEFAULT NULL,"
				+" `content` text,"
				+" `content_plain` text,"
				+" `path_id_list` varchar(255) DEFAULT NULL,"
				+" `path_name_list` varchar(255) DEFAULT NULL,"
				+" `cart` varchar(10) DEFAULT NULL,"
				+" `is_full` varchar(1) DEFAULT '0',"
				+" `file_list` longtext,"
				+" `status` varchar(1) DEFAULT NULL,"
				+" `time_add` datetime DEFAULT NULL,"
				+" `time_edit` datetime DEFAULT NULL,"
				+" `statistic_qty` int(10) DEFAULT '0',"
				+" `owner_id` varchar(20) DEFAULT '0',"
				+" `owner_type_id` varchar(20) DEFAULT '0'" + ")");
		addDefault_other_set(str3, paramSQLiteDatabase);
	}

	@Override
	public void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1,
			int paramInt2)
	{
		if (paramInt1 < paramInt2)
			;
		for (int i = 0;; i++)
		{
			if (i >= this.tablename.length)
			{
				onCreate(paramSQLiteDatabase);
				return;
			}
			paramSQLiteDatabase.execSQL("Drop table if exists " + this.tablename[i] + ";");
		}
	}

	public void opendata(String paramString)
	{
		this.table.clear();
		int iColumn = 0;
		SQLiteDatabase localSQLiteDatabase = getReadableDatabase();
		Cursor localCursor = localSQLiteDatabase.rawQuery(paramString, null);
		String[] colNames = null;
		iColumn = localCursor.getColumnCount();
		String[] arrayOfString = new String[iColumn + 1];
		int m = 0;
		if (iColumn > 0)
		{
			for (int i = 0; i < iColumn; i++)
			{
				arrayOfString[i] = localCursor.getColumnName(i);
				this.table.put(arrayOfString[i], new Vector());
				// this.meMap.put(i, new HashMap<String, String>());
			}
		}

		if (this.meMap.size() > 0)
		{
			this.meMap.clear();
		}
		if (localCursor.getCount() > 0)
		{
			localCursor.moveToFirst();
			do
			{
				// this.table.put(arrayOfString[j], new Vector());

				// colNames=localCursor.getColumnNames();
				// i++;
				// arrayOfString[j] = localCursor.getColumnName(j);

				this.meMap.put(m, new HashMap<String, String>());
				// meMap.get(m).put("_id", localCursor.getString(0));
				for (int j = 0; j < iColumn; j++)
				{

					meMap.get(m)
							.put(arrayOfString[j], localCursor.getString(j));

				}

				m++;

			} while (localCursor.moveToNext());
		} else
			meMap.clear();

		localCursor.close();
		localSQLiteDatabase.close();
	}
	/*
	 * @SuppressWarnings("unused") public boolean open(String paramString) {
	 * this.table.clear(); while (true) { int i; int k; int m; try {
	 * SQLiteDatabase localSQLiteDatabase = getReadableDatabase(); Cursor
	 * localCursor = localSQLiteDatabase.rawQuery(paramString, null); i =
	 * localCursor.getColumnCount(); String[] arrayOfString = new String[i + 1];
	 * int j = 0; if (j >= i) { this.count = 0; this.count =
	 * localCursor.getCount(); k = 0; if (k >= this.count) {
	 * Log.d("kkkttt111",""+k); localCursor.close();
	 * localSQLiteDatabase.close(); moveFirst(); if (this.count != 0){ return
	 * true; // break label213; }else{
	 * 
	 * return false; }
	 * 
	 * 
	 * } } else { arrayOfString[j] = localCursor.getColumnName(j);
	 * this.table.put(arrayOfString[j], new Vector()); Log.d("kkkttt111",""+j);
	 * j++; continue;
	 * 
	 * }
	 * 
	 * localCursor.move(1);
	 * 
	 * // break label213; m = 0; while(true){
	 * 
	 * Vector localVector = (Vector)this.table.get(arrayOfString[m]); String str
	 * = localCursor.getString(m); if (str == null) str = null;
	 * localVector.addElement(str); m++; } if (m >= i){ k++; }
	 * 
	 * // label211: return true;
	 * 
	 * // label213: if (m >= i) // k++; } catch (Exception localException) {
	 * localException.printStackTrace(); return false; }
	 * 
	 * 
	 * 
	 * }
	 * 
	 * 
	 * }
	 */
	public int recordCount()
	{
		return this.count;
	}
}