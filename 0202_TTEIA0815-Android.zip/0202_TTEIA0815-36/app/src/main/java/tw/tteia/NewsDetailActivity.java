package tw.tteia;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;

import org.apache.http.NameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static tw.tteia.ConstantUtil.SERVER_NAME_WEB;
import static tw.tteia.ConstantUtil.SERVER_NAME_WEB8;

public class NewsDetailActivity extends WebActivity
{
	private TextView title_name;
	private WebView webview_content;
	private ImageView back_btn;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_newsdetail);
		imw.nav_init();
		back_btn= (ImageView) findViewById(R.id.backbtn);
		back_btn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(maint, NewsActivity.class);
				startActivity(intent);
				finish();
			}
		});
		title_name = (TextView)findViewById(R.id.title_name);
		webview_content = (WebView)findViewById(R.id.content);
		HashMap<String, String> timeMap = new HashMap<String, String>();
		if (isInternetPresent == 0)
			alert_error();
		else
			new NewsDetailActivity.get_news_data().execute(timeMap);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		switch (keyCode)
		{
			case KeyEvent.KEYCODE_BACK:
				Intent intent = new Intent();
				intent.setClass(maint, EducationActivity.class);
				startActivity(intent);
				finish();
				break;
		}
		return true;
	}

	private class get_news_data extends AsyncTask<HashMap<String, String>, Void, JSONObject>
	{
		@Override
		protected JSONObject doInBackground(HashMap<String, String>... params)
		{
			String jsonURL = SERVER_NAME_WEB8 + "index.php?mode=get_action_news&id="+sp.getString("news_id","");
			jsonConnect json_func = new jsonConnect();
			List<NameValuePair> postParams = new ArrayList<NameValuePair>();
			String requestJSON = json_func.getjson(jsonURL, postParams);
			JSONObject obj = null;
			try
			{
				obj = new JSONObject(requestJSON);
			} catch (Exception e)
			{
				cancel(true);
			}
			return obj;
		}
		@Override
		protected void onPostExecute(JSONObject result)
		{
			try
			{
				if (result.getString("status").equals("1")) {
					JSONArray typeData = new JSONArray(result.getString("outputObject"));
					String name = typeData.getJSONObject(0).getString("name");
					String content = typeData.getJSONObject(0).getString("content");
					title_name.setText(name);
				//	String html = "<br /><br />Read the handouts please for tomorrow.<br /><br /><!--homework help homework" +
				//			"help help with homework homework assignments elementary school high school middle school" +
				//			"// --><font color='#60c000' size='4'><strong>Please!</strong></font>" +
				//			"<img src='http://www.tteia.org.tw/archive/20190711_12%20AI%20invitation(3).jpg'  />";
				//	webview_content.loadDataWithBaseURL("", html, "text/html","utf-8",null);
					webview_content.loadDataWithBaseURL(SERVER_NAME_WEB,content,"text/html","utf-8",null);
				}
			} catch (Exception e) {}
			super.onPostExecute(result);
		}
	}

	private void alert_error()
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("連線錯誤");
		builder.setMessage("連線發生錯誤，請確認您的網路狀態。").setCancelable(false)
				.setPositiveButton("確定", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.dismiss();
					}
				});
		AlertDialog alert = builder.create();
		alert.show();
	}
/*	private ImageView back_btn;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		back_btn= (ImageView) findViewById(R.id.backbtn);
		back_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(maint, NewsActivity.class);
				startActivity(intent);
				finish();
			}
		});
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		switch (keyCode)
		{
		case KeyEvent.KEYCODE_BACK:
			if (mWebView.canGoBack())
				mWebView.goBack();
			else
			{
				Intent intent = new Intent();
				intent.setClass(maint, NewsActivity.class);
				startActivity(intent);
				finish();
			}
			break;
		}
		return super.onKeyDown(keyCode, event);
	}*/
}
