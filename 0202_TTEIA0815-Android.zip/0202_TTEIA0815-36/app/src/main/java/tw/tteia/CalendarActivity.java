package tw.tteia;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;

import static tw.tteia.ConstantUtil.SERVER_NAME_WEB8;

public class CalendarActivity extends BaseActivity {

	private HashSet<Date> events = new HashSet<>();
	private List<Map<String, String>> datalistmap = new ArrayList<Map<String, String>>();
	private Date today = new Date(),event[];
	private int year_num[],
			month_num[]={0,3,3,6,1,4,6,2,5,0,3,5},
			current_year = today.getYear() + 1900,current_month = today.getMonth() + 1;
	private Boolean listarray[];
	private GridView grid;
	private ImageView btnPrev,btnNext;
	private Calendar currentDate = Calendar.getInstance();

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		System.out.printf("CalendarActivity\r\n");

		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_calendar);
		imw.nav_init();
		year_init();
		event_init();
		imw_thread = new api_getevent();
		imw_thread.start();
	}

	private void event_init(){
		events.clear();
		event = new Date[31];
		listarray = new Boolean[42];
		for(int j=0;j<42;j++){
			datalistmap.add(j,null);
			listarray[j]=false;
		}
	}
	private void year_init(){
		year_num = new int[100];
		year_num[0]=2;
		year_num[1]=3;
		year_num[2]=4;
		year_num[3]=65;
		year_num[4]=0;
		year_num[5]=1;
		year_num[6]=2;
		year_num[7]=43;
		for(int k=8;k<100;k++){
			switch ((k-8)%28)
			{
				case 0:year_num[k]=3;
					break;
				case 1:year_num[k]=4;
					break;
				case 2:year_num[k]=5;
					break;
				case 3:year_num[k]=6;
					break;
				case 4:year_num[k]=1;
					break;
				case 5:year_num[k]=2;
					break;
				case 6:year_num[k]=3;
					break;
				case 7:year_num[k]=54;
					break;
				case 8:year_num[k]=6;
					break;
				case 9:year_num[k]=0;
					break;
				case 10:year_num[k]=1;
					break;
				case 11:year_num[k]=32;
					break;
				case 12:year_num[k]=4;
					break;
				case 13:year_num[k]=5;
					break;
				case 14:year_num[k]=6;
					break;
				case 15:year_num[k]=10;
					break;
				case 16:year_num[k]=2;
					break;
				case 17:year_num[k]=3;
					break;
				case 18:year_num[k]=4;
					break;
				case 19:year_num[k]=65;
					break;
				case 20:year_num[k]=0;
					break;
				case 21:year_num[k]=1;
					break;
				case 22:year_num[k]=2;
					break;
				case 23:year_num[k]=43;
					break;
				case 24:year_num[k]=5;
					break;
				case 25:year_num[k]=6;
					break;
				case 26:
					year_num[k] = 0;
					break;
				case 27:
					year_num[k] = 21;
					break;
			}
		}
	}
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.menu_main, menu);
		return true;
	}
	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	private class api_getevent extends Thread {
		@Override
		public void run()
		{
			String jsonURL = SERVER_NAME_WEB8 + "index.php?mode=get_calendar&year=" + Integer.toString(current_year) + "&month=" + Integer.toString(current_month);

			System.out.printf("api_getevent\r\n" + jsonURL + "\r\n");

			jsonConnect json_func = new jsonConnect();
			try
			{
				String requestJSON = json_func.getJson(jsonURL);
				try
				{
					JSONObject obj = new JSONObject(requestJSON);
					String calendar_data = obj.getString("outputObject");
					JSONArray DataArray = new JSONArray(calendar_data);
					for (int i = 0; i < DataArray.length(); i++)
					{
						event[i]=new Date();
						event[i].setYear(current_year - 1900);
						event[i].setMonth(current_month - 1);
						event[i].setDate(Integer.parseInt(DataArray.getJSONObject(i).getString("date").substring(8, 10)));
						events.add(event[i]);
						HashMap<String, String> eventData = new HashMap<String, String>();
						eventData.put("year", DataArray.getJSONObject(i).getString("date").substring(0, 4));
						eventData.put("month", DataArray.getJSONObject(i).getString("date").substring(5, 7));
						eventData.put("day", DataArray.getJSONObject(i).getString("date").substring(8, 10));

						int A01 = Integer.parseInt(DataArray.getJSONObject(i).getString("date").substring(8, 10));
						listarray[A01]=true;
						datalistmap.add(A01,eventData);

					}
				} catch (Exception e) {}
			} catch (Exception e) {}
			mHandler.post(new Runnable()
			{
				public void run()
				{
					calendar_init(datalistmap);
				}
			});
			super.run();
		}
	}

	private void calendar_init(final List<Map<String, String>> listmap)
	{
		CalendarView cv = ((CalendarView)findViewById(R.id.calendar_view));
		cv.updateCalendar(events,currentDate);
		grid = (GridView)findViewById(R.id.calendar_grid);
		grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

			//	view.findViewById( R.id.cast_notification_id );
				String IsClick = ((TextView)view).getText().toString();
				int A01 = Integer.parseInt(IsClick);
				// System.out.printf("IsClick: " + IsClick + "\r\n" );

				position = A01;

				if (listarray[position]) {
					speditor.putString("event_year", listmap.get(position).get("year"));
					speditor.putString("event_month", listmap.get(position).get("month"));
					speditor.putString("event_day", listmap.get(position).get("day"));
					speditor.commit();

				//	System.out.printf("event_year: " + listmap.get(position).get("year") + "\r\n" );
				//	System.out.printf("event_month: " + listmap.get(position).get("month") + "\r\n" );
				//	System.out.printf("event_day: " + listmap.get(position).get("day") + "\r\n" );

					Intent intent = new Intent();
					intent.setClass(maint, EventActivity.class);
					startActivity(intent);
				}
			}
		});
		btnPrev = (ImageView)findViewById(R.id.calendar_prev_button);
		btnNext = (ImageView)findViewById(R.id.calendar_next_button);
		// add one month and refresh UI
		btnNext.setOnClickListener(new View.OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				currentDate.add(Calendar.MONTH, 1);
				if(current_month == 12){
					current_year += 1;
					current_month = 1;
				}
				else
					current_month +=1;
				event_init();
				imw_thread = new api_getevent();
				imw_thread.start();
			}
		});
		// subtract one month and refresh UI
		btnPrev.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				currentDate.add(Calendar.MONTH, -1);
				if (current_month == 1) {
					current_year -= 1;
					current_month = 12;
				} else
					current_month -= 1;
				event_init();
				imw_thread = new api_getevent();
				imw_thread.start();
			}
		});
	}
}