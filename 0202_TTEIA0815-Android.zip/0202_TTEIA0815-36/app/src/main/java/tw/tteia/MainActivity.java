package tw.tteia;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

import static tw.tteia.ConstantUtil.SERVER_NAME_WEB;
import static tw.tteia.ConstantUtil.SERVER_NAME_WEB8;

public class MainActivity extends BaseActivity
{
	public ImageView back_btn;
	private ImageView menu_member,menu_education,menu_report,menu_nearby,menu_news,menu_bidding,menu_calendar,menu_monthly,menu_contact;
	private  int counter = 0,max=0;
	/*----------------------主程式--------------------------------*/
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		imw.nav_init();
		back_btn = (ImageView) findViewById(R.id.backbtn);
		back_btn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				dialog_finish();
			}
		});
		button_init();
		if (isInternetPresent == 0)
			alert_error();

		// 依序讀取資料
		imw_thread = new api_getnews();
		imw_thread.start();
	}

	private void button_init(){
		menu_member = (ImageView) findViewById(R.id.menu_member);
		menu_education = (ImageView) findViewById(R.id.menu_education);
		menu_report = (ImageView) findViewById(R.id.menu_report);
		menu_nearby = (ImageView) findViewById(R.id.menu_nearby);
		menu_news = (ImageView) findViewById(R.id.menu_news);
		menu_bidding = (ImageView) findViewById(R.id.menu_bidding);
		menu_calendar = (ImageView) findViewById(R.id.menu_calendar);
		menu_monthly = (ImageView) findViewById(R.id.menu_monthly);
		menu_contact = (ImageView) findViewById(R.id.menu_contact);

		menu_member.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent member = new Intent(maint, tw.tteia.MemberFirstActivity.class);
				member.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(member);
			}
		});

		menu_education.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent education = new Intent(maint, tw.tteia.EducationActivity.class);
				education.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(education);
			}
		});

		menu_report.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent report = new Intent(maint, tw.tteia.ReportActivity.class);
				report.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(report);
			}
		});

		menu_nearby.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent nearby = new Intent(maint, tw.tteia.NearbyActivity.class);
				nearby.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(nearby);
			}
		});

		menu_news.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent news = new Intent(maint, tw.tteia.NewsActivity.class);
				news.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(news);
			}
		});

		menu_bidding.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent bidding = new Intent(maint, tw.tteia.BiddingActivity.class);
				bidding.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(bidding);
			}
		});

		menu_calendar.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				System.out.printf("CalendarActivity\r\n");
				Intent calendar = new Intent(maint, tw.tteia.CalendarActivity.class);
				calendar.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(calendar);
			}
		});

		menu_monthly.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent calendar = new Intent(maint, MonthlyActivity.class);
				calendar.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(calendar);
			}
		});

		menu_contact.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
			//	imw.weburlchange(SERVER_NAME_WEB + "api/index.php?mode=get_information&id=3813", R.string.title_contact, false);
				imw.weburlchange(SERVER_NAME_WEB + "app/contact_us/", R.string.title_contact, false);
			}
		});

	}

	// 活動訊息
	private class api_getnews extends Thread
	{
		@Override
		public void run()
		{
			String jsonURL = SERVER_NAME_WEB8 + "api_1_0_37.php?mode=get_news_tag&type=1";
			System.out.print("\r\n NEWS_range: " +  jsonURL + "\r\n" );
			jsonConnect json_func = new jsonConnect();
			try
			{
				String requestJSON = json_func.getJson(jsonURL);
				try
				{
					JSONObject obj = new JSONObject(requestJSON);
					String news_data = obj.getString("outputObject");
					JSONArray DataArray = new JSONArray(news_data);
					max = DataArray.length();
					System.out.print( "\r\n --- True: max = DataArray.length()" + String.valueOf(max) );

					int tempMax = 0, tempMin = 987654 , tempNow = 0 ;
					for (int i = 0; i < max; i++)
					{
						tempNow = Integer.valueOf( DataArray.getJSONObject(i).getString("id") );
						if(tempNow > tempMax){
							tempMax = tempNow;
						}
						if(tempNow < tempMin){
							tempMin = tempNow;
						}

						if(DataArray.getJSONObject(i).getString("status").equals("0"))
							counter+=1;
					}

					NEWS_range[1] = tempMax;
					NEWS_range[0] = tempMin;

				} catch (Exception e) {}
			} catch (Exception e) {}
			mHandler.post(new Runnable()
			{
				public void run()
				{

					 System.out.print( "\r\n --- True: NEWS_range[0]" + String.valueOf(NEWS_range[0]) );
					 System.out.print( "\r\n --- True: NEWS_range[1]" + String.valueOf(NEWS_range[1]) );

					for(int i= NEWS_range[0] ; i <= NEWS_range[1] ; i++){
						if(sp.getBoolean("news_" + i, false))
							counter+=1;
					}
					TextView remind_news = (TextView) findViewById(R.id.remind_news);
					if(max - counter>100){
						remind_news.setVisibility(View.VISIBLE);
						remind_news.setText("99+");
					}else if(max - counter>0){
						remind_news.setVisibility(View.VISIBLE);
						remind_news.setText(Integer.toString(max - counter));
					}else remind_news.setVisibility(View.GONE);
					counter = 0;
					imw_thread = new api_getreport();
					imw_thread.start();
				}
			});
			super.run();
		}
	}

	private class api_getreport extends Thread
	{
		@Override
		public void run()
		{
			String jsonURL = SERVER_NAME_WEB8 + "api_1_0_37.php?mode=get_news_tag&type=2";
			jsonConnect json_func = new jsonConnect();
			try
			{
				String requestJSON = json_func.getJson(jsonURL);
				try
				{
					JSONObject obj = new JSONObject(requestJSON);
					String news_data = obj.getString("outputObject");
					JSONArray DataArray = new JSONArray(news_data);
					max = DataArray.length();

					int tempMax = 0, tempMin = 987654 , tempNow = 0 ;
					for (int i = 0; i < max; i++)
					{
						tempNow = Integer.valueOf( DataArray.getJSONObject(i).getString("id") );
						if(tempNow > tempMax){
							tempMax = tempNow;
						}
						if(tempNow < tempMin){
							tempMin = tempNow;
						}
						if(DataArray.getJSONObject(i).getString("status").equals("0"))
							counter+=1;
					}

					RPTS_range[1] = tempMax;
					RPTS_range[0] = tempMin;

				} catch (Exception e) {}
			} catch (Exception e) {}
			mHandler.post(new Runnable()
			{
				public void run()
				{
					for(int i= RPTS_range[0] ; i <= RPTS_range[1]  ; i++){
						if(sp.getBoolean("report_" + i, false))
							counter+=1;
					}
					TextView remind_report = (TextView) findViewById(R.id.remind_report);
					if(max - counter>100){
						remind_report.setVisibility(View.VISIBLE);
						remind_report.setText("99+");
					}else if(max - counter>0){
						remind_report.setVisibility(View.VISIBLE);
						remind_report.setText(Integer.toString(max - counter));
					}else remind_report.setVisibility(View.GONE);
					counter = 0;
					imw_thread = new api_getbidding();
					imw_thread.start();
				}
			});
			super.run();
		}
	}

	private class api_getbidding extends Thread
	{
		@Override
		public void run()
		{
			String jsonURL = SERVER_NAME_WEB8 + "api_1_0_37.php?mode=get_action_2";
			jsonConnect json_func = new jsonConnect();
			try
			{
				String requestJSON = json_func.getJson(jsonURL);
				try
				{
					JSONObject obj = new JSONObject(requestJSON);
					String news_data = obj.getString("outputObject");
					JSONArray DataArray = new JSONArray(news_data);
					max = DataArray.length();

					int tempMax = 0, tempMin = 987654 , tempNow = 0 ;
					for (int i = 0; i < max; i++)
					{
						tempNow = Integer.valueOf( DataArray.getJSONObject(i).getString("id") );
						if(tempNow > tempMax){
							tempMax = tempNow;
						}
						if(tempNow < tempMin){
							tempMin = tempNow;
						}
						if(DataArray.getJSONObject(i).getString("status").equals("0"))
							counter+=1;
					}

					BIDD_range[1] = tempMax;
					BIDD_range[0] = tempMin;


				} catch (Exception e) {}
			} catch (Exception e) {}
			mHandler.post(new Runnable()
			{
				public void run()
				{
					for(int i= BIDD_range[0] ; i <= BIDD_range[1] ; i++){
						if(sp.getBoolean("bidding_" + i, false))
							counter+=1;
					}
					TextView remind_bidding = (TextView) findViewById(R.id.remind_bidding);
					if(max - counter>100){
						remind_bidding.setVisibility(View.VISIBLE);
						remind_bidding.setText("99+");
					}else if(max - counter>0){
						remind_bidding.setVisibility(View.VISIBLE);
						remind_bidding.setText(Integer.toString(max - counter));
					}else remind_bidding.setVisibility(View.GONE);
					counter = 0;
					imw_thread = new api_geteducation();
					imw_thread.start();
				}
			});
			super.run();
		}
	}

	private class api_geteducation extends Thread
	{
		@Override
		public void run()
		{
			String jsonURL = SERVER_NAME_WEB8 + "api_1_0_37.php?mode=get_action";
			jsonConnect json_func = new jsonConnect();
			try
			{
				String requestJSON = json_func.getJson(jsonURL);
				try
				{
					JSONObject obj = new JSONObject(requestJSON);
					String news_data = obj.getString("outputObject");
					JSONArray DataArray = new JSONArray(news_data);
					max = DataArray.length();

					int tempMax = 0, tempMin = 987654 , tempNow = 0 ;
					for (int i = 0; i < max; i++)
					{
						tempNow = Integer.valueOf( DataArray.getJSONObject(i).getString("id") );
						if(tempNow > tempMax){
							tempMax = tempNow;
						}
						if(tempNow < tempMin){
							tempMin = tempNow;
						}

						if(DataArray.getJSONObject(i).getString("status").equals("0"))
							counter+=1;
					}

					EDUS_range[1] = tempMax;
					EDUS_range[0] = tempMin;

				} catch (Exception e) {}
			} catch (Exception e) {}
			mHandler.post(new Runnable()
			{
				public void run()
				{
					for(int i= EDUS_range[0] ; i <= EDUS_range[1] ; i++){
						if(sp.getBoolean("education_" + i, false))
							counter+=1;
					}
					TextView remind_education = (TextView) findViewById(R.id.remind_education);
					if(max - counter>100){
						remind_education.setVisibility(View.VISIBLE);
						remind_education.setText("99+");
					}else if(max - counter>0){
						remind_education.setVisibility(View.VISIBLE);
						remind_education.setText(Integer.toString(max - counter));
					}else remind_education.setVisibility(View.GONE);
				}
			});
			super.run();
		}
	}

	private void alert_error()
	{
		AlertDialog.Builder MyAlertDialog = new AlertDialog.Builder(maint);
		MyAlertDialog.setTitle("無法取得網路連線");
		MyAlertDialog.setIcon(R.mipmap.icon_80x80);
		MyAlertDialog.setMessage("部份功能必需在網路連線狀態下執行，請確定您是否已連線上網！").setCancelable(false)
				.setPositiveButton("確定", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        finish();
                    }
                });
		AlertDialog alert = MyAlertDialog.create();
		alert.show();
	}

	protected void dialog_finish()
	{
		AlertDialog.Builder bulider = new AlertDialog.Builder(this);
		bulider.setTitle("確定是否離開電信公會?");
		bulider.setIcon(R.mipmap.icon_80x80);
		bulider.setPositiveButton("確定", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dialog.cancel();
				finishAffinity();
			}

		});
		bulider.setNegativeButton("取消", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dialog.cancel();
			}

		});
		AlertDialog alert2 = bulider.create();
		alert2.show();
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		boolean b_state = true;
		switch (keyCode)
		{
			case KeyEvent.KEYCODE_BACK:
				dialog_finish();
				b_state = true;
				break;
			default:
				b_state = super.onKeyDown(keyCode, event);
				break;
		}
		return b_state;
	}
}