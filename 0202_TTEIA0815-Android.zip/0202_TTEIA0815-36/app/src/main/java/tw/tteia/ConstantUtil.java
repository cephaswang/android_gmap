package tw.tteia;

public class ConstantUtil
{
	public static String SERVER_NAME_WEB = "http://www.tteia.org.tw/";
	public static String SERVER_NAME_WEB8 = SERVER_NAME_WEB + "api/";
	public static String FILENAME = "/imwpic/";

	// 基本設定
	public static String MAINNAME = "tw.tteia";
	public static String DBNAME_PATH = "imw_DB";
	public static String CONFIG_PATH = "imw_config";
	public static String FILE_TXT = "imw.txt";

	public static String[] unCheckNetActivity =
	{ MAINNAME + ".WarningActivity", MAINNAME + ".Welcome" };
	public static String[] unCheckUserActivity =
	{ MAINNAME + ".WarningActivity", MAINNAME + ".Welcome",	MAINNAME + ".UserLoginActivity",MAINNAME + ".MainActivity",
			MAINNAME + ".MonthlyDetailActivity"};

	// 下載狀態
	public static final int DOWNLOAD_PREPARE = 0;
	public static final int DOWNLOAD_WORK = 1;
	public static final int DOWNLOAD_OK = 2;
	public static final int DOWNLOAD_ERROR = 3;

	// 上傳狀態
	public static final int UPLOAD_PREPARE = 0;
	public static final int UPLOAD_WORK = 1;
	public static final int UPLOAD_OK = 2;
	public static final int UPLOAD_ERROR = 3;
}