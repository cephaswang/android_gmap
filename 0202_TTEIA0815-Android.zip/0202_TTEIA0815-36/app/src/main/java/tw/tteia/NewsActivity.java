package tw.tteia;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static tw.tteia.ConstantUtil.SERVER_NAME_WEB8;

public class NewsActivity extends BaseActivity
{
	private Context context = NewsActivity.this;
	private ImageView back_btn,read_btn;
	private ListView data_listview;
	private ProgressDialog mypDialog;
	private List<Map<String, String>> datalistmap = new ArrayList<Map<String, String>>();
	public Thread imw_thread;
	private Handler mHandler = new Handler();
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_null);
		setContentView(R.layout.activity_news);
		imw.nav_init();
		back_btn = (ImageView) findViewById(R.id.backbtn);
		back_btn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				imw.backMain();
				finish();
			}
		});
		read_btn = (ImageView) findViewById(R.id.readbtn);
		read_btn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				dialog_Clear();
			}

		});
		if (isInternetPresent == 0)
			Toast.makeText(context, "無法連接到網路，請檢查您的連線設定！", Toast.LENGTH_LONG).show();
		else
		{
			mypDialog = new ProgressDialog(this);
			mypDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			mypDialog.setMessage("更新資料中");
			mypDialog.setIndeterminate(false);
			mypDialog.setCancelable(false);
			mypDialog.show();
			imw_thread = new api_getnews();
			imw_thread.start();
		}
		mypDialog.dismiss();
	}

	protected void dialog_Clear()
	{
		AlertDialog.Builder bulider = new AlertDialog.Builder(this);
		bulider.setTitle("確認要一鍵巳讀？");
		bulider.setIcon(R.mipmap.icon_80x80);
		bulider.setPositiveButton("確定", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dialog.cancel();

				for(int i= NEWS_range[0] ; i <= NEWS_range[1]  ; i++){
					if (sp.getString("news_tag_" + i, "").equals("signed")) {
						speditor.putBoolean("news_" + i, true);
						speditor.commit();
					}
				}
				Intent member = new Intent(maint, tw.tteia.NewsActivity.class);
				member.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				startActivity(member);
			}

		});
		bulider.setNegativeButton("取消", new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int id)
			{
				dialog.cancel();
			}

		});
		AlertDialog alert2 = bulider.create();
		alert2.show();
	}


	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		switch (keyCode)
		{
			case KeyEvent.KEYCODE_BACK:
				imw.backMain();
				finish();
				return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	private class api_getnews extends Thread
	{
		@Override
		public void run()
		{
			String jsonURL = SERVER_NAME_WEB8 + "api_1_0_37.php?mode=get_news_tag&type=1";
			jsonConnect json_func = new jsonConnect();
			try
			{
				String requestJSON = json_func.getJson(jsonURL);
				try
				{
					JSONObject obj = new JSONObject(requestJSON);
					String status = obj.getString("status");
					if (status.equals("0"))
						mHandler.post(new Runnable()
						{
							public void run()
							{
								Toast.makeText(context, "抱歉，目前尚無活動資料", Toast.LENGTH_LONG).show();
								mypDialog.dismiss();
							}
						});
					String news_data = obj.getString("outputObject");
					JSONArray DataArray = new JSONArray(news_data);

					int max = DataArray.length();
					System.out.print( "\r\n --- True: max = DataArray.length()" + String.valueOf(max) );

					for (int i = 0; i < DataArray.length(); i++)
					{
						HashMap<String, String> newsData = new HashMap<String, String>();
						if(DataArray.getJSONObject(i).getString("status").equals("0"))
							continue;
						newsData.put("id", DataArray.getJSONObject(i).getString("id"));
						newsData.put("subject", DataArray.getJSONObject(i).getString("subject"));
						newsData.put("date_start", DataArray.getJSONObject(i).getString("date_start"));
						speditor.putString("news_tag_" + DataArray.getJSONObject(i).getString("id"), "signed");
						speditor.commit();
						datalistmap.add(newsData);
					}
				} catch (Exception e) {}
			} catch (Exception e) {}
			mHandler.post(new Runnable()
			{
				public void run()
				{
					int max = datalistmap.size();
					System.out.print( "\r\n --- True: int max = datalistmap.size()" + String.valueOf(max) + "\r\n" );
					datalist_init(datalistmap);
					mypDialog.dismiss();
				}
			});
			super.run();
		}
	}

	private void datalist_init(final List<Map<String, String>> listmap)
	{
		TextView inone = (TextView) findViewById(R.id.inonetxt);
		inone.setVisibility(View.GONE);
		data_listview = (ListView) findViewById(R.id.news_data);
		data_listview.setAdapter(new BaseAdapter() {
			@Override
			public View getView(int position, View convertView, ViewGroup parent) {
				// 新建LinearLayout
				View view = getLayoutInflater().inflate(R.layout.news_listview, null);
				TextView subject = (TextView) view.findViewById(R.id.newstext);
				if (listmap.get(position).get("subject").length() > 10)
					subject.setText(listmap.get(position).get("subject").substring(0, 10) + "...");
				else
					subject.setText(listmap.get(position).get("subject"));
				TextView year = (TextView) view.findViewById(R.id.year);
				TextView date = (TextView) view.findViewById(R.id.date);
				year.setText(listmap.get(position).get("date_start").replaceAll("-", "").substring(0,4));
				date.setText(listmap.get(position).get("date_start").replaceAll("-", "").substring(4,8));
				ImageView tag_new = (ImageView) view.findViewById(R.id.tag_new);
				ImageView arrow = (ImageView) view.findViewById(R.id.arrow);
				if (sp.getBoolean("news_" + listmap.get(position).get("id"), false)) {
					tag_new.setVisibility(View.GONE);
					arrow.setVisibility(View.VISIBLE);
				} else {
					tag_new.setVisibility(View.VISIBLE);
					arrow.setVisibility(View.GONE);
				}
				return view;
			}
			@Override
			public long getItemId(int position) {
				return Integer.parseInt(listmap.get(position).get("id"));
			}
			@Override
			public Object getItem(int position) {
				return listmap.get(position);
			}
			@Override
			public int getCount() {
				return listmap.size();
			}
		});
		data_listview.setOnItemClickListener(new OnItemClickListener()
		{
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id)
			{
				try
				{
					speditor.putString("news_id", String.valueOf(id));
					speditor.putBoolean("news_" + String.valueOf(id), true);
					speditor.commit();
					System.out.print( "\r\n --- True: news_" + String.valueOf(id) );

					Intent intent = new Intent();
					intent.setClass(maint, NewsDetailActivity.class);
					startActivity(intent);
					finish();
				} catch (Exception e) {}

			}
		});
		if (listmap.size() == 0)
			Toast.makeText(context, "抱歉，目前尚無活動訊息", Toast.LENGTH_LONG).show();
	}
}