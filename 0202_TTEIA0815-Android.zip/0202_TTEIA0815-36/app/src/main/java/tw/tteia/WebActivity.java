package tw.tteia;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

public class WebActivity extends BaseActivity
{
	// 建立瀏覽器
	public WebView mWebView;
	private Context context = WebActivity.this;
	// db 物件
	static LiteDatabase mydb;
	public TextView webtextView1;
	public int titlename = 0;
	private static final int qrcode_join_order = 0x000001;
	public String webloadurl = "";
	private WebSettings webSettings;
	private ProgressBar loadbar;
	@SuppressLint("SetJavaScriptEnabled")
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_weburl);
		imw.nav_init();
		webinit();
		// 資料更新
		// 判斷選單資料
		if (isInternetPresent == 0)
			Toast.makeText(context, "無法連接到網路，請檢查您的連線設定！", Toast.LENGTH_LONG).show();
		else
		{
			try
			{
				Bundle bundle = this.getIntent().getExtras();
				String url = bundle.getString("url");
				int titleint = bundle.getInt("titleint");
				weburl(url, titleint);
			} catch (Exception e) {}
		}
	}

	private void webinit()
	{
		speditor.putString("packagename", "webactivity");
		speditor.commit();
		webtextView1 = (TextView) findViewById(R.id.title_name);
	}
	/*
	 * 切換 網頁版的視窗 activity_web.xml 視窗
	 */
	public void weburl(String url, int titleint)
	{
		titlename = titleint;
		webloadurl = url;
		webtextView1.setText(titleint);
		flag = 1;
		mWebView = (WebView) findViewById(R.id.webView1);
		webSettings = mWebView.getSettings();
		webSettings.setJavaScriptEnabled(true);
		webSettings.setBuiltInZoomControls(true); // 顯示放大縮小 controller
		webSettings.setSupportZoom(true); // 可以縮放
		webSettings.setDefaultZoom(WebSettings.ZoomDensity.FAR);// 預設縮放模式
		webSettings.setUseWideViewPort(true);
		mWebView.addJavascriptInterface(new webfunction(this), "Android");
		mWebView.loadUrl(url);
		mWebView.setWebChromeClient(new WebChromeClient()
		{
			@Override
			public void onReachedMaxAppCacheSize(long spaceNeeded, long totalUsedQuota, WebStorage.QuotaUpdater quotaUpdater)
			{
				quotaUpdater.updateQuota(spaceNeeded * 2);
			}

			@Override
			public boolean onJsAlert(WebView view, String url, String message, final android.webkit.JsResult result)
			{
				new AlertDialog.Builder(WebActivity.this).setTitle("訊息").setMessage(message)
						.setPositiveButton(android.R.string.ok, new AlertDialog.OnClickListener()
						{
							public void onClick(DialogInterface dialog, int which)
							{
								result.confirm();
							}
						}).setCancelable(false).create().show();
				return true;
			}
			@Override
			public void onReceivedTitle(WebView view, String sTitle)
			{
				super.onReceivedTitle(view, sTitle);
			}
		});

		mWebView.setWebViewClient(new WebViewClient() {
			@Override
			public boolean shouldOverrideUrlLoading(WebView view, String url) {
				String urlkey = "<div id=\"ok\"></div>";
				if (url.indexOf(urlkey) > -1)
					return true;
				else
					return false;
			}

			@Override
			public void onReceivedError(WebView paramWebView, int paramInt, String paramString1, String paramString2) {
				imw.ActivityToWarning(titlename);
				super.onReceivedError(paramWebView, paramInt, paramString1, paramString2);
			}

			@Override
			public void onPageFinished(WebView view, String url) {
				loadbar = (ProgressBar) findViewById(R.id.loadbar);
				loadbar.setVisibility(View.GONE);
				view.loadUrl("javascript:window.local_obj.showSource('<html>'+document.getElementsByTagName('html')[0].innerHTML+'</html>');");
				super.onPageFinished(view, url);
			}

			@Override
			public void onPageStarted(WebView view, String url, Bitmap favicon) {
				super.onPageStarted(view, url, favicon);
				ProgressBar loadbar = (ProgressBar) findViewById(R.id.loadbar);
				loadbar.setVisibility(View.VISIBLE);
			}
		});
	}

	public class webfunction
	{
		Context mContext;
		webfunction(Context c)
		{
			mContext = c;
		}
		// 撥打電話
		@JavascriptInterface
		public void telext(String telStr)
		{
			String phone = telStr.replace("wtai://wp/mc;", "");
			Uri uri = Uri.parse("tel:" + phone);
			Intent intent = new Intent(Intent.ACTION_DIAL, uri);
			startActivity(intent);
		}
		// 導航
		@JavascriptInterface
		public void gpsurl(String gpsStr)
		{
			Uri uri = Uri.parse("geo:0,0?q=" + gpsStr);
			Intent intent = new Intent(Intent.ACTION_VIEW, uri);
			startActivity(intent);
		}
		@JavascriptInterface
		public void openqrcode_join()
		{
			Intent intent = new Intent("com.google.zxing.client.android.SCAN");
			startActivityForResult(intent, qrcode_join_order);
		}
	}
	// 跟網頁溝通
	public class InJavaScriptLocalObj
	{
		Context mContext;
		InJavaScriptLocalObj(Context c)
		{
			mContext = c;
		}
		// 網頁
		@JavascriptInterface
		public void showSource(String webStr)
		{
			showhtml(webStr);
		}
	}

	public void showhtml(String webStr)
	{
		String urlkey = "<div id=\"ok\"></div>";
		if (webStr.indexOf(urlkey) > -1) {}
		else
			imw.ActivityToWarning(titlename);
	}

	// ==================== 秀出 訊息 ==================================
	private void showerrorAlert(int tmp)
	{
		// Looper.prepare();
		Builder MyAlertDialog = new AlertDialog.Builder(maint);
		MyAlertDialog.setTitle("警告 !!");
		MyAlertDialog.setIcon(R.mipmap.icon_80x80);
		// MyAlertDialog.setMessage(tmp);
		MyAlertDialog.setMessage(tmp);
		// 建立按下按鈕
		DialogInterface.OnClickListener OkClick = new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int which)
			{
				// 如果不做任何事情 就會直接關閉 對話方塊
				// System.out.println(">>找尋>>>>>>>>"+which);
				dialog.cancel();
			}
		};
		MyAlertDialog.setNegativeButton("關閉", OkClick);
		AlertDialog alert2 = MyAlertDialog.create();
		alert2.getWindow().setType(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED);
		alert2.show();
		// Looper.loop();
		// MyAlertDialog.show();
	}
	// ======================================================
	// 判斷網頁是否存在
	public boolean checkweb(String urlx)
	{
		try
		{
			URL url = new URL(urlx);
			executeReq(url);
			return true;
		} catch (Exception e) {}
		return false;
	}

	private void executeReq(URL urlObject) throws IOException
	{
		HttpURLConnection conn = null;
		conn = (HttpURLConnection) urlObject.openConnection();
		conn.setReadTimeout(10000);// milliseconds
		conn.setConnectTimeout(2000);// milliseconds
		conn.setRequestMethod("GET");
		conn.setDoInput(true);
		// Start connect
		conn.connect();
		InputStream response = conn.getInputStream();
	}
	/*
	 * 
	 * 建立DB 元件
	 */
	public static LiteDatabase getMydb()
	{
		if (mydb == null)
			mydb = new LiteDatabase(maint, "imw_isclubDB");
		return mydb;
	}

	@Override
	protected void onRestart()
	{
		super.onRestart();
		weburl(webloadurl, titlename);
	}
	@Override
	protected void onPause()
	{
		super.onPause();
	}
	@Override
	protected void onStop()
	{
		super.onStop();
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		switch (keyCode)
		{
			case KeyEvent.KEYCODE_BACK:
				if (mWebView.canGoBack())
					mWebView.goBack();
				else
					super.onKeyDown(keyCode, event);
				break;
			default:
				super.onKeyDown(keyCode, event);
				break;
		}
		return false;
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
	}
}