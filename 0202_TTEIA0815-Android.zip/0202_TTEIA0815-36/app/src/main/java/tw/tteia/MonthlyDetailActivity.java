package tw.tteia;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static tw.tteia.ConstantUtil.SERVER_NAME_WEB;
import static tw.tteia.ConstantUtil.SERVER_NAME_WEB8;

public class MonthlyDetailActivity extends BaseActivity
{
	private Context context = MonthlyDetailActivity.this;
	private ImageView back_btn;
	private ListView data_listview;
	private List<Map<String, String>> datalistmap = new ArrayList<Map<String, String>>();
	public Thread imw_thread;
	private ProgressDialog mypDialog;
	private Handler mHandler = new Handler();
	private String dest_file_path = "imw.pdf";
	private int downloadedSize = 0, totalsize;
	private String download_file_url = "";
	float per = 0;

	private final static int REQ_PERMISSIONS = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		System.out.printf("MonthlyDetailActivity");

		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_null);
		setContentView(R.layout.activity_monthly);
		imw.nav_init();
		back_btn= (ImageView) findViewById(R.id.backbtn);
		back_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(maint, MonthlyActivity.class);
				startActivity(intent);
				finish();
			}
		});
		if (isInternetPresent == 0)
			Toast.makeText(context, "無法連接到網路，請檢查您的連線設定！", Toast.LENGTH_LONG).show();
		else
		{
			imw_thread = new api_getmonthly();
			imw_thread.start();
		}

		askPermissions();
	}

	private void askPermissions() {

		String[] PERMISSION_S = {
				android.Manifest.permission.WRITE_EXTERNAL_STORAGE,
				android.Manifest.permission.READ_EXTERNAL_STORAGE
		};


		Set<String> permissionsRequest = new HashSet<>();
		for (String permission : PERMISSION_S) {
			int result = ContextCompat.checkSelfPermission(this, permission);
			if (result != PackageManager.PERMISSION_GRANTED) {
				permissionsRequest.add(permission);
			}
		}

		if (!permissionsRequest.isEmpty()) {
			ActivityCompat.requestPermissions(this,
					permissionsRequest.toArray(new String[permissionsRequest.size()]),
					REQ_PERMISSIONS);
		}
		System.out.println("permissionsRequest:" + permissionsRequest.size());
	}

	@SuppressLint("Override")
	public void onRequestPermissionsResult(int requestCode,
										   @NonNull String[] permissions,
										   @NonNull int[] grantResults) {
		switch (requestCode) {
			case REQ_PERMISSIONS:
				for (int result : grantResults) {
					if (result != PackageManager.PERMISSION_GRANTED) {
						// String text = getString(R.string.text_ShouldGrant) + " : "+ result ;
						Toast.makeText(this, "text", Toast.LENGTH_LONG).show();

						// handler.postDelayed(GotoMenu, 4000);
						return;
					}
				}
				break;
		}
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		switch (keyCode)
		{
			case KeyEvent.KEYCODE_BACK:
				Intent intent = new Intent();
				intent.setClass(maint, MonthlyActivity.class);
				startActivity(intent);
				finish();
				return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	private class api_getmonthly extends Thread
	{
		@Override
		public void run()
		{
			datalistmap.clear();

			String jsonURL = SERVER_NAME_WEB8 + "magazine.php?mode=magazine_folder&folder_id=" + sp.getString("monthly_type_id","");
			System.out.print( "\r\n" + jsonURL + "\r\n" );

			jsonConnect json_func = new jsonConnect();
			try
			{
				String requestJSON = json_func.getJson(jsonURL);
				try
				{
					JSONObject obj = new JSONObject(requestJSON);
					String status = obj.getString("status");
					if (status.equals("0"))
						mHandler.post(new Runnable()
						{
							public void run()
							{
								Toast.makeText(context, "抱歉，目前尚無月刊資料", Toast.LENGTH_LONG).show();
							}
						});
					String monthly_Data = obj.getString("outputObject");
					JSONArray DataArray = new JSONArray(monthly_Data);
					for (int i = 0; i < DataArray.length(); i++)
					{
						HashMap<String, String> monthlyData = new HashMap<String, String>();
						monthlyData.put("id", DataArray.getJSONObject(i).getString("id"));
						monthlyData.put("folder_name", DataArray.getJSONObject(i).getString("folder_name"));
						datalistmap.add(monthlyData);
					}
				} catch (Exception e) {}
			} catch (Exception e) {}

			System.out.print( "\r\n datalistmap.size(): " + datalistmap.size() + "\r\n" );

			mHandler.post(new Runnable()
			{
				public void run()
				{
					datalist_init(datalistmap);
				}
			});
			super.run();
		}
	}

	private void datalist_init(final List<Map<String, String>> listmap)
	{
		TextView inone = (TextView) findViewById(R.id.inonetxt);
		inone.setVisibility(View.GONE);
		data_listview = (ListView) findViewById(R.id.news_data);
		data_listview.setAdapter(new BaseAdapter() {
			@Override
			public View getView(int position, View convertView, ViewGroup parent) {
				// 新建LinearLayout
				View view = getLayoutInflater().inflate(R.layout.monthly_listview, null);
				TextView name = (TextView) view.findViewById(R.id.name);
				name.setText(listmap.get(position).get("folder_name"));
				return view;
			}
			@Override
			public long getItemId(int position) {
				return Integer.parseInt(listmap.get(position).get("id"));
			}
			@Override
			public Object getItem(int position) {
				return listmap.get(position);
			}
			@Override
			public int getCount() {
				return listmap.size();
			}
		});
		data_listview.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				try {
					speditor.putString("file_id",listmap.get(position).get("id"));
					speditor.commit();
					imw_thread = new api_getfile();
					imw_thread.start();
					imw_thread.join();
					download_file_url = SERVER_NAME_WEB + "archive/" + sp.getString("file_name","");
					downloadAndOpenPDF(download_file_url);
				} catch (Exception e) {}
			}
		});
		if (listmap.size() == 0)
			Toast.makeText(context, "抱歉，目前尚無月刊訊息", Toast.LENGTH_LONG).show();
	}

	private class api_getfile extends Thread
	{
		@Override
		public void run()
		{
			String jsonURL = SERVER_NAME_WEB8 + "api.php?mode=magazine_delite&folder_id=" + sp.getString("file_id","");
			jsonConnect json_func = new jsonConnect();
			try
			{
				String requestJSON = json_func.getJson(jsonURL);
				try
				{
					JSONObject obj = new JSONObject(requestJSON);
					String status = obj.getString("status");
					if (status.equals("0"))
						mHandler.post(new Runnable()
						{
							public void run()
							{
								Toast.makeText(context, "抱歉，目前尚無月刊資料", Toast.LENGTH_LONG).show();
							}
						});
					String file_Data = obj.getString("outputObject");
					JSONArray DataArray = new JSONArray(file_Data);
					speditor.putString("file_name",DataArray.getJSONObject(0).getString("file_1"));
					speditor.commit();
				} catch (Exception e) {}
			} catch (Exception e) {}
			super.run();
		}
	}

	void downloadAndOpenPDF(String FromURL) {

		Uri path; // = Uri.fromFile(FromURL.toString());

		path = Uri.parse ( download_file_url );

		try {
			Intent intent = new Intent(Intent.ACTION_VIEW);
			intent.setDataAndType(path, "application/pdf");
			intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
			intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
			intent = Intent.createChooser(intent, "Open File");
			startActivity(intent);
		} catch (ActivityNotFoundException e) {
			int i=0;
		}


		if (FromURL.equals( "backup" )) {
			DownloadTask downloadTask=new DownloadTask();
			downloadTask.execute( FromURL );
		}

	}

	class DownloadTask extends AsyncTask<String, Integer, String> {
		// ProgressDialog progressDialog;
		protected void onPreExecute(Void aVoid) {
			/*
			progressDialog = new ProgressDialog(MonthlyDetailActivity.this);
			progressDialog.setTitle( "In Progress..." );
			progressDialog.setProgressStyle( ProgressDialog.STYLE_HORIZONTAL  );
			progressDialog.setMax( 100 );
			progressDialog.setProgress( 0 );
			progressDialog.show();*/
		}

		@Override
		protected void onProgressUpdate(Integer... values) {
			super.onProgressUpdate( values );
			// progressDialog.setProgress( values[0] );
		}

		@Override
		protected void onPostExecute(String result) {
			super.onPostExecute( result );
			// progressDialog.hide();

			if (result.equals( "0" )){
				Toast.makeText( getApplicationContext(), "Download Fail", Toast.LENGTH_SHORT).show();
				return;
			}

			Uri path = Uri.parse(result);
			Toast.makeText( getApplicationContext(), "Download File: " + path.getPath().toString() , Toast.LENGTH_LONG).show();
			try {
				// How to open a PDF via Intent from SD card
				// https://www.tfzx.net/article/278156.html
				Intent intent = new Intent(Intent.ACTION_VIEW);
				intent.setDataAndType(path, "application/pdf");
				intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
				intent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
				intent = Intent.createChooser(intent, "Open File");
				intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				startActivity(intent);
			} catch (ActivityNotFoundException e) {
				int i=0;
			}
		}

		@Override
		protected String doInBackground(String... params) {
			String path = params[0];
			int file_length = 0;
			File input_file = null;
			try {
				URL url = new URL(path);
				URLConnection urlConnection = url.openConnection();
				urlConnection.connect();
				file_length = urlConnection.getContentLength();

				File SDCardRoot = Environment.getExternalStorageDirectory();
				input_file = new File( SDCardRoot  + "/" + dest_file_path);

				if (input_file.exists()){
					input_file.delete();
				}

				InputStream inputStream = new BufferedInputStream( url.openStream(),8192 );
				byte[] data = new byte[1024];
				int total = 0;
				int count = 0;
				OutputStream outputStream = new FileOutputStream( input_file );
				while ( (count = inputStream.read(data)) != -1 ){
					total += count;
					outputStream.write( data,0,count );
					int progress = (int)total*100/file_length;
					publishProgress( progress );
				}
				inputStream.close();
				outputStream.close();

			} catch (MalformedURLException e) {
				e.printStackTrace();
				return "0";
			} catch (IOException e) {
				e.printStackTrace();
				return "0";
			}
			// 傳回下載檔案的路徑
			return input_file.getPath().toString();
		}
	}


}