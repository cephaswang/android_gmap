package tw.tteia;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static tw.tteia.ConstantUtil.SERVER_NAME_WEB8;

public class MemberSecondActivity extends BaseActivity implements View.OnClickListener
{
	// 版面變數
	private Thread member_thread;
	private Context context = MemberSecondActivity.this;
	private GridView banner;
	private TableRow pagebar;
	private Button previouspage,nextpage;
	private ListView data_listview;
	private String city_name;
	private boolean isFirst=true;
	private List<Map<String, String>> datalistmap = new ArrayList<Map<String, String>>();
	private int page=1,max=0,mupMenuLng;
	// 工具列
	public String[] mupMenuNames = {};
	public String[] mupMenuIds = {};
	private Boolean[] mupMenuHover = {};

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_member_second);
		imw.nav_init();
		init_main();
		if (isInternetPresent == 0)
			alert_error();
		else {
			imw_thread = new api_getmenu();
			imw_thread.start();
		}
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		switch (keyCode)
		{
			case KeyEvent.KEYCODE_BACK:
				finish();
				break;
		}
		return true;
	}

	private void init_main()
	{
		data_listview = (ListView) findViewById(R.id.category_list);
		banner = (GridView) findViewById(R.id.category_gallery);
		pagebar = (TableRow) findViewById(R.id.pagebar);
		previouspage = (Button) findViewById(R.id.previouspage);
		previouspage.setOnClickListener(this);
		nextpage = (Button) findViewById(R.id.nextpage);
		nextpage.setOnClickListener(this);
	}

	private void createbanner() {
		DisplayMetrics dm = new DisplayMetrics();
		getWindowManager().getDefaultDisplay().getMetrics(dm);
		float density = dm.density;
		int length = mupMenuLng;
		int gridviewWidth = (int) (120 * length* density);
		int itemWidth = (int) (50 * density);
		LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
				gridviewWidth , LinearLayout.LayoutParams.FILL_PARENT);
		banner.setLayoutParams(params);
		banner.setColumnWidth(itemWidth);
		banner.setNumColumns(length);
		banner.setAdapter(new CategoryAdapter(maint));
		banner.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			public void onItemClick(AdapterView parent, View v, int position, long id) {
				for(int i=0;i<mupMenuLng;i++)
					mupMenuHover[i] = false;
				mupMenuHover[position] = true;
				banner.setAdapter(new CategoryAdapter(maint));
				data_listview.setAdapter(null);
				datalistmap.clear();
				city_name = mupMenuNames[position];
				page = 1;
				member_thread = new api_getmember();
				member_thread.start();
			}
		});
	}
	private void bannerinit(){
		mupMenuHover[0] = true;
		data_listview.setAdapter(null);
		datalistmap.clear();
		city_name = mupMenuNames[0];
		page = 1;
		member_thread = new api_getmember();
		member_thread.start();
	}

	private class api_getmenu extends Thread
	{
		@Override
		public void run()
		{
			String jsonURL = SERVER_NAME_WEB8 + "index.php?mode=get_county&areaid=" + sp.getString("first_id","");
			jsonConnect json_func = new jsonConnect();
			try
			{
				String requestJSON = json_func.getJson(jsonURL);
				try
				{
					JSONObject obj = new JSONObject(requestJSON);
					String status = obj.getString("status");
					if (status.equals("0"))
					{
						mHandler.post(new Runnable()
						{
							public void run()
							{
								Toast.makeText(context, "抱歉，目前尚無資料", Toast.LENGTH_LONG).show();
							}
						});
					}
					String menu_data = obj.getString("outputObject");
					JSONArray DataArray = new JSONArray(menu_data);
					mupMenuLng = DataArray.length();
					if(isFirst)
						mupMenuHover = new Boolean[mupMenuLng];
					mupMenuIds = new String[mupMenuLng];
					mupMenuNames = new String[mupMenuLng];
					for (int i = 0; i < DataArray.length(); i++)
					{
						if(isFirst)
							mupMenuHover[i] = false;
						mupMenuIds[i]=DataArray.getJSONObject(i).getString("id");
						mupMenuNames[i]=DataArray.getJSONObject(i).getString("type_name");
					}
				} catch (Exception e) {}
			} catch (Exception e) {}
			mHandler.post(new Runnable()
			{
				public void run()
				{
					if(isFirst){
						bannerinit();
						isFirst=false;
					}
					createbanner();
				}
			});
			super.run();
		}
	}

	private class api_getmember extends Thread
	{
		@Override
		public void run()
		{
			String jsonURL = SERVER_NAME_WEB8 + "index.php?mode=get_user_data_list&city=" + city_name + "&page=" + page;
			jsonConnect json_func = new jsonConnect();
			try
			{
				String requestJSON = json_func.getJson(jsonURL);
				try
				{
					JSONObject obj = new JSONObject(requestJSON);
					String status = obj.getString("status");
					if (status.equals("0"))
					{
						mHandler.post(new Runnable()
						{
							public void run()
							{
								Toast.makeText(context, "抱歉，目前尚無會員資料", Toast.LENGTH_LONG).show();
							}
						});
					}
					max = Integer.parseInt(obj.getString("maxCount"));
					String product_data = obj.getString("outputObject");
					JSONArray DataArray = new JSONArray(product_data);
					for (int i = 0; i < DataArray.length(); i++)
					{
						HashMap<String, String> memberData = new HashMap<String, String>();
						memberData.put("id", DataArray.getJSONObject(i).getString("id"));
						memberData.put("company_name", DataArray.getJSONObject(i).getString("company_name"));
						memberData.put("tel_1", DataArray.getJSONObject(i).getString("tel_1"));
						memberData.put("address", DataArray.getJSONObject(i).getString("address"));
						datalistmap.add(memberData);
					}
				} catch (Exception e) {}
			} catch (Exception e) {}
			mHandler.post(new Runnable() {
				public void run()
				{
					if(page==1)
						previouspage.setVisibility(View.GONE);
					else
						previouspage.setVisibility(View.VISIBLE);
					if(page*30>=max)
						nextpage.setVisibility(View.GONE);
					else
						nextpage.setVisibility(View.VISIBLE);
					if(page==1&&page*30>=max)
						pagebar.setVisibility(View.GONE);
					else
					pagebar.setVisibility(View.VISIBLE);
					datalist_init(datalistmap);
				}
			});
			super.run();
		}
	}

	private void datalist_init(final List<Map<String, String>> listmap)
	{
		data_listview = (ListView) findViewById(R.id.category_list);
		data_listview.setAdapter(new BaseAdapter() {
			@Override
			public View getView(final int position, View convertView, ViewGroup parent) {
				View view = getLayoutInflater().inflate(R.layout.member_second_listview, null);
				TextView name = (TextView) view.findViewById(R.id.name);
				name.setText(listmap.get(position).get("company_name"));
				String address = listmap.get(position).get("address");
				TextView list_name = (TextView) view.findViewById(R.id.address);
				list_name.setText(address);
				String tel = listmap.get(position).get("tel_1");
				TextView list_price = (TextView) view.findViewById(R.id.tel);
				list_price.setText(tel);
				return view;
			}
			@Override
			public long getItemId(int position) {
				return Integer.parseInt(listmap.get(position).get("id"));
			}

			@Override
			public Object getItem(int position) {
				return listmap.get(position);
			}

			@Override
			public int getCount() {
				return listmap.size();
			}
		});
		data_listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				try {
					speditor.putString("detail_id", String.valueOf(id));
					speditor.putString("detail_name", listmap.get(position).get("company_name"));
					speditor.commit();
					Intent imenu = new Intent(maint, MemberDetailActivity.class);
					imenu.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(imenu);
				} catch (Exception e) {}
			}
		});
		if (listmap.size() == 0)
		{
			nextpage.setVisibility(View.GONE);
			Toast.makeText(context, "抱歉，目前尚無資料", Toast.LENGTH_LONG).show();
		}
	}
	private void alert_error()
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("連線錯誤");
		builder.setMessage("連線發生錯誤，請確認您的網路狀態。").setCancelable(false)
				.setPositiveButton("確定", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.dismiss();
						finish();
					}
				});
		AlertDialog alert = builder.create();
		alert.show();
	}

	private class CategoryAdapter extends BaseAdapter
	{
		private Context mContext;
		public CategoryAdapter(Context context)
		{
			mContext = context;
		}
		public int getCount()
		{
			return mupMenuLng;
		}
		public Object getItem(int position)
		{
			return mupMenuNames[position];
		}
		public long getItemId(int position)
		{
			return position;
		}
		public View getView(int position, View convertView, ViewGroup parent)
		{
			View view = getLayoutInflater().inflate(R.layout.gallery_menu_type, null);
			String name = mupMenuNames[position];
			TextView gallery_name = (TextView) view.findViewById(R.id.gallery_name);
			gallery_name.setText(name);
			return view;
		}
	}
	@Override
	public void onClick(View v)
	{
		switch (v.getId())
		{
			case R.id.previouspage:
				data_listview.setAdapter(null);
				datalistmap.clear();
				page-=1;
				imw_thread =new api_getmember();
				imw_thread.start();
				break;
			case R.id.nextpage:
				data_listview.setAdapter(null);
				datalistmap.clear();
				page+=1;
				member_thread =new api_getmember();
				member_thread.start();
				break;
		}
	}
}