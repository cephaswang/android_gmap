package tw.tteia;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static tw.tteia.ConstantUtil.SERVER_NAME_WEB8;

public class SearchActivity extends BaseActivity implements View.OnClickListener
{
	private Button search,clear;
	private Spinner spinner_city,spinner_district;
	private Context context = SearchActivity.this;
	private String[] citys = {"請選擇","台北市","基隆市","新北市","連江縣","宜蘭縣","釣魚臺","新竹市","新竹縣","桃園市",
			"苗栗縣","台中市","彰化縣","南投縣","嘉義市","嘉義縣","雲林縣","台南市","高雄市","南海島",
			"澎湖縣","金門縣","屏東縣","台東縣","花蓮縣"};
	private String[] districts = {};
	private ArrayAdapter listAdapter,nameAdapter;
	private EditText edit_keyword;
	private String keyword;
	private int select_city=0,select_district=0;
	private ListView data_listview;
	private List<Map<String, String>> datalistmap = new ArrayList<Map<String, String>>();

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_null);
		setContentView(R.layout.activity_search);
		imw.nav_init();
		initmain();
		if (isInternetPresent == 0)
			alert_error();
		else{
			spinner_city = (Spinner) findViewById(R.id.spinner_city);
			spinner_district = (Spinner) findViewById(R.id.spinner_district);
			listAdapter = new ArrayAdapter(SearchActivity.this,R.layout.spinnerlayout,citys);
			listAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
			spinner_city.setAdapter(listAdapter);
			//設定當kind spinner item選取後的動作
			spinner_city.setOnItemSelectedListener(spinnerlistener);
		}
	}

	private void initmain()
	{
		// 隱藏鍵盤
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
		// 送出資料
		edit_keyword = (EditText) findViewById(R.id.keyword);
		search = (Button) findViewById(R.id.search);
		search.setOnClickListener(this);
		clear = (Button) findViewById(R.id.clear);
		clear.setOnClickListener(this);
		data_listview = (ListView) findViewById(R.id.category_list);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		switch (keyCode)
		{
			case KeyEvent.KEYCODE_BACK:
				finish();
				return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	AdapterView.OnItemSelectedListener spinnerlistener = new AdapterView.OnItemSelectedListener() {
		@Override
		public void onItemSelected(AdapterView adapterView, View view, int position, long id) {
			//當選取的spinner是kind時
			if (adapterView.getId() == R.id.spinner_city) {
				//判斷選取的種類是何種，設定相對應的字串陣列內容
				select_city = position;
				switch (select_city){
					case 0:
						districts = new String[]{"請選擇"};
						break;
					case 1:
						districts = new String[]{"請選擇","中正區","大同區","中山區","松山區","大安區","萬華區","信義區","士林區","北投區",
								"內湖區","南港區","文山區"};
						break;
					case 2:
						districts = new String[]{"請選擇","仁愛區","信義區","中正區","中山區","安樂區","暖暖區","七堵區"};
						break;
					case 3:
						districts = new String[]{"請選擇","萬里區","金山區","板橋區","汐止區","深坑區","石碇區","瑞芳區","平溪區","雙溪區",
								"貢寮區","新店區","坪林區","烏來區","永和區","中和區","土城區","三峽區","樹林區","鶯歌區",
								"三重區","新莊區","泰山區","林口區","蘆洲區","五股區","八里區","淡水區","三芝區","石門區"};
						break;
					case 4:
						districts = new String[]{"請選擇","南竿鄉","北竿鄉","莒光鄉","東引鄉"};
						break;
					case 5:
						districts = new String[]{"請選擇","宜蘭市","壯圍鄉","頭城鎮","礁溪鄉","員山鄉","羅東鎮","三星鄉","大同鄉","五結鄉",
								"冬山鄉","蘇澳鎮","南澳鄉","釣魚臺"};
						break;
					case 6:
						districts = new String[]{"請選擇","釣魚臺"};
						break;
					case 7:
						districts = new String[]{"請選擇","東區","北區","香山區"};
						break;
					case 8:
						districts = new String[]{"請選擇","寶山鄉","竹北市","湖口鄉","新豐鄉","新埔鎮","關西鎮","芎林鄉","竹東鎮","五峰鄉",
								"橫山鄉","尖石鄉","北埔鄉","峨眉鄉"};
						break;
					case 9:
						districts = new String[]{"請選擇","中壢區","平鎮區","龍潭區","楊梅區","新屋區","觀音區","桃園區","龜山區","八德區",
								"大溪區","復興區","大園區","蘆竹區"};
						break;
					case 10:
						districts = new String[]{"請選擇","竹南鎮","頭份市","三灣鄉","南庄鄉","獅潭鄉","後龍鎮","通霄鎮","苑裡鎮","苗栗市",
								"造橋鄉","頭屋鄉","公館鄉","大湖鄉","泰安鄉","銅鑼鄉","三義鄉","西湖鄉","卓蘭鎮"};
						break;
					case 11:
						districts = new String[]{"請選擇","中區","東區","南區","西區","北區","北屯區","西屯區","南屯區","太平區",
								"大里區","霧峰區","烏日區","豐原區","后里區","石岡區","東勢區","和平區","新社區","潭子區",
								"大雅區","神岡區","大肚區","沙鹿區","龍井區","梧棲區","清水區","大甲區","外埔區","大安區"};
						break;
					case 12:
						districts = new String[]{"請選擇","彰化市","芬園鄉","花壇鄉","秀水鄉","鹿港鎮","福興鄉","線西鄉","和美鎮","伸港鄉",
								"員林市","社頭鄉","永靖鄉","埔心鄉","溪湖鎮","大村鄉","埔鹽鄉","田中鎮","北斗鎮","田尾鄉",
								"埤頭鄉","溪州鄉","竹塘鄉","二林鎮","大城鄉","芳苑鄉","二水鄉"};
						break;
					case 13:
						districts = new String[]{"請選擇","南投市","中寮鄉","草屯鎮","國姓鄉","埔里鎮","仁愛鄉","名間鄉","集集鎮","水里鄉",
								"魚池鄉","信義鄉","竹山鎮","鹿谷鄉"};
						break;
					case 14:
						districts = new String[]{"請選擇","西區","東區"};
						break;
					case 15:
						districts = new String[]{"請選擇","番路鄉","梅山鄉","竹崎鄉","阿里山鄉","中埔鄉","大埔鄉","水上鄉","鹿草鄉","太保市",
								"朴子市","東石鄉","六腳鄉","新港鄉","民雄鄉","大林鎮","溪口鄉","義竹鄉","布袋鎮"};
						break;
					case 16:
						districts = new String[]{"請選擇","斗南鎮","大埤鄉","虎尾鎮","土庫鎮","褒忠鄉","東勢鄉","臺西鄉","崙背鄉","麥寮鄉",
								"斗六市","林內鄉","古坑鄉","莿桐鄉","西螺鎮","二崙鄉","北港鎮","水林鄉","口湖鄉","四湖鄉",
								"元長鄉"};
						break;
					case 17:
						districts = new String[]{"請選擇","中西區","東區","南區","北區","安平區","安南區","永康區","歸仁區","新化區",
								"左鎮區","玉井區","楠西區","南化區","仁德區","關廟區","龍崎區","官田區","麻豆區","佳里區",
								"西港區","七股區","將軍區","學甲區","北門區","新營區","後壁區","白河區","東山區","六甲區",
								"下營區","柳營區","鹽水區","善化區","新市區","大內區","山上區","安定區"};
						break;
					case 18:
						districts = new String[]{"請選擇","新興區","前金區","苓雅區","鹽埕區","鼓山區","旗津區","前鎮區","三民區","楠梓區",
								"小港區","左營區","仁武區","大社區","東沙群島","南沙群島","岡山區","路竹區","阿蓮區","田寮區",
								"燕巢區","橋頭區","梓官區","彌陀區","永安區","湖內區","鳳山區","大寮區","林園區","鳥松區",
								"大樹區","旗山區","美濃區","六龜區","內門區","杉林區","甲仙區","桃源區","那瑪夏區","茂林區",
								"茄萣區"};
						break;
					case 19:
						districts = new String[]{"請選擇","東沙群島","南沙群島"};
						break;
					case 20:
						districts = new String[]{"請選擇","馬公市","西嶼鄉","望安鄉","七美鄉","白沙鄉","湖西鄉"};
						break;
					case 21:
						districts = new String[]{"請選擇","金沙鎮","金湖鎮","金寧鄉","金城鎮","烈嶼鄉","烏坵鄉"};
						break;
					case 22:
						districts = new String[]{"請選擇","屏東市","三地門鄉","霧臺鄉","瑪家鄉","九如鄉","里港鄉","高樹鄉","鹽埔鄉","長治鄉",
								"麟洛鄉","竹田鄉","內埔鄉","萬丹鄉","潮州鎮","泰武鄉","來義鄉","萬巒鄉","崁頂鄉","新埤鄉",
								"南州鄉","林邊鄉","東港鎮","琉球鄉","佳冬鄉","新園鄉","枋寮鄉","枋山鄉","春日鄉","獅子鄉",
								"車城鄉","牡丹鄉","恆春鎮","滿州鄉"};
						break;
					case 23:
						districts = new String[]{"請選擇","臺東市","綠島鄉","蘭嶼鄉","延平鄉","卑南鄉","鹿野鄉","關山鎮","海端鄉","池上鄉",
								"東河鄉","成功鎮","長濱鄉","太麻里鄉","金峰鄉","大武鄉","達仁鄉"};
						break;
					case 24:
						districts = new String[]{"請選擇","花蓮市","新城鄉","秀林鄉","吉安鄉","壽豐鄉","鳳林鎮","光復鄉","豐濱鄉","瑞穗鄉",
								"萬榮鄉","玉里鎮","卓溪鄉","富里鄉"};
						break;
				}
				nameAdapter = new ArrayAdapter(SearchActivity.this, R.layout.spinnerlayout, districts);
				nameAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
				spinner_district.setAdapter(nameAdapter);
				spinner_district.setOnItemSelectedListener(spinnerlistener);
			}
			if (adapterView.getId() == R.id.spinner_district) {
				//判斷選取的種類是何種，設定相對應的字串陣列內容
				select_district = position;
			}
		}
		@Override
		public void onNothingSelected(AdapterView arg0) {}
	};

	private class api_getsearch extends Thread
	{
		@Override
		public void run()
		{
			String jsonURL;
			if(select_city == 0 && select_district == 0)
				jsonURL = SERVER_NAME_WEB8 + "index.php?mode=get_user_search&city=&area=&keyword=" + keyword;
			else if (select_city == 0)
				jsonURL = SERVER_NAME_WEB8 + "index.php?mode=get_user_search&city=&area=" + districts[select_district] + "&keyword=" + keyword;
			else if (select_district == 0)
				jsonURL = SERVER_NAME_WEB8 + "index.php?mode=get_user_search&city="+ citys[select_city] + "&area=&keyword=" + keyword;
			else
				jsonURL = SERVER_NAME_WEB8 + "index.php?mode=get_user_search&city="+ citys[select_city] + "&area=" + districts[select_district] + "&keyword=" + keyword;
			jsonConnect json_func = new jsonConnect();
			try
			{
				String requestJSON = json_func.getJson(jsonURL);
				try
				{
					JSONObject obj = new JSONObject(requestJSON);
					String status = obj.getString("status");
					if (status.equals("0"))
						mHandler.post(new Runnable()
						{
							public void run()
							{
								Toast.makeText(context, "抱歉，目前尚無會員資料", Toast.LENGTH_LONG).show();
							}
						});
					String product_data = obj.getString("outputObject");
					JSONArray DataArray = new JSONArray(product_data);
					for (int i = 0; i < DataArray.length(); i++)
					{
						HashMap<String, String> memberData = new HashMap<String, String>();
						memberData.put("id", DataArray.getJSONObject(i).getString("id"));
						memberData.put("company_name", DataArray.getJSONObject(i).getString("company_name"));
						memberData.put("tel_1", DataArray.getJSONObject(i).getString("tel_1"));
						memberData.put("address", DataArray.getJSONObject(i).getString("address"));
						datalistmap.add(memberData);
					}
				} catch (Exception e) {}
			} catch (Exception e) {}
			mHandler.post(new Runnable() {
				public void run()
				{
					datalist_init(datalistmap);
				}
			});
			super.run();
		}
	}

	private void datalist_init(final List<Map<String, String>> listmap)
	{
		data_listview.setAdapter(new BaseAdapter() {
			@Override
			public View getView(final int position, View convertView, ViewGroup parent) {
				View view = getLayoutInflater().inflate(R.layout.member_second_listview, null);
				TextView name = (TextView) view.findViewById(R.id.name);
				name.setText(listmap.get(position).get("company_name"));
				TextView address = (TextView) view.findViewById(R.id.address);
				address.setText(listmap.get(position).get("address"));
				TextView tel = (TextView) view.findViewById(R.id.tel);
				tel.setText(listmap.get(position).get("tel_1"));
				return view;
			}
			@Override
			public long getItemId(int position) {
				return Integer.parseInt(listmap.get(position).get("id"));
			}
			@Override
			public Object getItem(int position) {
				return listmap.get(position);
			}
			@Override
			public int getCount() {
				return listmap.size();
			}
		});
		data_listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				try {
					speditor.putString("detail_id", String.valueOf(id));
					speditor.putString("detail_name", listmap.get(position).get("company_name"));
					speditor.commit();
					Intent imenu = new Intent(maint, MemberDetailActivity.class);
					imenu.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(imenu);
				} catch (Exception e) {}
			}
		});
		if (listmap.size() == 0)
			Toast.makeText(context, "抱歉，目前尚無資料", Toast.LENGTH_LONG).show();
	}

	private void alert_error()
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("連線錯誤");
		builder.setMessage("連線發生錯誤，請確認您的網路狀態。").setCancelable(false)
				.setPositiveButton("確定", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.dismiss();
					}
				});
		AlertDialog alert = builder.create();
		alert.show();
	}

	@Override
	public void onClick(View v)
	{
		switch (v.getId())
		{
			case R.id.search:
				data_listview.setAdapter(null);
				datalistmap.clear();
				try
				{
					keyword = edit_keyword.getText().toString();
					imw_thread = new api_getsearch();
					imw_thread.start();
				} catch (Exception e)
				{
					Toast.makeText(maint, "搜尋錯誤", Toast.LENGTH_LONG).show();
				}
				break;
			case R.id.clear:
				data_listview.setAdapter(null);
				edit_keyword.setText("");
				spinner_city.setSelection(0);
				spinner_district.setSelection(0);
				break;
		}
	}
}