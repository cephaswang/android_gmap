package tw.tteia;

import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Criteria;
import android.location.GpsStatus;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.location.LocationProvider;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static tw.tteia.ConstantUtil.SERVER_NAME_WEB8;

public class NearbyActivity extends Activity implements OnMapReadyCallback {
    private int max=0;
    private LatLng OUTPUT[];
    private MarkerOptions markerOpt[];
    private GoogleMap mMap;
    private List<Map<String, String>> datalistmap = new ArrayList<Map<String, String>>();
    private Context context = NearbyActivity.this;
    public Thread imw_thread;
    private Handler mHandler = new Handler();
    private TextView current;
    private Marker markerMe;
    /** GPS */
    private LocationManager locationMgr;
    private String provider;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nearby);
        OUTPUT = new LatLng[2000];
        markerOpt = new MarkerOptions[2000];
        imw_thread = new api_getaddress();
        imw_thread.start();
    }
    @Override
    public void onMapReady(GoogleMap map) {
        // DO WHATEVER YOU WANT WITH GOOGLEMAP
        map.setMapType(GoogleMap.MAP_TYPE_HYBRID);
        map.setMyLocationEnabled(true);
        map.setTrafficEnabled(true);
        map.setIndoorEnabled(true);
        map.setBuildingsEnabled(true);
        map.getUiSettings().setZoomControlsEnabled(true);
    }
    @Override
    protected void onStop() {
        locationMgr.removeUpdates(locationListener);
        super.onStop();
    }
    private boolean initLocationProvider() {
       locationMgr = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
        //1.選擇最佳提供器
		Criteria criteria = new Criteria();
		criteria.setAccuracy(Criteria.ACCURACY_FINE);
		criteria.setAltitudeRequired(false);
		criteria.setBearingRequired(false);
		criteria.setCostAllowed(true);
		criteria.setPowerRequirement(Criteria.POWER_LOW);
		provider = locationMgr.getBestProvider(criteria, true);
		if (provider != null) {
			return true;
		}
        //選擇使用網路提供器
        if (locationMgr.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
            provider = LocationManager.NETWORK_PROVIDER;
            return true;
        }
        //選擇使用GPS提供器
        if (locationMgr.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
            provider = LocationManager.GPS_PROVIDER;
            return true;
        }
        return false;
    }
    /**
     * 執行"我"在哪裡
     * 1.建立位置改變偵聽器
     * 2.預先顯示上次的已知位置
     */
    private void whereAmI(){
        if ( Build.VERSION.SDK_INT >= 23 &&
                ContextCompat.checkSelfPermission( context, android.Manifest.permission.ACCESS_FINE_LOCATION ) != PackageManager.PERMISSION_GRANTED &&
                ContextCompat.checkSelfPermission( context, android.Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            return  ;
        }
        //取得上次已知的位置
        Location location = locationMgr.getLastKnownLocation(provider);
        updateWithNewLocation(location);
        //GPS Listener
        locationMgr.addGpsStatusListener(gpsListener);
        //Location Listener
        long minTime = 5000;//ms
        float minDist = 5.0f;//meter
        locationMgr.requestLocationUpdates(provider, minTime, minDist, locationListener);
    }

    private void showMarkerMe(final double lat, final double lng){
        if (markerMe != null) {
            markerMe.remove();
        }
        mMap = ((MapFragment)getFragmentManager().findFragmentById(R.id.map)).getMap();
    //    MapFragment mapFragment = (MapFragment) getFragmentManager()
    //            .findFragmentById(R.id.map);

    //    mapFragment.getMapAsync(this);

        current = (TextView)findViewById(R.id.current_position);
        current.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(lat, lng), 15));
            }
        });
        MarkerOptions markerOpt = new MarkerOptions();
        markerOpt.position(new LatLng(lat, lng));
        markerOpt.title("目前位置");
        markerOpt.snippet("經度：" + lat + " 緯度：" + lng);
        markerOpt.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_VIOLET));
        markerMe = mMap.addMarker(markerOpt);
    }

    private void cameraFocusOnMe(double lat, double lng){
        CameraPosition camPosition = new CameraPosition.Builder()
                .target(new LatLng(lat, lng))
                .zoom(16)
                .build();
        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(camPosition));
    }

    /**
     * 更新並顯示新位置
     * @param location
     */
    private void updateWithNewLocation(Location location) {
        if (location != null) {
            //經度
            double lng = location.getLongitude();
            //緯度
            double lat = location.getLatitude();
            //標記"我"
            showMarkerMe(lat, lng);
            cameraFocusOnMe(lat, lng);
        }
    }

    GpsStatus.Listener gpsListener = new GpsStatus.Listener() {

        @Override
        public void onGpsStatusChanged(int event) {
            switch (event) {
                case GpsStatus.GPS_EVENT_STARTED:
                    Toast.makeText(NearbyActivity.this, "開始接收目前位置", Toast.LENGTH_SHORT).show();
                    break;
                case GpsStatus.GPS_EVENT_STOPPED:
                    Toast.makeText(NearbyActivity.this, "GPS收不到訊號！", Toast.LENGTH_SHORT).show();
                    break;
                case GpsStatus.GPS_EVENT_FIRST_FIX:
                    break;
                case GpsStatus.GPS_EVENT_SATELLITE_STATUS:
                   Toast.makeText(NearbyActivity.this, "GPS收不到訊號！", Toast.LENGTH_SHORT).show();
                    break;
            }
        }
    };

    LocationListener locationListener = new LocationListener(){
        @Override
        public void onLocationChanged(Location location) {
            updateWithNewLocation(location);
        }
        @Override
        public void onProviderDisabled(String provider) {
            updateWithNewLocation(null);
        }
        @Override
        public void onProviderEnabled(String provider) {}
        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {
            switch (status) {
                case LocationProvider.OUT_OF_SERVICE:
                    break;
                case LocationProvider.TEMPORARILY_UNAVAILABLE:
                    break;
                case LocationProvider.AVAILABLE:
                    break;
            }
        }
    };

    private class api_getaddress extends Thread
    {
        @Override
        public void run()
        {
            String jsonURL = SERVER_NAME_WEB8 + "index.php?mode=map_list";
            jsonConnect json_func = new jsonConnect();
            try
            {
                String requestJSON = json_func.getJson(jsonURL);
                try
                {
                    JSONObject obj = new JSONObject(requestJSON);
                    String status = obj.getString("status");
                    if (status.equals("1")) {
                        String nearby_data = obj.getString("outputObject");
                        JSONArray DataArray = new JSONArray(nearby_data);
                        max = DataArray.length();
                        for (int i = 0; i < max; i++) {
                            HashMap<String, String> nearbyData = new HashMap<String, String>();
                            nearbyData.put("id", DataArray.getJSONObject(i).getString("id"));
                            nearbyData.put("name", DataArray.getJSONObject(i).getString("name"));
                            nearbyData.put("company_name", DataArray.getJSONObject(i).getString("company_name"));
                            nearbyData.put("address", DataArray.getJSONObject(i).getString("address"));
                            nearbyData.put("tel_1", DataArray.getJSONObject(i).getString("tel_1"));
                            nearbyData.put("fax", DataArray.getJSONObject(i).getString("fax"));
                            nearbyData.put("lat", DataArray.getJSONObject(i).getString("lat"));
                            nearbyData.put("lng", DataArray.getJSONObject(i).getString("lng"));
                            datalistmap.add(nearbyData);
                        }
                    }
                } catch (Exception e) {}
            } catch (Exception e) {}
            mHandler.post(new Runnable() {
                public void run() {
                    initMap(datalistmap);
                    if (initLocationProvider())
                        whereAmI();
                    else
                        Toast.makeText(NearbyActivity.this, "請開啟定位!", Toast.LENGTH_SHORT).show();
                }
            });
            super.run();
        }
    }

    private void initMap(final List<Map<String, String>> listmap){
        if (mMap == null) {
            GoogleMap mMap = ((MapFragment)getFragmentManager().findFragmentById(R.id.map)).getMap();
        //    MapFragment mapFragment = (MapFragment) getFragmentManager()
        //           .findFragmentById(R.id.map);

        //    mapFragment.getMapAsync(this);
            if (mMap != null) {
                mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                for(int i=0;i<max;i++){
                    OUTPUT[i] = new LatLng(Double.parseDouble(listmap.get(i).get("lat")), Double.parseDouble(listmap.get(i).get("lng")));
                    markerOpt[i] = new MarkerOptions();
                    markerOpt[i].position(OUTPUT[i]);
                    markerOpt[i].title(listmap.get(i).get("company_name"));
                    markerOpt[i].snippet(listmap.get(i).get("address"));
                    mMap.addMarker(markerOpt[i]);
                }
            }
        }
    }

}

