package tw.tteia;

import android.util.Log;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntity;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HTTP;
import org.apache.http.protocol.HttpContext;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.util.List;

public class jsonConnect
{
	public String getJson(String url)
	{
		// 這邊所接進來的url是撈JSON的那個網址
		// 宣告一個String來存放等等撈到的資料
		String result = "";
		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost(url);
		HttpResponse response;
		try
		{
			response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			InputStream is = entity.getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf8"), 9999999);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null)
			{
				sb.append(line + "\n");
			}
			is.close();
			result = sb.toString();
		} catch (ClientProtocolException e)
		{
			e.printStackTrace();
		} catch (IOException e)
		{
			e.printStackTrace();
		}
		return result;
	}

	public String getjson(String url, List<NameValuePair> postParams)
	{
		// 這邊所接進來的url是撈JSON的那個網址
		// 宣告一個String來存放等等撈到的資料
		String result = "";
		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost(url);
		HttpResponse response;
		try
		{
			for (int index = 0; index < postParams.size(); index++)
			{
				Log.e(postParams.get(index).getName(), postParams.get(index).getValue());
			}
			httppost.setEntity(new UrlEncodedFormEntity(postParams, HTTP.UTF_8));
			response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			InputStream is = entity.getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf8"), 9999999);
			StringBuilder sb = new StringBuilder();
			String line = null;

			while ((line = reader.readLine()) != null)
			{
				sb.append(line + "\n");
			}
			is.close();
			result = sb.toString();
		} catch (ClientProtocolException e)
		{
			e.printStackTrace();
		} catch (IOException e)
		{
			e.printStackTrace();
		}
		return result;
	}

	public String getjson(String url, List<NameValuePair> postParams, File file)
	{
		// 這邊所接進來的url是撈JSON的那個網址
		// 宣告一個String來存放等等撈到的資料
		Log.d("getJson : ", "Running");
		Log.d("getJson : ", "url => " + url);
		String result = "";
		HttpClient httpclient = new DefaultHttpClient();
		HttpContext localContext = new BasicHttpContext();
		HttpPost httppost = new HttpPost(url);
		try
		{
			MultipartEntity entity=new MultipartEntity(HttpMultipartMode.BROWSER_COMPATIBLE);
			
			Log.v(file.getName(), file.getPath());
			entity.addPart("file", new FileBody(file));
			for (int index = 0; index < postParams.size(); index++)
			{
				Log.v(postParams.get(index).getName(), postParams.get(index).getValue());
				StringBody body = new StringBody(postParams.get(index).getValue(), Charset.forName("UTF-8"));
				entity.addPart(postParams.get(index).getName(), body);
			} 
			httppost.setEntity(entity);
			HttpResponse response = httpclient.execute(httppost, localContext);
			HttpEntity resEntity = response.getEntity();
			result = EntityUtils.toString(resEntity);

		} catch (ClientProtocolException e)
		{
			Log.e("getJson : ", Log.getStackTraceString(e));
		} catch (IOException e)
		{
			Log.e("getJson : ", Log.getStackTraceString(e));
		} catch (Exception e)
		{
			Log.e("getJson : ", Log.getStackTraceString(e));
		}
		return result;
	}

	public String sendjson(String url, JSONObject jsonObject)
	{
		// 這邊所接進來的url是撈JSON的那個網址
		// 宣告一個String來存放等等撈到的資料
		String result = "";
		HttpClient httpclient = new DefaultHttpClient();
		HttpPost httppost = new HttpPost(url);
		HttpResponse response;
		try
		{
			httppost.setEntity(new StringEntity(jsonObject.toString(), HTTP.UTF_8));
			httppost.setHeader("Accept", "application/json");
			httppost.setHeader("Content-type", "application/json");
			response = httpclient.execute(httppost);
			HttpEntity entity = response.getEntity();
			InputStream is = entity.getContent();
			BufferedReader reader = new BufferedReader(new InputStreamReader(is, "utf8"), 9999999);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null)
			{
				sb.append(line + "\n");
			}
			is.close();
			result = sb.toString();
		} catch (ClientProtocolException e)
		{
			e.printStackTrace();
		} catch (IOException e)
		{
			e.printStackTrace();
		}
		return result;
	}
}