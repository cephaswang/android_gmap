package tw.tteia;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.Window;

import org.json.JSONObject;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;

import imw.imw_core;

import static tw.tteia.ConstantUtil.DBNAME_PATH;
import static tw.tteia.ConstantUtil.FILE_TXT;
import static tw.tteia.ConstantUtil.SERVER_NAME_WEB8;

public class BaseActivity extends Activity
{
	public static int flag;
	// 背景執行程序
	public Thread imw_thread;
	public Handler mHandler = new Handler();
	// xid 設定
	private static final int READ_BLOCK_SIZE = 100;
	public String fnamexid = FILE_TXT;
	public static LiteDatabase mydb;
	public String xid = "";
	public Activity mContext;
	static Context maint;
	public imw_core imw;

	// 活動訊息
	public static int [] NEWS_range = new int[2];
	// 會務報導
	public static int [] RPTS_range = new int[2];
	// 招標訊息
	public static int [] BIDD_range = new int[2];
	// 教育訓練
	public static int [] EDUS_range = new int[2];


	// 資料讀取元件
	public ProgressDialog mypDialog;
	// 連線測試
	public int isInternetPresent = 0;
	// 設定介面
	public SharedPreferences sp;
	public SharedPreferences.Editor speditor;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_base);
		mContext = this;
		maint = this;
		imw = new imw_core(this);

		// 建立 CONFIG 的資料檔
		sp = imw.get_sp();
		speditor = imw.get_speditor();
		
		//檢查使用者
		if ((sp.getString("username", "")).equals("")){
			imw.isNeedLogin();
		}
		else check_relogin();
		// 檢查網路狀態
		isInternetPresent = imw.get_network_state();
		// 建立XID
		tw.tteia.DeviceUuidFactory uuid1 = new tw.tteia.DeviceUuidFactory(mContext);
		xid = uuid1.getDeviceUuid().toString();
	}


	private void check_relogin()
	{
		imw_thread = new check_relogin();
		imw_thread.start();
	}

	public void getxid()
	{
		try
		{
			FileInputStream in = openFileInput(fnamexid);
			InputStreamReader sr = new InputStreamReader(in);
			char[] buffer = new char[READ_BLOCK_SIZE];
			int count;
			xid = "";
			while ((count = sr.read(buffer)) > 0)
			{
				String s = String.copyValueOf(buffer, 0, count);
				xid += s;
				buffer = new char[READ_BLOCK_SIZE];
			}
			sr.close();
		} catch (IOException ex) {}
	}

	public void weburlchange(String url, int titleint, Boolean hadParam)
	{
		weburlchange(url, titleint, hadParam);
	}

	public static LiteDatabase getMydb()
	{
		mydb = new LiteDatabase(maint, DBNAME_PATH);
		return mydb;
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		switch (keyCode)
		{
		case KeyEvent.KEYCODE_BACK:
			imw.backMain();
			break;
		default:
			break;
		}
		return super.onKeyDown(keyCode, event);
	}
	private class check_relogin extends Thread
	{
		@Override
		public void run()
		{
			String xid = sp.getString("xid", "");
			String jsonURL = SERVER_NAME_WEB8 + "index.php?mode=get&xid=" + xid;
			tw.tteia.jsonConnect json_func = new tw.tteia.jsonConnect();
			try
			{
				String requestJSON = json_func.getJson(jsonURL);
				try
				{
					JSONObject obj = new JSONObject(requestJSON);
					String status = obj.getString("status");
					if (status.equals("0"))
						mHandler.post(new Runnable()
						{
							public void run()
							{
								speditor.putString("username","");
								speditor.commit();
							}
						});
				} catch (Exception e) {}
			} catch (Exception e) {}
			super.run();
		}
	}

	private void alert_login()
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("登入錯誤");
		builder.setMessage("登入發生錯誤，此帳號已從其他裝置登入。").setCancelable(false)
				.setPositiveButton("確定", new DialogInterface.OnClickListener()
				{
					public void onClick(DialogInterface dialog, int id)
					{
						speditor.putString("username","");
						speditor.commit();
						imw.isNeedLogin();
						dialog.dismiss();
					}
				});
		AlertDialog alert = builder.create();
		alert.show();
	}
}