package tw.tteia;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static tw.tteia.ConstantUtil.SERVER_NAME_WEB8;

public class OtheruserActivity extends BaseActivity implements View.OnClickListener
{
	private Context context = OtheruserActivity.this;
	private Button search,clear;
	private Spinner spinner_city;
	private int select_city=0;
	private ArrayAdapter listAdapter;
	private ListView data_listview;
	private String[] citys = {"請選擇","台北市","基隆市","新北市","連江縣","宜蘭縣","釣魚臺","新竹市","新竹縣","桃園市",
			"苗栗縣","台中市","彰化縣","南投縣","嘉義市","嘉義縣","雲林縣","台南市","高雄市","南海島",
			"澎湖縣","金門縣","屏東縣","台東縣","花蓮縣"};
	private List<Map<String, String>> datalistmap = new ArrayList<Map<String, String>>();
	public Thread imw_thread;
	private Handler mHandler = new Handler();
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_null);
		setContentView(R.layout.activity_otheruser);
		imw.nav_init();
		initmain();
		if (isInternetPresent == 0)
			Toast.makeText(context, "無法連接到網路，請檢查您的連線設定！", Toast.LENGTH_LONG).show();
	}

	private void initmain()
	{
		// 隱藏鍵盤
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
		// 送出資料
		search = (Button) findViewById(R.id.search);
		search.setOnClickListener(this);
		clear = (Button) findViewById(R.id.clear);
		clear.setOnClickListener(this);
		data_listview = (ListView) findViewById(R.id.category_list);
		spinner_city = (Spinner) findViewById(R.id.spinner_city);
		listAdapter = new ArrayAdapter(OtheruserActivity.this,R.layout.spinnerlayout,citys);
		listAdapter.setDropDownViewResource(R.layout.spinner_dropdown);
		spinner_city.setAdapter(listAdapter);
		spinner_city.setOnItemSelectedListener(spinnerlistener);
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		switch (keyCode)
		{
			case KeyEvent.KEYCODE_BACK:
				finish();
				return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	AdapterView.OnItemSelectedListener spinnerlistener = new AdapterView.OnItemSelectedListener() {
		@Override
		public void onItemSelected(AdapterView adapterView, View view, int position, long id) {
			if (adapterView.getId() == R.id.spinner_city) {
				//判斷選取的種類是何種，設定相對應的字串陣列內容
				select_city = position;
			}
		}
		@Override
		public void onNothingSelected(AdapterView arg0) {
		}
	};

	private class api_getotheruser extends Thread
	{
		@Override
		public void run()
		{
			String jsonURL = SERVER_NAME_WEB8 + "index.php?mode=get_user_data_list&city=" + citys[select_city] + "&page=1&number=100";
			jsonConnect json_func = new jsonConnect();
			try
			{
				String requestJSON = json_func.getJson(jsonURL);
				try
				{
					JSONObject obj = new JSONObject(requestJSON);
					String status = obj.getString("status");
					if (status.equals("0"))
						mHandler.post(new Runnable()
						{
							public void run()
							{
								Toast.makeText(context, "抱歉，目前尚無其他會員資料", Toast.LENGTH_LONG).show();
							}
						});
					String news_data = obj.getString("outputObject");
					JSONArray DataArray = new JSONArray(news_data);
					for (int i = 0; i < DataArray.length(); i++)
					{
						HashMap<String, String> newsData = new HashMap<String, String>();
						newsData.put("id", DataArray.getJSONObject(i).getString("id"));
						newsData.put("company_name", DataArray.getJSONObject(i).getString("company_name"));
						newsData.put("tel_1", DataArray.getJSONObject(i).getString("tel_1"));
						newsData.put("address", DataArray.getJSONObject(i).getString("address"));
						datalistmap.add(newsData);
					}
				} catch (Exception e) {}
			} catch (Exception e){}
			mHandler.post(new Runnable()
			{
				public void run()
				{
					datalist_init(datalistmap);
				}
			});
			super.run();
		}
	}

	private void datalist_init(final List<Map<String, String>> listmap)
	{
		data_listview = (ListView) findViewById(R.id.category_list);
		data_listview.setAdapter(new BaseAdapter()
		{
			@Override
			public View getView(int position, View convertView, ViewGroup parent)
			{
				// 新建LinearLayout
				View view = getLayoutInflater().inflate(R.layout.otheruser_listview, null);
				TextView name = (TextView) view.findViewById(R.id.name);
				name.setText(listmap.get(position).get("company_name"));
				TextView address = (TextView) view.findViewById(R.id.address);
				address.setText(listmap.get(position).get("address"));
				TextView tel = (TextView) view.findViewById(R.id.tel);
				tel.setText(listmap.get(position).get("tel_1"));
				return view;
			}
			@Override
			public long getItemId(int position)
			{
				return Integer.parseInt(listmap.get(position).get("id"));
			}
			@Override
			public Object getItem(int position)
			{
				return listmap.get(position);
			}
			@Override
			public int getCount()
			{
				return listmap.size();
			}
		});
		data_listview.setOnItemClickListener(new OnItemClickListener()
		{
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id)
			{
				try
				{
					speditor.putString("detail_id", String.valueOf(id));
					speditor.putString("detail_name", listmap.get(position).get("company_name"));
					speditor.commit();
					Intent imenu = new Intent(maint, MemberDetailActivity.class);
					imenu.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
					startActivity(imenu);
				} catch (Exception e) {}
			}
		});
		if (listmap.size() == 0)
			Toast.makeText(context, "抱歉，目前尚無其他會員訊息", Toast.LENGTH_LONG).show();
	}
	@Override
	public void onClick(View v)
	{
		switch (v.getId())
		{
			case R.id.search:
				data_listview.setAdapter(null);
				datalistmap.clear();
				try
				{
					imw_thread = new api_getotheruser();
					imw_thread.start();
				} catch (Exception e)
				{
					Toast.makeText(maint, "搜尋錯誤", Toast.LENGTH_LONG).show();
				}
				break;
			case R.id.clear:
				data_listview.setAdapter(null);
				spinner_city.setSelection(0);
				break;
		}
	}
}