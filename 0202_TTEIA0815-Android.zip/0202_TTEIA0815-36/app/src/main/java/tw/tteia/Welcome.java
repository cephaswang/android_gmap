package tw.tteia;

import android.os.Bundle;
import android.view.KeyEvent;

import java.util.Timer;
import java.util.TimerTask;

public class Welcome extends BaseActivity
{
	private Timer mTimer;
	private TimerTask mTimerTask;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_welcome);
		mTimer = new Timer();
		mTimerTask = new TimerTask()
		{
			@Override
			public void run()
			{
				mHandler.post(new Runnable()
				{
					@Override
					public void run()
					{
						String gcm_id = sp.getString("gcm_id", "");

						// 記錄，是否巳經成功登入。
						int is_login = sp.getInt("is_login", 0);
						if (gcm_id.equals("") || is_login == 0)
						{
							imw_GCM gcm = new imw_GCM(mContext);
							gcm.startGCM();
						}else
							imw.backMain();
						imw.backMain();//回首頁 MainActivity.class
						finish();
					}
				});
			}
		};
		mTimer.schedule(mTimerTask, 2000);//停在登入頁3秒後轉跳
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		switch (keyCode)
		{
			case KeyEvent.KEYCODE_BACK:
				finish();
				break;
		}
		return true;
	}
}