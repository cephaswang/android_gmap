package tw.tteia;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static tw.tteia.ConstantUtil.SERVER_NAME_WEB8;

public class EventActivity extends BaseActivity
{
	private Context context = EventActivity.this;
	private ListView data_listview;
	private ProgressDialog mypDialog;
	private List<Map<String, String>> datalistmap = new ArrayList<Map<String, String>>();
	public Thread imw_thread;
	private Handler mHandler = new Handler();

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.view_null);
		setContentView(R.layout.activity_event);
		imw.nav_init();
		if (isInternetPresent == 0)
			Toast.makeText(context, "無法連接到網路，請檢查您的連線設定！", Toast.LENGTH_LONG).show();
		else {
			mypDialog = new ProgressDialog(this);
			mypDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
			mypDialog.setMessage("更新資料中");
			mypDialog.setIndeterminate(false);
			mypDialog.setCancelable(false);
			mypDialog.show();
			imw_thread = new api_getnews();
			imw_thread.start();
		}
		mypDialog.dismiss();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data)
	{
		super.onActivityResult(requestCode, resultCode, data);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		switch (keyCode)
		{
			case KeyEvent.KEYCODE_BACK:
				finish();
				return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	private class api_getnews extends Thread
	{
		@Override
		public void run()
		{
			String jsonURL = SERVER_NAME_WEB8 + "index.php?mode=get_calendar&year=" + sp.getString("event_year","") + "&month=" + sp.getString("event_month","") + "&day=" + sp.getString("event_day","") + "&type=2";
			jsonConnect json_func = new jsonConnect();
			try
			{
				String requestJSON = json_func.getJson(jsonURL);
				try
				{
					JSONObject obj = new JSONObject(requestJSON);
					String status = obj.getString("status");
					if (status.equals("0"))
					{
						mHandler.post(new Runnable()
						{
							public void run()
							{
								Toast.makeText(context, "抱歉，目前尚無活動資料", Toast.LENGTH_LONG).show();
								mypDialog.dismiss();
							}
						});
					}
					String event_data = obj.getString("outputObject");
					JSONArray DataArray = new JSONArray(event_data);
					for (int i = 0; i < DataArray.length(); i++)
					{
						HashMap<String, String> eventData = new HashMap<String, String>();
						eventData.put("time", DataArray.getJSONObject(i).getString("date") + " "+ DataArray.getJSONObject(i).getString("time"));
						eventData.put("title", DataArray.getJSONObject(i).getString("title"));
						eventData.put("location", DataArray.getJSONObject(i).getString("location"));
						datalistmap.add(eventData);
					}
				} catch (Exception e) {}
			} catch (Exception e) {}
			mHandler.post(new Runnable()
			{
				public void run()
				{
					datalist_init(datalistmap);
					mypDialog.dismiss();
				}
			});
			super.run();
		}
	}

	private void datalist_init(final List<Map<String, String>> listmap)
	{
		data_listview = (ListView) findViewById(R.id.news_data);
		data_listview.setAdapter(new BaseAdapter()
		{
			@Override
			public View getView(int position, View convertView, ViewGroup parent)
			{
				// 新建LinearLayout
				View view = getLayoutInflater().inflate(R.layout.event_listview, null);
				TextView time = (TextView) view.findViewById(R.id.time);
				time.setText(listmap.get(position).get("time"));
				TextView title = (TextView) view.findViewById(R.id.title_text);
				title.setText(listmap.get(position).get("title"));
				TextView location = (TextView) view.findViewById(R.id.location);
				location.setText(listmap.get(position).get("location"));
				return view;
			}
			@Override
			public long getItemId(int position)
			{
				return position;
			}
			@Override
			public Object getItem(int position)
			{
				return listmap.get(position);
			}
			@Override
			public int getCount()
			{
				return listmap.size();
			}
		});
		if (listmap.size() == 0)
			Toast.makeText(context, "抱歉，目前尚無活動訊息", Toast.LENGTH_LONG).show();
	}
}