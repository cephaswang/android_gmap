package tw.tteia;

import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.Bundle;
import android.widget.Toast;

import java.util.List;

import static tw.tteia.ConstantUtil.unCheckNetActivity;

public class Connload
{
	private Context _context;
	public Connload(Context context)
	{
		this._context = context;
	}
	/**
	 * 判斷網路是否以WIFI還是以3G連接
	 * 
	 * @return 0:no connection, 1:Wifi connection, 2:3g connection
	 */
	public int isConnected()
	{
		ConnectivityManager connecting = (ConnectivityManager) _context.getSystemService(Context.CONNECTIVITY_SERVICE);
		// For 3G check
		boolean is3g = connecting.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).isConnectedOrConnecting();
		// For WiFi Check
		boolean isWifi = connecting.getNetworkInfo(ConnectivityManager.TYPE_WIFI).isConnectedOrConnecting();
		if (is3g)
		{
			return 2;
		} else if (isWifi)
		{
			return 1;
		} else
		{
			// 檢查該頁面是否限制連線狀況
			Boolean inarray = false;
			String packageName = getPackageName(_context);
			for (int i = 0; i < unCheckNetActivity.length; i++)
			{

				if (packageName.indexOf(unCheckNetActivity[i]) != -1)
				{
					// 在不用連線清單
					inarray = true;
				}
			}
			if (!inarray)
			{
				showAlert();
			}
			return 0;
		}
	}

	public String getPackageName(Context context)
	{
		String topActivityClassName = null;
		ActivityManager activityManager = (ActivityManager) (context
				.getSystemService(android.content.Context.ACTIVITY_SERVICE));
		List<RunningTaskInfo> runningTaskInfos = activityManager.getRunningTasks(1);
		if (runningTaskInfos != null)
		{
			ComponentName f = runningTaskInfos.get(0).topActivity;
			topActivityClassName = f.getClassName();
		}
		return topActivityClassName;
	}

	public void showToast(String message, int time)
	{
		Toast.makeText(_context, message, time).show();
	}

	private void showAlert()
	{
		Builder MyAlertDialog = new AlertDialog.Builder(_context);
		MyAlertDialog.setTitle("無法取得網路連線");
		MyAlertDialog.setIcon(R.mipmap.ic_launcher);
		MyAlertDialog.setMessage("部份功能必需在網路連線狀態下執行，請確定您是否已連線上網！");
		MyAlertDialog.setCancelable(false);
		DialogInterface.OnClickListener OkClick = new DialogInterface.OnClickListener()
		{
			public void onClick(DialogInterface dialog, int which)
			{
				Intent ilose = new Intent();
				ilose.setClass(_context, tw.tteia.WarningActivity.class);
				Bundle bundle = new Bundle();
				bundle.putInt("titlename", R.string.title_warning);
				ilose.putExtras(bundle);
				_context.startActivity(ilose);
				dialog.cancel();
			}
		};
		MyAlertDialog.setNegativeButton("確定", OkClick);
		MyAlertDialog.show();
	}
}