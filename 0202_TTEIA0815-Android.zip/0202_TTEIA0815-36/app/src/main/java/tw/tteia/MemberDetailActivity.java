package tw.tteia;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.widget.TextView;

import org.apache.http.NameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static tw.tteia.ConstantUtil.SERVER_NAME_WEB8;

public class MemberDetailActivity extends BaseActivity
{
	// 版面變數
	private TextView title_name,member_id,member_email,member_representation,member_person,member_tel,member_fax,
			member_address,member_register,member_no,member_zip,member_url,member_profile;
	// 工具列
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_memberdetail);
		imw.nav_init();
		title_name = (TextView) this.findViewById(R.id.name);
		title_name.setText(sp.getString("detail_name", ""));
		HashMap<String, String> timeMap = new HashMap<String, String>();
		if (isInternetPresent == 0)
			alert_error();
		else
			new get_member_data().execute(timeMap);
	}
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		switch (keyCode)
		{
			case KeyEvent.KEYCODE_BACK:
				finish();
				break;
		}
		return true;
	}

	private class get_member_data extends AsyncTask<HashMap<String, String>, Void, JSONObject>
	{
		@Override
		protected JSONObject doInBackground(HashMap<String, String>... params)
		{
			String jsonURL = SERVER_NAME_WEB8 + "index.php?mode=get_user_data&id="+sp.getString("detail_id","");
			jsonConnect json_func = new jsonConnect();
			List<NameValuePair> postParams = new ArrayList<NameValuePair>();
			String requestJSON = json_func.getjson(jsonURL, postParams);
			JSONObject obj = null;
			try
			{
				obj = new JSONObject(requestJSON);
			} catch (Exception e)
			{
				cancel(true);
				alert_error();
			}
			return obj;
		}
		@Override
		protected void onPostExecute(JSONObject result)
		{
			try
			{
				if (result.getString("status").equals("1")) {
					JSONArray typeData = new JSONArray(result.getString("outputObject"));
					String username = typeData.getJSONObject(0).getString("username");
					String email = typeData.getJSONObject(0).getString("email");
					String name = typeData.getJSONObject(0).getString("name");
					String contact_person = typeData.getJSONObject(0).getString("contact_person");
					String tel = typeData.getJSONObject(0).getString("tel_1");
					String fax = typeData.getJSONObject(0).getString("fax");
					String address = typeData.getJSONObject(0).getString("address");
					String address_reg = typeData.getJSONObject(0).getString("address_reg");
					String company_no = typeData.getJSONObject(0).getString("company_no");
					String zip = typeData.getJSONObject(0).getString("zip");
					String url = typeData.getJSONObject(0).getString("url");
					String profile = typeData.getJSONObject(0).getString("profile");
					member_id = (TextView) findViewById(R.id.id);
					member_email = (TextView) findViewById(R.id.email);
					member_representation = (TextView) findViewById(R.id.representation);
					member_person = (TextView) findViewById(R.id.person);
					member_tel = (TextView) findViewById(R.id.tel);
					member_fax = (TextView) findViewById(R.id.fax);
					member_address = (TextView) findViewById(R.id.address);
					member_register = (TextView) findViewById(R.id.register_address);
					member_no = (TextView) findViewById(R.id.company_no);
					member_zip = (TextView) findViewById(R.id.zip);
					member_url = (TextView) findViewById(R.id.url);
					member_profile = (TextView) findViewById(R.id.profile);
					member_id.setText(username);
					member_email.setText(email);
					member_representation.setText(contact_person);
					member_person.setText(name);
					member_tel.setText(tel);
					member_fax.setText(fax);
					member_address.setText(address);
					member_register.setText(address_reg);
					member_no.setText(company_no);
					member_zip.setText(zip);
					member_url.setText(url);
					member_profile.setText(profile);
				}
			} catch (Exception e) {
				alert_error();
			}
			super.onPostExecute(result);
		}
	}

	private void alert_error()
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("連線錯誤");
		builder.setMessage("連線發生錯誤，請確認您的網路狀態。").setCancelable(false)
				.setPositiveButton("確定", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.dismiss();
					}
				});
		AlertDialog alert = builder.create();
		alert.show();
	}
}