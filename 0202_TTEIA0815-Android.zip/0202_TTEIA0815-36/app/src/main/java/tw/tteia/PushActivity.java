package tw.tteia;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

import org.apache.http.NameValuePair;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import static tw.tteia.ConstantUtil.SERVER_NAME_WEB8;

public class PushActivity extends BaseActivity implements OnClickListener
{
	private Context context = PushActivity.this;
	private Button btn_logout;
	private ImageView back_btn;
	/*private ListView data_listview;
	private CheckBox inform;
	private ImageView no_result;
	private List<Map<String, String>> datalistmap = new ArrayList<Map<String, String>>();*/
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_logout);
		imw.nav_init();
		back_btn = (ImageView) findViewById(R.id.backbtn);
		back_btn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				imw.backMain();
				finish();
			}
		});
		init_main();
		/*if (isInternetPresent == 0)
			Toast.makeText(context, "無法連接到網路，請檢查您的連線設定！", Toast.LENGTH_LONG).show();
		else {
			imw_thread = new api_getpush();
			imw_thread.start();
		}*/
	}
	private void init_main()
	{
		/*inform=(CheckBox) findViewById(R.id.inform);
		inform.setChecked(sp.getBoolean("isPush", true));
		inform.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {

			@Override
			public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
				if (isChecked) {
					showNotification();
					speditor.putBoolean("isPush", true);
				} else {
					cancelNotification(0);
					speditor.putBoolean("isPush", false);
				}
				speditor.commit();
			}
		});
		no_result = (ImageView) findViewById(R.id.no_result);*/
		btn_logout = (Button) findViewById(R.id.btn_logout);
		btn_logout.setOnClickListener(this);
	}

	private class logout extends Thread
	{
		@Override
		public void run()
		{
			String jsonURL = SERVER_NAME_WEB8 + "index.php?mode=login&username=" + sp.getString("username","") + "&password=" + sp.getString("password","") + "&xid=0000";
			jsonConnect json_func = new jsonConnect();
			List<NameValuePair> postParams = new ArrayList<NameValuePair>();
			String requestJSON = json_func.getjson(jsonURL, postParams);
			try
			{
				imw.backMain();
				finish();
				try {
					JSONObject obj = new JSONObject(requestJSON);
				} catch (Exception e) {}
			} catch (Exception e) {}
			super.run();
		}
	}
	@Override
	public void onClick(View v)
	{
		switch (v.getId())
		{
		case R.id.btn_logout:
			alert_logout();
		}
	}

	/*private class api_getpush extends Thread
	{
		@Override
		public void run()
		{
			String jsonURL = SERVER_NAME_WEB8 + "push_log.php?mode=push_log_android&gcm_id=" + sp.getString("gcm_id","") + "&xid=" + sp.getString("xid","");
			jsonConnect json_func = new jsonConnect();
			try
			{
				String requestJSON = json_func.getJson(jsonURL);
				try
				{
					JSONObject obj = new JSONObject(requestJSON);
					String status = obj.getString("status");
					if (status.equals("0"))
					{
						mHandler.post(new Runnable()
						{
							public void run()
							{
								Toast.makeText(context, "抱歉，目前尚無推播紀錄", Toast.LENGTH_LONG).show();
							}
						});
					}
					String news_data = obj.getString("outputObject");
					JSONArray DataArray = new JSONArray(news_data);
					for (int i = 0; i < DataArray.length(); i++)
					{
						HashMap<String, String> newsData = new HashMap<String, String>();
						newsData.put("id", DataArray.getJSONObject(i).getString("id"));
						newsData.put("content", DataArray.getJSONObject(i).getString("content"));
						newsData.put("time_send", DataArray.getJSONObject(i).getString("time_send"));
						datalistmap.add(newsData);
					}
				} catch (Exception e) {}
			} catch (Exception e) {}
			mHandler.post(new Runnable()
			{
				public void run()
				{
					datalist_init(datalistmap);
				}
			});
			super.run();
		}
	}

	private class api_delete extends Thread
	{
		@Override
		public void run()
		{
			String jsonURL = SERVER_NAME_WEB8 + "push_log.php?mode=push_log_del_android&id=" + sp.getString("history_id","");
			jsonConnect json_func = new jsonConnect();
			try
			{
				String requestJSON = json_func.getJson(jsonURL);
				try
				{
					JSONObject obj = new JSONObject(requestJSON);
				} catch (Exception e) {}
			} catch (Exception e) {}
			mHandler.post(new Runnable()
			{
				public void run()
				{
					Intent intent = new Intent();
					intent.setClass(maint, PushActivity.class);
					startActivity(intent);
					finish();
				}
			});
			super.run();
		}
	}*/

	/*private void datalist_init(final List<Map<String, String>> listmap)
	{
		data_listview = (ListView) findViewById(R.id.push_data);
		data_listview.setAdapter(new BaseAdapter() {
			@Override
			public View getView(int position, View convertView, ViewGroup parent) {
				// 新建LinearLayout
				View view = getLayoutInflater().inflate(R.layout.push_listview, null);
				TextView content = (TextView) view.findViewById(R.id.content);
				content.setText(listmap.get(position).get("content"));
				TextView time_invite = (TextView) view.findViewById(R.id.time_send);
				time_invite.setText(listmap.get(position).get("time_send"));
				speditor.putBoolean("push_" + listmap.get(position).get("id"), true);
				speditor.commit();
				return view;
			}

			@Override
			public long getItemId(int position) {
				return Integer.parseInt(listmap.get(position).get("id"));
			}

			@Override
			public Object getItem(int position) {
				return listmap.get(position);
			}

			@Override
			public int getCount() {
				return listmap.size();
			}
		});
		data_listview.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
				try {
					speditor.putString("history_id", String.valueOf(id));
					speditor.commit();
					AlertDialog.Builder bulider = new AlertDialog.Builder(maint);
					bulider.setTitle("是否要刪除" + listmap.get(position).get("content") + "?");
					bulider.setPositiveButton("刪除", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int id) {
							dialog.cancel();
							imw_thread = new api_delete();
							imw_thread.start();
						}
					});
					bulider.setNegativeButton("取消", new DialogInterface.OnClickListener() {
						public void onClick(DialogInterface dialog, int id) {
							dialog.cancel();
						}

					});
					AlertDialog alert2 = bulider.create();
					alert2.show();
				} catch (Exception e) {
				}
			}
		});
		if (listmap.size() == 0)
			no_result.setVisibility(View.VISIBLE);
		else
			no_result.setVisibility(View.GONE);
	}*/

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		switch (keyCode)
		{
			case KeyEvent.KEYCODE_BACK:
				imw.backMain();
				finish();
				return true;
		}
		return super.onKeyDown(keyCode, event);
	}


	private void alert_logout()
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("確定登出");
		builder.setMessage("登出後，將清空現有帳號資料。").setCancelable(false)
				.setPositiveButton("確定", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.dismiss();
						imw_thread = new logout();
						imw_thread.start();
					}
				})
				.setNegativeButton("取消", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.dismiss();
					}
				});
		AlertDialog alert = builder.create();
		alert.show();
	}

	/*public void showNotification(){
		// define sound URI, the sound to be played when there's a notification
		Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
		// intent triggered, you can add other intent for other actions
		Intent intent = new Intent(PushActivity.this, PushActivity.class);
		PendingIntent pIntent = PendingIntent.getActivity(PushActivity.this, 0, intent, 0);
		// this is it, we'll build the notification!
		// in the addAction method, if you don't want any icon, just set the first param to 0
		Notification mNotification = new Notification.Builder(this)
				.setContentTitle("電信公會")
				.setContentText("已啟用推播通知")
				.setSmallIcon(R.mipmap.icon_80x80)
				.setContentIntent(pIntent)
				.setSound(soundUri)
				.addAction(0, "設定", pIntent)
				.build();
		NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
		// If you want to hide the notification after it was selected, do the code below
		// myNotification.flags |= Notification.FLAG_AUTO_CANCEL;
		notificationManager.notify(0, mNotification);
	}
	public void cancelNotification(int notificationId){
		if (Context.NOTIFICATION_SERVICE!=null) {
			String ns = Context.NOTIFICATION_SERVICE;
			NotificationManager nMgr = (NotificationManager) getApplicationContext().getSystemService(ns);
			nMgr.cancel(notificationId);
		}
	}*/
}