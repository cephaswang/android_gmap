package tw.tteia;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.WakefulBroadcastReceiver;

import com.google.android.gms.gcm.GoogleCloudMessaging;

public class GcmBroadcastReceiver extends WakefulBroadcastReceiver
{
	public static final int NOTIFICATION_INVITE_ID = 0;
	public String gcm_type = "";
	@Override
	public void onReceive(Context context, Intent intent)
	{
		Bundle extras = intent.getExtras();
		GoogleCloudMessaging gcm = GoogleCloudMessaging.getInstance(context);
		String messageType = gcm.getMessageType(intent);
		if (!extras.isEmpty())
		{
			if (GoogleCloudMessaging.MESSAGE_TYPE_MESSAGE.equals(messageType))
			{
				try
				{
					gcm_type = extras.getString("gcm_type", "");
					if (!gcm_type.equals("invite_receiver"))
					{
						if(extras.getString("message").startsWith("http://www.tteia.org.tw/app/questionary/index.php?id=")){
							Intent i = new Intent(context, WebActivity.class);
							Bundle bundle = new Bundle();
							bundle.putString("url", extras.getString("message"));
							bundle.putInt("titleint", R.string.title_questionnaire);
							i.putExtras(bundle);
							i.setAction("android.intent.action.MAIN");
							i.addCategory("android.intent.category.LAUNCHER");
							imw_GCM.sendLocalNotification(context, NOTIFICATION_INVITE_ID, R.mipmap.icon_80x80, "電信公會",
									extras.getString("message"),  "www.tteia.org.tw", true,
									PendingIntent.getActivity(context, 0, i, PendingIntent.FLAG_CANCEL_CURRENT));
						}else {
							Intent i = new Intent(context, MainActivity.class);
							i.setAction("android.intent.action.MAIN");
							i.addCategory("android.intent.category.LAUNCHER");
							imw_GCM.sendLocalNotification(context, NOTIFICATION_INVITE_ID, R.mipmap.icon_80x80, "電信公會",
									extras.getString("message"),  "www.tteia.org.tw", true,
									PendingIntent.getActivity(context, 0, i, PendingIntent.FLAG_CANCEL_CURRENT));
						}
					}
				} catch (Exception e) {}
			}
		}
		setResultCode(Activity.RESULT_OK);
	}
}