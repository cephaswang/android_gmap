package tw.tteia;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.TextView;

import org.apache.http.NameValuePair;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static tw.tteia.ConstantUtil.SERVER_NAME_WEB;
import static tw.tteia.ConstantUtil.SERVER_NAME_WEB8;

public class EducationDetailActivity extends BaseActivity
{
	private TextView title_name;
	private WebView webview_content;
	private ImageView back_btn;
	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_educationdetail);
		imw.nav_init();
		back_btn= (ImageView) findViewById(R.id.backbtn);
		back_btn.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent();
				intent.setClass(maint, EducationActivity.class);
				startActivity(intent);
				finish();
			}
		});
		title_name = (TextView)findViewById(R.id.title_name);
		webview_content = (WebView)findViewById(R.id.content);
		HashMap<String, String> timeMap = new HashMap<String, String>();
		if (isInternetPresent == 0)
			alert_error();
		else
			new get_education_data().execute(timeMap);
	}

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event)
	{
		switch (keyCode)
		{
			case KeyEvent.KEYCODE_BACK:
				Intent intent = new Intent();
				intent.setClass(maint, EducationActivity.class);
				startActivity(intent);
				finish();
				break;
		}
		return true;
	}

	private class get_education_data extends AsyncTask<HashMap<String, String>, Void, JSONObject>
	{
		@Override
		protected JSONObject doInBackground(HashMap<String, String>... params)
		{
			String jsonURL = SERVER_NAME_WEB8 + "api_1_0_37.php?mode=get_education_msg&id="+sp.getString("education_id","");
			jsonConnect json_func = new jsonConnect();
			List<NameValuePair> postParams = new ArrayList<NameValuePair>();
			String requestJSON = json_func.getjson(jsonURL, postParams);
			JSONObject obj = null;
			try
			{
				obj = new JSONObject(requestJSON);
			} catch (Exception e)
			{
				cancel(true);
			}
			return obj;
		}
		@Override
		protected void onPostExecute(JSONObject result)
		{
			try
			{
				if (result.getString("status").equals("1")) {
					JSONArray typeData = new JSONArray(result.getString("outputObject"));
					String name = typeData.getJSONObject(0).getString("name");
					String content = typeData.getJSONObject(0).getString("content");
					title_name.setText(name);
					webview_content.loadDataWithBaseURL(SERVER_NAME_WEB,content,"text/html","utf-8","about:blank");
				}
			} catch (Exception e) {}
			super.onPostExecute(result);
		}
	}

	private void alert_error()
	{
		AlertDialog.Builder builder = new AlertDialog.Builder(this);
		builder.setTitle("連線錯誤");
		builder.setMessage("連線發生錯誤，請確認您的網路狀態。").setCancelable(false)
				.setPositiveButton("確定", new DialogInterface.OnClickListener() {
					public void onClick(DialogInterface dialog, int id) {
						dialog.dismiss();
					}
				});
		AlertDialog alert = builder.create();
		alert.show();
	}
}