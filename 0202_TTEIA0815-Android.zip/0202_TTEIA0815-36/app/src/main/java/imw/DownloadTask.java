package imw;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Handler;
import android.widget.TextView;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import static tw.tteia.ConstantUtil.DOWNLOAD_ERROR;
import static tw.tteia.ConstantUtil.DOWNLOAD_OK;

/*
 * 
 */
public class DownloadTask extends AsyncTask<String[], Integer, Boolean>
{
	// 啟動參數
	private ProgressDialog _dialog;
	private TextView _tv;
	private String _targetURL, _path, _msg = "";
	private int _len = 0;
	private Handler _handler;

	public DownloadTask(ProgressDialog dialog, Handler handler, String targetURL, String path)
	{
		this._dialog = dialog;
		this._handler = handler;
		this._targetURL = targetURL;
		this._path = path;
	}

	public DownloadTask(TextView tv, Handler handler, String targetURL, String path, int len, String msg)
	{
		this._tv = tv;
		this._handler = handler;
		this._targetURL = targetURL;
		this._msg = msg;
		this._len = len;
		this._path = path;
	}

	@Override
	protected Boolean doInBackground(String[]... params)
	{
		Boolean result = false;
		try
		{
			String[] param = params[0];
			for (int i = 0; i < param.length; i++)
			{
				String targetURL = _targetURL + param[i];
				String path = _path + param[i];
				File file = new File(path);
				if (!file.exists())
				{
					// 檔案不存在下載圖片
					URL url = new URL(targetURL);
					HttpURLConnection conn = (HttpURLConnection) url.openConnection();
					conn.setRequestMethod("GET");
					conn.setDoOutput(true);
					conn.connect();
					int fileSize = conn.getContentLength();
					InputStream is = conn.getInputStream();
					FileOutputStream fos = new FileOutputStream(file);
					int downloadedSize = 0;
					byte[] bytes = new byte[1024 * 5];
					int len = -1;
					while ((len = is.read(bytes)) != -1)
					{
						fos.write(bytes, 0, len);
						downloadedSize += len;
					}
					// 下載完成
					is.close();
					fos.close();
					publishProgress(i);
				}
			}
			result = true;
		} catch (Exception e) {}
		return result;
	}

	@Override
	protected void onProgressUpdate(Integer... values)
	{
		try
		{
			if (_dialog != null)
			{
				_dialog.setProgress(values[0]);
			}
			if (_tv != null)
			{
				_tv.setText(_msg + "(" + values[0] + "/" + _len + ")");
			}
		} catch (Exception e) {}
		super.onProgressUpdate(values);
	}

	@Override
	protected void onPostExecute(Boolean result)
	{
		if (result)
		{
			_handler.sendEmptyMessage(DOWNLOAD_OK);
		} else
		{
			_handler.sendEmptyMessage(DOWNLOAD_ERROR);
		}
		super.onPostExecute(result);
	}
}
