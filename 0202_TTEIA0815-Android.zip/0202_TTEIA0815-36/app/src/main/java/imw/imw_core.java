/**
 * @author ISREAL Wayne 2015/03/19
 *
 */
package imw;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.ActivityManager.RunningTaskInfo;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import com.navdrawer.SimpleSideDrawer;
import java.io.File;
import java.util.List;
import tw.tteia.BiddingActivity;
import tw.tteia.CalendarActivity;
import tw.tteia.Connload;
import tw.tteia.EducationActivity;
import tw.tteia.MainActivity;
import tw.tteia.MemberFirstActivity;
import tw.tteia.MonthlyActivity;
import tw.tteia.NearbyActivity;
import tw.tteia.NewsActivity;
import tw.tteia.OtheruserActivity;
import tw.tteia.PushActivity;
import tw.tteia.R;
import tw.tteia.ReportActivity;
import tw.tteia.UserLoginActivity;
import tw.tteia.WarningActivity;
import tw.tteia.WebActivity;

import static tw.tteia.ConstantUtil.CONFIG_PATH;
import static tw.tteia.ConstantUtil.SERVER_NAME_WEB;
import static tw.tteia.ConstantUtil.SERVER_NAME_WEB8;
import static tw.tteia.ConstantUtil.unCheckUserActivity;

public class imw_core
{
	public Integer[] NAV_ICON =
			{ R.mipmap.nav_home, R.mipmap.nav_user, R.mipmap.nav_education, R.mipmap.nav_report, R.mipmap.nav_nearby, R.mipmap.nav_news, R.mipmap.nav_bidding,
					 R.mipmap.nav_calendar, R.mipmap.nav_monthly, R.mipmap.nav_contact, R.mipmap.nav_otheruser, R.mipmap.nav_profile};
	public final String[] NAV_NAME =
	{ "首頁", "會員資料查詢", "教育訓練", "會務報導", "目前位置查詢", "活動訊息", "招標訊息", "公會行事曆", "電信月刊", "聯絡我們", "其他會員查詢", "登入/登出"};
	private SharedPreferences sp;
	private SharedPreferences.Editor speditor;
	private Activity mActivity;



	public imw_core(Activity mActivity)
	{
		this.mActivity = mActivity;
		sp = mActivity.getSharedPreferences(CONFIG_PATH, 0);
		speditor = sp.edit();
	}

	public String getPackageName(Context context)
	{
		String topActivityClassName = null;
		ActivityManager activityManager = (ActivityManager) (context.getSystemService(android.content.Context.ACTIVITY_SERVICE));
		List<RunningTaskInfo> runningTaskInfos = activityManager.getRunningTasks(1);
		if (runningTaskInfos != null)
		{
			ComponentName f = runningTaskInfos.get(0).topActivity;
			topActivityClassName = f.getClassName();
		}
		return topActivityClassName;
	}

	public SharedPreferences get_sp()
	{
		return sp;
	}

	public SharedPreferences.Editor get_speditor()
	{
		return speditor;
	}

	public void isNeedLogin()
	{
		Boolean inarray = false;
		String packageName = getPackageName(mActivity);
		for (int i = 0; i < unCheckUserActivity.length; i++)
			if (packageName.indexOf(unCheckUserActivity[i]) != -1)				// 在不用連線清單
				inarray = true;
		if (!inarray)
		{
			toLoginActivity();
			mActivity.finish();
		}
	}

	public void toLoginActivity()
	{
		Intent intent = new Intent();
		intent.setClass(mActivity, UserLoginActivity.class);
		mActivity.startActivity(intent);
	}

	public int get_network_state()
	{
		// 建立物件
		Connload hd = new Connload(mActivity);
		// 判斷是否有連線
		return hd.isConnected();
	}

	public void nav_init()
	{
		new nav_obj();
	}

	public void backMain()
	{
		Intent back = new Intent();
		back.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		back.setClass(mActivity, MainActivity.class);
		mActivity.startActivity(back);
	}

	public class nav_obj
	{
		private SimpleSideDrawer side_nav;
		private ImageView nav_btn,back_btn;;
		private ListView nav;
		public nav_obj()
		{
			side_nav = new SimpleSideDrawer(mActivity);
			side_nav.setLeftBehindContentView(R.layout.nav);
			nav_btn = (ImageView) mActivity.findViewById(R.id.menubtn);
			back_btn= (ImageView) mActivity.findViewById(R.id.backbtn);
			nav = (ListView) mActivity.findViewById(R.id.nav_list);
			set_nav();
		}
		public void set_nav()
		{
			nav_btn.setOnClickListener(new OnClickListener()
			{

				@Override
				public void onClick(View v)
				{
					nav.setVisibility(View.VISIBLE);
					side_nav.toggleLeftDrawer();
				}
			});
			back_btn.setOnClickListener(new OnClickListener()
			{
				@Override
				public void onClick(View v)
				{
					mActivity.finish();
				}
			});
			nav.setAdapter(new BaseAdapter()
			{
				@Override
				public View getView(int position, View convertView, ViewGroup parent)
				{
					LayoutInflater inflater = (LayoutInflater) mActivity.getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
					View view = inflater.inflate(R.layout.list_nav, null);
					// 設定圖片
					ImageView iv1 = (ImageView) view.findViewById(R.id.nav_image);
					Bitmap bitmap = BitmapFactory.decodeResource(mActivity.getResources(), NAV_ICON[position]);
					bitmap = Bitmap.createScaledBitmap(bitmap, 33, 33, false);
					iv1.setImageBitmap(bitmap);
					TextView tv1 = (TextView) view.findViewById(R.id.nav_name);
					tv1.setText(NAV_NAME[position]);
					return view;
				}
				@Override
				public long getItemId(int position)
				{
					return position;
				}
				@Override
				public Object getItem(int position)
				{
					return NAV_ICON[position];
				}
				@Override
				public int getCount()
				{
					return NAV_ICON.length;
				}
			});
			nav.setOnItemClickListener(new OnItemClickListener()
			{

				@Override
				public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
					Intent nav_intent = new Intent();
					switch (position) {
						case 0://首頁
							closemenu();
							backMain();
							break;
						case 1: // 會員資料查詢
							closemenu();
							nav_intent.setClass(mActivity, MemberFirstActivity.class);
							mActivity.startActivity(nav_intent);
							break;
						case 2: // 教育訓練 for (int i = 3350; i < 4500; i++)
							// http://www.tteia.org.tw/api/api_1_0_37.php?mode=get_action
							// api_1_0_37.php?mode=get_action
							closemenu();
							nav_intent.setClass(mActivity, EducationActivity.class);
							mActivity.startActivity(nav_intent);
							break;
						case 3: // 會務報導 for (int i = 2450; i < 4000; i++) {
							// http://www.tteia.org.tw/api/api_1_0_37.php?mode=get_news_tag&type=2
							// api_1_0_37.php?mode=get_news_tag&type=2
							closemenu();
							nav_intent.setClass(mActivity, ReportActivity.class);
							mActivity.startActivity(nav_intent);
							break;
						case 4: // 目前位置查詢
							closemenu();
							nav_intent.setClass(mActivity, NearbyActivity.class);
							mActivity.startActivity(nav_intent);
							break;
						case 5: // 活動訊息 for (int i = 2825; i < 4000; i++) {
							// http://www.tteia.org.tw/api/api_1_0_37.php?mode=get_news_tag&type=1
							// api_1_0_37.php?mode=get_news_tag&type=1
							closemenu();
							nav_intent.setClass(mActivity, NewsActivity.class);
							mActivity.startActivity(nav_intent);
							break;
						case 6: // 招標訊息 for (int i = 21000; i < 22000; i++) {
							// http://www.tteia.org.tw/api/api_1_0_37.php?mode=get_action_2
							// api_1_0_37.php?mode=get_action_2
							closemenu();
							nav_intent.setClass(mActivity, BiddingActivity.class);
							mActivity.startActivity(nav_intent);
							break;
						case 7: // 公會行事曆
							closemenu();
							nav_intent.setClass(mActivity, CalendarActivity.class);
							mActivity.startActivity(nav_intent);
							break;
						case 8: // 電信月刊
							closemenu();
							nav_intent.setClass(mActivity, MonthlyActivity.class);
							mActivity.startActivity(nav_intent);
							break;
						case 9: // 聯絡我們
							closemenu();
							weburlchange(SERVER_NAME_WEB + "app/contact_us/", R.string.title_contact, false);
							break;
						case 10: // 其他會員查詢
							closemenu();
							nav_intent.setClass(mActivity, OtheruserActivity.class);
							mActivity.startActivity(nav_intent);
							break;
						case 11: // 登入/登出
							closemenu();
							if(sp.getString("username","").equals(""))
								nav_intent.setClass(mActivity, UserLoginActivity.class);
							else
								nav_intent.setClass(mActivity, PushActivity.class);
							mActivity.startActivity(nav_intent);
							break;
					}
				}
			});
			nav.setVisibility(View.GONE);
		}

		public void closemenu()
		{
			nav.setVisibility(View.GONE);
			side_nav.toggleLeftDrawer();
		}
	}

	public String get_login_url(String url)
	{
		String xid = sp.getString("xid", "");
		String login_url = SERVER_NAME_WEB8 + "user/web_login.php?xid=" + xid + "&direct_url=" + url;
		return login_url;
	}

	public String get_web_url(String url, Boolean hadParam)
	{
		String xid = sp.getString("xid", "");
		url += hadParam ? "&xid=" + xid : "?xid=" + xid;
		return url;
	}

	public void ActivityToWarning(int titleint)
	{
		Intent intent = new Intent(mActivity, WarningActivity.class);
		Bundle bundle = new Bundle();
		bundle.putInt("titlename", titleint);
		intent.putExtras(bundle);
		mActivity.startActivity(intent);
	}

	public void weburlchange(String url, int titleint, Boolean hadParam)
	{
		url = get_web_url(url, hadParam);
		Intent intent = new Intent(mActivity, WebActivity.class);
		Bundle bundle = new Bundle();
		bundle.putString("url", url);
		bundle.putInt("titleint", titleint);
		intent.putExtras(bundle);
		intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
		mActivity.startActivity(intent);
	}

	public void clearData()
	{
		try
		{
			speditor.clear();
			speditor.commit();
			File cache = mActivity.getCacheDir();
			File appDir = new File(cache.getParent());
			if (appDir.exists())
			{
				String[] children = appDir.list();
				for (String s : children)
				{
					if (!s.equals("lib"))
					{
						deleteDir(new File(appDir, s));
					}
				}
			}
			Intent restart = new Intent();
			restart.setClass(mActivity, MainActivity.class);
			mActivity.startActivity(restart);
		} catch (Exception e) {}
	}

	public static boolean deleteDir(File dir)
	{
		if (dir != null && dir.isDirectory())
		{
			String[] children = dir.list();
			for (int i = 0; i < children.length; i++)
			{
				boolean success = deleteDir(new File(dir, children[i]));
				if (!success)
				{
					return false;
				}
			}
		}
		return dir.delete();
	}
}
