//
//  UserAreaViewController.swift
//  tteia
//
//  Created by admin on 2020/2/13.
//  Copyright © 2020 tteia. All rights reserved.
//

import UIKit

class UserAreaViewController: BaseViewController , UITableViewDataSource, UITableViewDelegate {

    var srcDict:NSDictionary = NSDictionary()
    var infoData:NSArray = NSArray()
    var timer : Timer = Timer()
    
    let menuOptions = ["首頁","會員資料查詢","教育訓練","會務報導","目前位置查詢",
                       "活動訊息","招標訊息","公會行事曆","電信月刊","聯絡我們",
                       "其他會員查詢","登入/登出"]
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var btnSearch: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("MainPage/UserList/UserAreaViewController")
        
        // print(srcDict)
        
        // showInfo()
        
        // Do any additional setup after loading the view.
        //   setupRightOneNavItems(self , actionOne: #selector(CalendarView.newBackHome))
        setupRightOneNavItems(self , actionOne: #selector(super.backHome))
        //   setupRightTwoNavItems(self , actionOne: #selector(CalendarView.newBackHome), actionTwo: #selector(super.backHome))
        
         let jsonUrlSting = "http://www.tteia.org.tw/api/index.php?mode=get_area"
         super.getJsonBase(JsonUrlSting: jsonUrlSting ,actionFunc: #selector(self.showInfo))
        
        //  UserAreaViewController.self.srcDict = BaseViewController.self.srcDictBase
        // self.tableView.reloadData()
        
         btnSearch.addTarget(self,   action: #selector(actSearch as (UIButton) -> ()) ,  for: .touchUpInside)
        
        // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
        self.timer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(updateTable), userInfo: nil, repeats: true)
        
        // 自動設定高度，或直接給數值
       // self.tableView.rowHeight = UITableView.automaticDimension
       // self.tableView.rowHeight = 50
        
        self.tableView.register(UINib(nibName: "UserAreaCell", bundle: nil), forCellReuseIdentifier: "UserAreaCell")
        
        self.tableView.rowHeight = 60
        
        checkState () // 檢查是否有登入
    }
    
    // https://medium.com/@mikru168/ios-timer-434d91529cdf
    // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
    @objc func updateTable (){
        if ( self.srcDict == NSDictionary()){
            return
        }
        
        self.tableView.reloadData()
        self.timer.invalidate()
    }
    
    @objc func actSearch (SW : UIButton){
        // self.tableView.reloadData()
        print("actSearch")

        let userSearchViewController = UserSearchViewController(nibName: "UserSearchViewController", bundle: nil)
        self.navigationController?.pushViewController(userSearchViewController, animated: true)
    }
    
    
    @objc func showInfo(){
        self.srcDict = BaseViewController.self.srcDictBase
        // print(self.srcDict)
        
        if ( self.srcDict == NSDictionary() ){
            return
        }
        
        // print(self.srcDict)
        let allkeys : NSArray = self.srcDict.allKeys as NSArray
        // print(allkeys[2])
        // Data is NSArray
        infoData = self.srcDict.object(forKey: allkeys[2]) as! NSArray
        // print(infoData)
        
        
        //for Ix  in 0 ... (UserAreaViewController.infoData.count - 1) {
        for Ix  in 0 ... 0 {
            let infoOneRec : NSDictionary = infoData[Ix] as! NSDictionary
            print(infoOneRec) // date = "2020-02-01";
            /*
             print(infoOneRec.object(forKey: "areaid") as! String )
             print(infoOneRec.object(forKey: "content") as! String )
             print(infoOneRec.object(forKey: "file_1") as! String )
             print(infoOneRec.object(forKey: "id") as! String )
             print(infoOneRec.object(forKey: "name") as! String )
             print(infoOneRec.object(forKey: "parent_id") as! String )
             print(infoOneRec.object(forKey: "sequence") as! String )
             print(infoOneRec.object(forKey: "status") as! String )
             print(infoOneRec.object(forKey: "time_create") as! String )
             print(infoOneRec.object(forKey: "type_name") as! String )
             
             {
                 areaid = 2;
                 content = "";
                 "file_1" = "";
                 id = 2;
                 name = "\U7b2c\U4e8c\U5340";
                 "parent_id" = 0;
                 sequence = 98;
                 status = 1;
                 "time_create" = "";
                 "type_name" = "\U7b2c\U4e8c\U5340";
             }
            */
            
        }
        
       // self.tableView.reloadData()
    }
        
    
    @IBAction func userSearch(_ sender: Any) {
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return (infoData.count - 0)
    }
    
    /*
    private func tableView(tableView: UITableView!, heightForRowAtIndexPath indexPath: NSIndexPath!) -> CGFloat {
       // let cell = tableView.cellForRow(at: indexPath as IndexPath)
        self.tableView.estimatedRowHeight = UITableView.automaticDimension
        self.tableView.rowHeight = UITableView.automaticDimension
        self.tableView.estimatedRowHeight = 288.0
        //return ((cell?.frame.height)! * 2.2)
        return 288
    }
  */
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserAreaCell") as! UserAreaCell
        let infoOneRec : NSDictionary = infoData[indexPath.row] as! NSDictionary
        cell.label.text = (infoOneRec.object(forKey: "name") as! String)
        cell.label.textColor = .black
        return cell
        

        /*
        // 彼得潘的-swift-ios-app-開發問題解答集/設定表格-cell-點選時的背景顏色
        // https://medium.com/%E5%BD%BC%E5%BE%97%E6%BD%98%E7%9A%84-swift-ios-app-%E9%96%8B%E7%99%BC%E5%95%8F%E9%A1%8C%E8%A7%A3%E7%AD%94%E9%9B%86/%E8%A8%AD%E5%AE%9A%E8%A1%A8%E6%A0%BC-cell-%E9%BB%9E%E9%81%B8%E6%99%82%E7%9A%84%E8%83%8C%E6%99%AF%E9%A1%8F%E8%89%B2-b59d0abe4b9d
        let selectedBackgroundView = UIView()
        selectedBackgroundView.backgroundColor = .black
        cell.selectedBackgroundView = selectedBackgroundView
        */
        
        
        // return cell
    }
    
       func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
              NSLog("willSelectRowAt indexPath:\(indexPath)")
              
              let infoOneRec : NSDictionary = infoData[indexPath.row] as! NSDictionary
              let id : String = (infoOneRec.object(forKey: "id") as! String)
              let urlString : String =  "http://www.tteia.org.tw/api/index.php?mode=get_county&areaid=\(id)"
        print(urlString)

              let menuViewController = MenuViewController(nibName: "MenuViewController", bundle: nil)
               menuViewController.urlString = urlString
    
              self.navigationController?.pushViewController(menuViewController, animated: true)
       
              return indexPath
       }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
