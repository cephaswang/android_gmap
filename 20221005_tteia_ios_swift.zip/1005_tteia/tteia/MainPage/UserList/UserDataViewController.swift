//
//  UserDataViewController.swift
//  tteia
//
//  Created by admin on 2020/2/15.
//  Copyright © 2020 tteia. All rights reserved.
//

import UIKit

class UserDataViewController: BaseViewController , UITableViewDataSource, UITableViewDelegate {

    var srcDict:NSDictionary = NSDictionary()
    var infoData:NSArray = NSArray()
    var timer : Timer = Timer()
    var urlString:String = ""
    var ThisRowhight:CGFloat = 0
    
    @IBOutlet weak var tableView: UITableView!
    
    
    // https://stackoverflow.com/questions/38843671/automatically-set-focus-to-first-cell-of-uitableview-when-view-loads
    // Automatically set focus to first cell of UITableView when view loads
    override func viewWillAppear(_ animated: Bool) {
        let topCell:NSIndexPath = NSIndexPath(row: 0, section: 0)
        self.tableView.scrollToRow(at: topCell as IndexPath, at: UITableView.ScrollPosition.none, animated: true)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print("MainPage/UserList/Menu/UserDataViewController")
        
        // Do any additional setup after loading the view.
          //   setupRightOneNavItems(self , actionOne: #selector(CalendarView.newBackHome))
        setupRightOneNavItems(self , actionOne: #selector(closePage))
          //   setupRightTwoNavItems(self , actionOne: #selector(CalendarView.newBackHome), actionTwo: #selector(super.backHome))
          
        print(urlString)
        let jsonUrlSting = urlString
        super.getJsonBase(JsonUrlSting: jsonUrlSting ,actionFunc: #selector(self.showInfo))
          

        // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
        self.timer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(updateTable), userInfo: nil, repeats: true)
        self.tableView.register(UINib(nibName: "UserDataCell", bundle: nil), forCellReuseIdentifier: "UserDataCell")

      }
      
      // https://medium.com/@mikru168/ios-timer-434d91529cdf
      // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
      @objc func updateTable (){
          if ( self.infoData == NSArray()){
              return
          }
          
        self.tableView.reloadData()
        self.tableView.isHidden = false
        let topCell:NSIndexPath = NSIndexPath(row: 0, section: 0)
        self.tableView.scrollToRow(at: topCell as IndexPath, at: UITableView.ScrollPosition.none, animated: true)
        
        self.timer.invalidate()
      }
    
    @objc func closePage (SW : UIButton) {
        print("closePage")
        self.navigationController?.popViewController(animated: true)
    }

      
    @objc func showInfo(){
        self.srcDict = BaseViewController.self.srcDictBase
        // print(self.srcDict)
          
        if ( self.srcDict == NSDictionary() ){
            return
        }
          
        // print(self.srcDict)
        let allkeys : NSArray = self.srcDict.allKeys as NSArray
        
        if (allkeys.count<3){
            return
        }
        
        print(allkeys)
          // Data is NSArray
        infoData = self.srcDict.object(forKey: "outputObject") as! NSArray
        print(infoData)
        /*
         (
                 {
                 address = "\U57fa\U9686\U5e02\U4ec1\U611b\U5340\U611b\U4e09\U8def9\U865f12\U6a13\U4e4b1";
                 "address_reg" = "\U57fa\U9686\U5e02\U4ec1\U611b\U5340\U611b\U4e09\U8def13\U865f";
                 "company_name" = "\U6c38\U5b89\U901a\U4fe1\U80a1\U4efd\U6709\U9650\U516c\U53f8";
                 "company_no" = 00846160;
                 "contact_person" = "\U7ae5\U5fb7\U5bec";
                 email = "c2020009@ms15.hinet.net";
                 fax = "(02)2422-2264";
                 name = "\U7ae5\U5fb7\U5bec";
                 profile = "\U96fb\U4fe1\U5de5\U7a0b\U696d\U3001\U96fb\U4fe1\U7ba1\U5236\U5c04\U983b\U5668\U6750\U88dd\U8a2d\U5de5\U7a0b\U696d\U3001\U793e\U5340\U5171\U540c\U5929\U7dda\U96fb\U8996\U8a2d\U5099\U696d\U3001\U885b\U661f\U96fb\U8996\Uff2b\Uff35\U983b\U9053\U3001\Uff23\U983b\U9053\U5668\U6750\U5b89\U88dd\U696d\U3001\U4e8b\U52d9\U6027\U6a5f\U5668\U8a2d\U5099\U6279\U767c\U3001\U96f6\U552e\U696d\U3001\U6d88\U9632\U5b89\U5168\U8a2d\U5099\U5b89\U88dd\U5de5\U7a0b\U696d\U3001\U76e3\U63a7\U5668\U6750\U96f6\U552e\U5b89\U88dd\U5de5\U7a0b\U696d\U3002                                        ";
                 "tel_1" = "(02)2428-1166";
                 url = "";
                 username = 10001;
                 zip = 20047;
             }
         )
         */
        
      }
          
      
      @IBAction func userSearch(_ sender: Any) {
      }
      
 
 // MARK: - UITableView
    
      func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Int(13)
      }
      
   
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        
        if (indexPath.row == 0){
            return 44
        }
        
        if (ThisRowhight<44){
            ThisRowhight = 44
        }
      
        return ThisRowhight
    }
    

      
      func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if ( indexPath.row == 0 ){
            let cell = UITableViewCell(style: UITableViewCell.CellStyle.subtitle , reuseIdentifier: "Cell")
            cell.backgroundColor = .white
            
            if (infoData == NSArray()){
                return cell
            }
            let infoOneRec:NSDictionary = infoData.object(at: Int(0)) as! NSDictionary
            cell.textLabel!.text = (infoOneRec.object(forKey: "company_name") as! String)
            
            cell.textLabel?.textColor = UIColor(red: 4 / 255.0, green: 176 / 255.0, blue: 254 / 255.0, alpha: 1)

            
            return cell
        }
        
        var targetStr:String = ""
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserDataCell") as! UserDataCell
        cell.backgroundColor = .white

        if (infoData == NSArray() ){
            return cell
        }
        

        let infoOneRec:NSDictionary = infoData.object(at: Int(0)) as! NSDictionary

        ThisRowhight = 50
        
        cell.label.textAlignment = .left
        cell.name.numberOfLines = 0
        cell.label.numberOfLines = 0
        
        cell.name?.textColor = UIColor(red: 51 / 255.0, green: 51 / 255.0, blue: 51 / 255.0, alpha: 1)
        cell.label?.textColor = UIColor(red: 51 / 255.0, green: 51 / 255.0, blue: 51 / 255.0, alpha: 1)
        
        switch indexPath.row
        {

        
        case 1:
                cell.label.text  = "會 籍 編 號"
                targetStr = (infoOneRec.object(forKey: "username") as! String)
                cell.name.text = targetStr
                break
        case 2:
                cell.label.text  = "公司負責人"
                targetStr = (infoOneRec.object(forKey: "name") as! String)
                cell.name.text = targetStr
                break
        case 3:
                cell.label.text  = "會 員 代 表"
                targetStr = (infoOneRec.object(forKey: "contact_person") as! String)
                cell.name.text = targetStr
                break
        case 4:
                cell.label.text  = "電　　　話"
                targetStr = (infoOneRec.object(forKey: "tel_1") as! String)
                cell.name.text = targetStr
                break
        case 5:
                cell.label.text  = "傳　　　真"
                targetStr = (infoOneRec.object(forKey: "fax") as! String)
                cell.name.text = targetStr
                break
        case 6:
                cell.label.text  = "郵 遞 區 號"
                targetStr = (infoOneRec.object(forKey: "zip") as! String)
                cell.name.text = targetStr
                break
        case 7:
                cell.label.text  = "登 記 地 址"
                targetStr = (infoOneRec.object(forKey: "address_reg") as! String)
                cell.name.text = targetStr
                break
        case 8:
                cell.label.text  = "聯 絡 地 址"
                targetStr = (infoOneRec.object(forKey: "address") as! String)
                cell.name.text = targetStr
                break
        case 9:
                cell.label.text  = "統 一 編 號"
                targetStr = (infoOneRec.object(forKey: "company_no") as! String)
                cell.name.text = targetStr
                break
        case 10:
                cell.label.text  = "電 子 郵 件"
                targetStr = (infoOneRec.object(forKey: "email") as! String)
                cell.name.text = targetStr
                break
        case 11:
                cell.label.text  = "網　　　址"
                targetStr = (infoOneRec.object(forKey: "url") as! String)
                cell.name.text = targetStr
                break
        case 12:
                cell.label.text  = "營 業 項 目"
                targetStr = (infoOneRec.object(forKey: "profile") as! String)
                cell.name.text = targetStr
                
                break
            
        default:
            break
        }
        
        
        let size = CGSize(width: cell.name.frame.size.width, height: 1000)
        let labelSize:CGRect = (cell.name.text?.boundingRect(with: size, options: .usesLineFragmentOrigin,
            attributes: [NSAttributedString.Key.font: cell.name.font as Any], context: nil))!
        ThisRowhight = labelSize.size.height
        

       if (indexPath.row == 7 || indexPath.row == 8 || indexPath.row == 12 ){
            ThisRowhight = ThisRowhight + 30
       }
       
        print("ThisRowhight \(indexPath.row): \(ThisRowhight)")
        
        if ( indexPath.row % 2 == 1 ){
            cell.contentView.backgroundColor = UIColor(red: 241 / 255.0, green: 241 / 255.0, blue: 241 / 255.0, alpha: 1)
        }
        
          /*
          // 彼得潘的-swift-ios-app-開發問題解答集/設定表格-cell-點選時的背景顏色
          // https://medium.com/%E5%BD%BC%E5%BE%97%E6%BD%98%E7%9A%84-swift-ios-app-%E9%96%8B%E7%99%BC%E5%95%8F%E9%A1%8C%E8%A7%A3%E7%AD%94%E9%9B%86/%E8%A8%AD%E5%AE%9A%E8%A1%A8%E6%A0%BC-cell-%E9%BB%9E%E9%81%B8%E6%99%82%E7%9A%84%E8%83%8C%E6%99%AF%E9%A1%8F%E8%89%B2-b59d0abe4b9d
          let selectedBackgroundView = UIView()
          selectedBackgroundView.backgroundColor = .black
          cell.selectedBackgroundView = selectedBackgroundView
          */
          
          
          return cell
      }
      
      /*
      // MARK: - Navigation

      // In a storyboard-based application, you will often want to do a little preparation before navigation
      override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
          // Get the new view controller using segue.destination.
          // Pass the selected object to the new view controller.
      }
      */

    /*
    // https://medium.com/@mikru168/ios-%E5%8F%96%E5%BE%97%E6%96%87%E5%AD%97%E9%AB%98%E5%BA%A6%E7%9A%84%E6%96%B9%E5%BC%8F-d338893aedee
    // 利用UILabel來取得文字的高度
    // 详解UIView的frame、bounds和center属性
    // https://www.jianshu.com/p/c16c32c45862
    func getHeight(withLabelText text: String, width: CGFloat, font: UIFont) -> CGFloat {
        let label: UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: width, height: CGFloat(MAXFLOAT)))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        label.sizeToFit()
        return label.frame.height
    }*/
    
    
  }

