//
//  UserSearchViewController.swift
//  tteia
//
//  Created by admin on 2020/2/14.
//  Copyright © 2020 tteia. All rights reserved.
//
// https://www.youtube.com/watch?v=b1LiBiLjca4

import UIKit
import QuartzCore

/*
// Swift - 实现URL字符串的编码与解码（urlEncoded、urlDecoded）
// https://www.hangge.com/blog/cache/detail_1583.html
extension String {
    //将原始的url编码为合法的url
    func urlEncoded() -> String {
        let encodeUrlString = self.addingPercentEncoding(withAllowedCharacters:
            .urlQueryAllowed)
        return encodeUrlString ?? ""
    }
    //将编码后的url转换回原始的url
    func urlDecoded() -> String {
        return self.removingPercentEncoding ?? ""
    }
}
*/


class UserSearchViewController: BaseViewController , UITableViewDataSource, UITableViewDelegate {

    
    @IBOutlet weak var btnCity: UIButton!
    @IBOutlet weak var btnTown: UIButton!
    @IBOutlet weak var textKey: UITextField!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var btnClear: UIButton!
    @IBOutlet weak var btnSearch: UIButton!
    
    var tableData : [String] =  [String()]
    var sw_tagSN : NSInteger = -1
    var cityString: String = ""
    var townString: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("/MainPage/UserList/UserSearch/UserSearchViewController")
        
        // Default String
        textKey.text = ""
        
        tableView.isHidden = true

        // Do any additional setup after loading the view.
        
        setupRightOneNavItems(self , actionOne: #selector(super.backHome))
        
        tableView.register(UINib.init(nibName: "UserSearchCell", bundle: nil), forCellReuseIdentifier: "Cell")
        
        // tableView.register(UserSearchCell.self , forCellReuseIdentifier:"custom")
        
       // tableView.rowHeight = 400
        
        btnCity.addTarget(self,  action: #selector(btnOptionAct as (UIButton) -> ()) ,  for: .touchUpInside)
        btnTown.addTarget(self,  action: #selector(btnOptionAct as (UIButton) -> ()) ,  for: .touchUpInside)
        
        btnClear.addTarget(self,  action: #selector(btnClearAct as (UIButton) -> ()) ,  for: .touchUpInside)
        btnSearch.addTarget(self,  action: #selector(btnSearchAct as (UIButton) -> ()) ,  for: .touchUpInside)
       
        shadowButton(SW: &btnCity)
        shadowButton(SW: &btnTown)

        checkState () // 檢查是否有登入
    }
    
    @objc func btnSearchAct(SW : UIButton){
        
        var keyString:String = textKey.text!
        keyString = keyString.urlEncoded()
        let cityStringU = cityString.urlEncoded()
        let townStringU = townString.urlEncoded()
        let urlString:String = String ( "http://www.tteia.org.tw/api/index.php?mode=get_user_search&city=\(cityStringU)&area=\(townStringU)&keyword=\(keyString)")
        let userSearchController = UserSearchController(nibName: "UserSearchController", bundle: nil)
        userSearchController.urlString = urlString
        self.navigationController?.pushViewController(userSearchController, animated: true)
        
    }
    
    
    
    @objc func btnClearAct(SW : UIButton){
        cityString = ""
        townString = ""
        btnCity.setTitle( "請選擇", for: .normal)
        btnTown.setTitle( "請選擇", for: .normal)
    }

    func shadowButton (SW :  inout UIButton){
        // UIButton bottom shadow
        // https://stackoverflow.com/questions/27076419/uibutton-bottom-shadow
        SW.setImage(UIImage(named: "Globe"), for: .normal)
        SW.backgroundColor = UIColor(red: 171/255, green: 178/255, blue: 186/255, alpha: 1.0)
        // Shadow and Radius
        SW.layer.shadowColor = UIColor(red: 0, green: 0, blue: 0, alpha: 0.25).cgColor
        SW.layer.shadowOffset = CGSize(width: 0.0, height: 2.0)
        SW.layer.shadowOpacity = 1.0
        SW.layer.shadowRadius = 0.0
        SW.layer.masksToBounds = false
        SW.layer.cornerRadius = 4.0
    }
    
    
    @objc func btnOptionAct(SW : UIButton){
        sw_tagSN = SW.tag
        if cityString == "" {
            sw_tagSN = 1
        }
        
        if sw_tagSN == 1 {
            tableData = cityArr
        } else {
            if cityString != "" {
                tableData = townArr.object(forKey: cityString) as! [String]
            }
        }
        
        self.tableView.reloadData()
        
        view.endEditing(true)
        
        if (self.tableView.isHidden){
            UIView.animate(withDuration: 2.0) {
                self.tableView.isHidden = false
            }
        } else {
            UIView.animate(withDuration: 2.0) {
                self.tableView.isHidden = true
            }
        }
    }
    
    @objc func closePage (SW : UIButton) {
        print("closePage")
        self.navigationController?.popViewController(animated: true)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tableData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.subtitle , reuseIdentifier: "Cell")
   
        cell.textLabel?.text = tableData[indexPath.row]
   
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        NSLog("willSelectRowAt indexPath:\(indexPath)")
        let row : NSInteger  = indexPath.row

        if  sw_tagSN == 1 {
            if cityString != tableData[row] {
                btnTown.setTitle( "請選擇", for: .normal)
                townString = ""
            }
            cityString = tableData[row]
            btnCity.setTitle( tableData[row], for: .normal)
        } else {
            townString = tableData[row]
            btnTown.setTitle( tableData[row], for: .normal)
        }
        
        self.tableView.isHidden = true
        
        return indexPath
    }
    // MARK: - City And Town
    
    let cityArr : [String] =  [ "基隆市", "台北市", "新北市", "桃園市", "宜蘭縣", "新竹市",
                                "新竹縣", "苗栗縣", "台中市", "南投縣", "彰化縣", "雲林縣",
                                "嘉義市", "嘉義縣", "台南市", "高雄市", "屏東縣", "台東縣",
                                "花蓮縣", "澎湖縣", "金門縣", "連江縣"]
    
    
    let townArr :NSDictionary = [
        "基隆市": ["中正區","七堵區","暖暖區","仁愛區","中山區","安樂區","信義區"] ,
        "台北市": ["松山區","信義區","大安區","中山區","中正區",
                "大同區","萬華區","文山區","南港區","內湖區","士林區","北投區"] ,
        "新北市": ["板橋區","三重區","中和區","永和區","新莊區",
                "新店區","樹林區","鶯歌區","三峽區","淡水區",
                "汐止區","瑞芳區","土城區","蘆洲區","五股區",
                "泰山區","林口區","深坑區","石碇區","坪林區",
                "三芝區","石門區","八里區","平溪區","雙溪區",
                "貢寮區","金山區","萬里區","烏來區"] ,
        "桃園市": ["桃園區","中壢區","大溪區","楊梅區","蘆竹區",
                "大園區","龜山區","八德區","龍潭區","平鎮區",
                "新屋區","觀音區","復興區"] ,
        "宜蘭縣":["宜蘭市","羅東鎮","蘇澳鎮","頭城鎮","礁溪鄉",
                "壯圍鄉","員山鄉","冬山鄉","五結鄉","三星鄉",
                "大同鄉","南澳鄉"] ,
        "新竹市": ["東區","北區","香山區"] ,
        
        "新竹縣": ["竹北市","竹東鎮","新埔鎮","關西鎮","湖口鄉",
                "新豐鄉","芎林鄉","橫山鄉","北埔鄉","寶山鄉",
                "峨眉鄉","尖石鄉","五峰鄉"] ,
        "苗栗縣": ["苗栗市","苑裡鎮","通霄鎮","竹南鎮","頭份鎮",
                "後龍鎮","卓蘭鎮","大湖鄉","公館鄉","銅鑼鄉",
                "南庄鄉","頭屋鄉","三義鄉","西湖鄉","造橋鄉",
                "三灣鄉","獅潭鄉","泰安鄉"] ,
        "台中市": ["中區","東區","南區","西區","北區",
                "西屯區","南屯區","北屯區","豐原區","東勢區",
                "大甲區","清水區","沙鹿區","梧棲區","后里區",
                "神岡區","潭子區","大雅區","新社區","石岡區",
                "外埔區","大安區","烏日區","大肚區","龍井區",
                "霧峰區","太平區","大里區","和平區"] ,
        "南投縣": ["南投市","埔里鎮","草屯鎮","竹山鎮",
                "集集鎮","名間鄉","鹿谷鄉","中寮鄉","魚池鄉",
                "國姓鄉","水里鄉","信義鄉","仁愛鄉"] ,
        "彰化縣": ["彰化市","鹿港鎮","和美鎮","線西鄉","伸港鄉",
                "福興鄉","秀水鄉","花壇鄉","芬園鄉","員林市",
                "溪湖鎮","田中鎮","大村鄉","埔鹽鄉","埔心鄉",
                "永靖鄉","社頭鄉","二水鄉","北斗鎮","二林鎮",
                "田尾鄉","埤頭鄉","芳苑鄉","大城鄉","竹塘鄉",
                "溪州鄉"] ,
        "雲林縣": ["斗六市","斗南鎮","虎尾鎮","西螺鎮","土庫鎮",
                "北港鎮","古坑鄉","大埤鄉","莿桐鄉","林內鄉",
                "二崙鄉","崙背鄉","麥寮鄉","東勢鄉","褒忠鄉",
                "臺西鄉","元長鄉","四湖鄉","口湖鄉","水林鄉"] ,
        
        "嘉義市": ["東區","西區"] ,
        "嘉義縣": ["太保市","朴子市","布袋鎮","大林鎮","民雄鄉",
                "溪口鄉","新港鄉","六腳鄉","東石鄉","義竹鄉",
                "鹿草鄉","水上鄉","中埔鄉","竹崎鄉","梅山鄉",
                "番路鄉","大埔鄉","阿里山鄉"] ,
        "台南市": ["新營區","鹽水區","白河區","柳營區","後壁區",
                "東山區","麻豆區","下營區","六甲區","官田區",
                "大內區","佳里區","學甲區","西港區","七股區",
                "將軍區","北門區","新化區","善化區","新市區",
                "安定區","山上區","玉井區","楠西區","南化區",
                "左鎮區","仁德區","歸仁區","關廟區","龍崎區",
                "永康區","東區","南區","北區","安南區",
                "安平區"] ,
        "高雄市": ["鹽埕區","鼓山區","左營區",
                "楠梓區","三民區","新興區","前金區","苓雅區",
                "前鎮區","旗津區","小港區","鳳山區","林園區",
                "大寮區","大樹區","大社區","仁武區","鳥松區",
                "岡山區","橋頭區","燕巢區","田寮區","阿蓮區",
                "路竹區","湖內區","茄萣區","永安區","彌陀區",
                "梓官區","旗山區","美濃區","六龜區","甲仙區",
                "杉林區","內門區","茂林區","桃源區","那瑪夏區"] ,
        "屏東縣": ["屏東市","潮州鎮","東港鎮","恆春鎮","萬丹鄉",
                "長治鄉","麟洛鄉","九如鄉","里港鄉","鹽埔鄉",
                "高樹鄉","萬巒鄉","內埔鄉","竹田鄉","新埤鄉",
                "枋寮鄉","新園鄉","崁頂鄉","林邊鄉","南州鄉",
                "佳冬鄉","琉球鄉","車城鄉","滿州鄉","枋山鄉",
                "三地門鄉","霧臺鄉","瑪家鄉","泰武鄉","來義鄉",
                "春日鄉","獅子鄉","牡丹鄉"] ,
        "台東縣": ["臺東市","成功鎮","關山鎮","卑南鄉","鹿野鄉",
                "池上鄉","東河鄉","長濱鄉","太麻里鄉","大武鄉",
                "綠島鄉","海端鄉","延平鄉","金峰鄉","達仁鄉",
                "蘭嶼鄉"] ,
                
        "花蓮縣": ["花蓮市","鳳林鎮","玉里鎮","新城鄉","吉安鄉",
                "壽豐鄉","光復鄉","豐濱鄉","瑞穗鄉","富里鄉",
                "秀林鄉","萬榮鄉","卓溪鄉"] ,
        "澎湖縣": ["馬公市","湖西鄉","白沙鄉","西嶼鄉","望安鄉","七美鄉"] ,
        "金門縣": ["金城鎮","金沙鎮","金湖鎮","金寧鄉","烈嶼鄉","烏坵鄉"] ,
        "連江縣": ["南竿鄉","北竿鄉","莒光鄉","東引鄉"]
    ]
    
}
