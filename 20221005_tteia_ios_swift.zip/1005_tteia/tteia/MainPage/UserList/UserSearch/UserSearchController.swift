//
//  UserSearchController.swift
//  tteia
//
//  Created by admin on 2020/2/14.
//  Copyright © 2020 tteia. All rights reserved.
//

import UIKit

class UserSearchController: BaseViewController , UITableViewDelegate, UITableViewDataSource {
    
    var srcDict:NSDictionary = NSDictionary()
    var infoData:NSArray = NSArray()
    var urlString:String = ""
    var timer:Timer = Timer()

    @IBOutlet weak var noSearch: UIImageView!
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        print("MainPage/UserList/UserSearch/UserSearchController")
        print(urlString)

        // Do any additional setup after loading the view.
        // NSLog("urlString: \(urlString)")
        
        // urlString = "http://www.tteia.org.tw/api/index.php?mode=get_user_search&city=%E5%9F%BA%E9%9A%86%E5%B8%82&area=%E4%B8%AD%E6%AD%A3%E5%8D%80&keyword=%E5%9C%A8%E6%96%BC"
        super.getJsonBase(JsonUrlSting: urlString ,actionFunc: #selector(self.showInfo))
        
        setupRightOneNavItems(self , actionOne: #selector(super.backHome))
        
        // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
        self.timer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(updateView), userInfo: nil, repeats: true)
        
        self.tableView.register(UINib(nibName: "MenuViewCell", bundle: nil), forCellReuseIdentifier: "MenuViewCell")
        self.tableView.rowHeight = 70
        
        checkState () // 檢查是否有登入
    }
    
    // https://medium.com/@mikru168/ios-timer-434d91529cdf
    // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
    @objc func updateView (){
        NSLog("updateView")
            
        if ( self.srcDict == NSDictionary()){
            return
        }
        
        if infoData ==  NSArray(){
            noSearch.isHidden = false
        }

        self.tableView.reloadData()
        self.timer.invalidate()
    }

           
    @objc func showInfo(){
        print("showInfo()")
        self.srcDict = BaseViewController.self.srcDictBase
        if ( self.srcDict == NSDictionary() ){
            return
        }
        let numKeys : NSArray = self.srcDict.allKeys as NSArray
        
        // 沒有查到的記綠
        if numKeys.count < 3{
            print (self.srcDict)
            return
        }

        infoData = self.srcDict.object(forKey: "outputObject") as! NSArray
        // print (infoData)
        let infoDataDict: NSDictionary = infoData[0] as! NSDictionary
        print(infoDataDict)
        /*{
            address = "\U53f0\U5317\U5e02\U5927\U5b89\U5340\U4fe1\U7fa9\U8def\U56db\U6bb51\U865f7\U6a13\U4e4b5";
            "company_name" = "\U53f0\U7063\U5340\U96fb\U4fe1\U5de5\U7a0b\U5de5\U696d\U540c\U696d\U516c\U6703";
            id = 2631;
            "tel_1" = "(02)2701-3838";
        }
        */
    }
        
        /*
        @objc func closePage (SW : UIButton) {
            print("closePage")
            self.navigationController?.popViewController(animated: true)
        }
        */

        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return infoData.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "MenuViewCell") as! MenuViewCell
               
             //   let cell = UITableViewCell(style: UITableViewCell.CellStyle.subtitle , reuseIdentifier: "Cell")
               
               let infoOneRec : NSDictionary = infoData[indexPath.row] as! NSDictionary
               // print(infoOneRec)
               //cell.textLabel?.text = (infoOneRec.object(forKey: "company_name") as! String)
              // cell.detailTextLabel?.text  = (infoOneRec.object(forKey: "address") as! String)
               
               cell.commonName.text = (infoOneRec.object(forKey: "company_name") as! String)
               cell.address.text = (infoOneRec.object(forKey: "address") as! String)
               cell.tel.text = (infoOneRec.object(forKey: "tel_1") as! String)
               
               cell.commonName.textColor = UIColor(red: 4 / 255.0, green: 176 / 255.0, blue: 254 / 255.0, alpha: 1)
               cell.address.textColor = UIColor(red: 51 / 255.0, green: 51 / 255.0, blue: 51 / 255.0, alpha: 1)
               cell.tel.textColor = UIColor(red: 51 / 255.0, green: 51 / 255.0, blue: 51 / 255.0, alpha: 1)
               
               let myFont = UIFont.systemFont(ofSize: 14)
               cell.address?.font = myFont
               cell.tel?.font = myFont
               print("cell.bounds.width\(cell.bounds.width)")
            
            /*
             let cell = UITableViewCell(style: UITableViewCell.CellStyle.subtitle , reuseIdentifier: "Cell")
            
             let infoOneRec : NSDictionary = infoData[indexPath.row] as! NSDictionary
             cell.textLabel?.text = (infoOneRec.object(forKey: "company_name") as! String)
             cell.detailTextLabel?.text  = (infoOneRec.object(forKey: "address") as! String)
             */
            return cell
           
        }
        

        func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
               NSLog("willSelectRowAt indexPath:\(indexPath)")
               
               let infoOneRec : NSDictionary = infoData[indexPath.row] as! NSDictionary
               let id : String = (infoOneRec.object(forKey: "id") as! String)
               let urlString : String =  "http://www.tteia.org.tw/api/index.php?mode=get_user_data&id=\(id)"
               
               let userDataViewController = UserDataViewController(nibName: "UserDataViewController", bundle: nil)
               userDataViewController.urlString = urlString
               self.navigationController?.pushViewController(userDataViewController, animated: true)
        
               return indexPath
        }
   
        
        /*
        // MARK: - Navigation

        // In a storyboard-based application, you will often want to do a little preparation before navigation
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            // Get the new view controller using segue.destination.
            // Pass the selected object to the new view controller.
        }
        */

    }
