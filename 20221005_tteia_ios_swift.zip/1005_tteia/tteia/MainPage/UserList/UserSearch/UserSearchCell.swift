//
//  UserSearchCell.swift
//  tteia
//
//  Created by admin on 2020/2/14.
//  Copyright © 2020 tteia. All rights reserved.
//

import UIKit

class UserSearchCell: UITableViewCell {
    
    
    override init ( style: UITableViewCell.CellStyle , reuseIdentifier: String?){
        super.init(style:style, reuseIdentifier:reuseIdentifier)
        print("UserSearchCell custom")
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    
    @IBOutlet weak var clear: UIButton!
    @IBOutlet weak var keyWord: UITextField!
    @IBOutlet weak var ok: UIButton!
    @IBOutlet weak var selectCount: UIButton!
    @IBOutlet weak var selectArea: UIButton!
    
    

    

    @IBAction func clearAction(_ sender: Any) {
    }
    
    @IBAction func selectCountryAction(_ sender: Any) {
    }
    
    @IBAction func selectAreaAction(_ sender: Any) {
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
