//
//  MenuViewController.swift
//  tteia
//
//  Created by admin on 2020/2/15.
//  Copyright © 2020 tteia. All rights reserved.
//
//  Custom CollectionView Cell In Swift 5 & Xcode 10 (2019)
//  https://www.youtube.com/watch?v=k90V115zqRk
//  https://github.com/Maxnelson997/Programmatic-Custom-CollectionView-Cell-Subclass-in-Swift-5-Xcode-10
//  https://stackoverflow.com/questions/51100121/how-to-generate-an-uiimage-from-custom-text-in-swift


import UIKit

class MenuViewController: BaseViewController , UITableViewDelegate, UITableViewDataSource ,
        UICollectionViewDelegateFlowLayout, UICollectionViewDelegate, UICollectionViewDataSource  {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var collectionPageView: UICollectionView!
    
    var srcDict:NSDictionary = NSDictionary()
    var infoData:NSArray = NSArray()
    var infoCity:NSArray = NSArray()
    var infoPage:NSArray = NSArray()
    var urlString:String = ""
    var urlCityString:String = ""
    var timer:Timer = Timer()
    var timerCity:Timer = Timer()
    var maxCount:Int=0
    var pageCount:Int=0
    var pageQty:Int=0
    var snPage:Int=1
    var updatePageSn = 0
    
    override func viewDidLoad() {
        
    super.viewDidLoad()
        
    print("MainPage/UserList/Menu/MenuViewController")


            // Do any additional setup after loading the view.
    NSLog("urlString: \(urlString)")
    // 所在區，城市 台北，新北
    super.getJsonBase(JsonUrlSting: urlString ,actionFunc: #selector(self.showInfo))
        
    setupRightOneNavItems(self , actionOne: #selector(closePage))
            
    // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
    self.timer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(updateView), userInfo: nil, repeats: true)
    self.timerCity = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(cityView), userInfo: nil, repeats: true)
    
    collectionView.register (CustomCell.self, forCellWithReuseIdentifier: "cell")
    collectionView.backgroundColor =  UIColor(red: 0, green: 0.45806509256362915 , blue: 0.74563229084014893, alpha: 1)
        
    collectionPageView.register (CustomCell.self, forCellWithReuseIdentifier: "cell")
    collectionPageView.backgroundColor =  UIColor(red: 0, green: 0.45806509256362915 , blue: 0.74563229084014893, alpha: 1)
    
    self.tableView.register(UINib(nibName: "MenuViewCell", bundle: nil), forCellReuseIdentifier: "MenuViewCell")
        
    self.tableView.rowHeight = 70

}
// MARK: - cityChangeView
    func cityChange(){
        NSLog("urlString: \(urlString)")
        // super.getJsonBase(JsonUrlSting: urlString ,actionFunc: #selector(self.showInfo))
        
        self.srcDict = NSDictionary()
        self.updatePageSn = 0
        cityView ()
    }
    
// MARK: - cityView
    
    @objc func cityView (){
        if urlCityString == "" {
            return
        }
        
        getCity(cityStr:urlCityString)
        
        self.timerCity.invalidate()
        
        self.infoCity = NSArray()
        self.timerCity = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(updateCity), userInfo: nil, repeats: true)
    }
    
    @objc func updateCity (){
        if ( self.infoCity == NSArray()){
            return
        }
        
        print("updateCity")
        
        if (self.updatePageSn == 0){
            self.collectionPageView.reloadData()
            self.updatePageSn = 1
        }
        
        self.tableView.reloadData()
        self.timerCity.invalidate()
    }
    
    @objc func getCity(cityStr:String){
        let urlString:String = String( "http://www.tteia.org.tw/api/index.php?mode=get_user_data_list&city=\(cityStr.urlEncoded())&page=\(self.snPage)" )
        print("getCit: \(urlString)")
        
        self.srcDict = NSDictionary()
        super.getJsonBase(JsonUrlSting: urlString ,actionFunc: #selector(self.showCity))
    }
    
    
// MARK: - updateView
    
// https://medium.com/@mikru168/ios-timer-434d91529cdf
// 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
    @objc func updateView (){
        if ( self.srcDict == NSDictionary()){
            return
        }
        NSLog("updateView")
        collectionView.reloadData()
        self.timer.invalidate()
    }


    
    @objc func showCity(){
        self.srcDict = BaseViewController.self.srcDictBase
        if ( self.srcDict == NSDictionary() ){
            return
        }
        print ("City ========")
        // print(self.srcDict)
        let maxCountGet:NSString = self.srcDict.object(forKey: "maxCount") as! NSString
        self.maxCount = Int(maxCountGet.integerValue)
        print ("maxCount: \(maxCountGet)")
        
        let pageCountGet:NSString = self.srcDict.object(forKey: "pageCount") as! NSString
        self.pageCount = Int(pageCountGet.integerValue)
        print ("pageCount: \(pageCountGet)")
        
        let pageQtyGet:NSString = self.srcDict.object(forKey: "pageQty") as! NSString
        print ("pageQty: \(pageQty)")
        self.pageQty = Int(pageQtyGet.integerValue)
        
        infoCity = self.srcDict.object(forKey: "outputObject") as! NSArray
        let infoDataDict: NSDictionary = infoCity[0] as! NSDictionary
        print(infoDataDict)
        
        // self.maxCount = 390
        let tmpArr:NSMutableArray = NSMutableArray()
        let Lim : Int = (self.maxCount / self.pageQty)
        print("maxCount: \(maxCount) / pageQty: \(pageQty) = Lim:\(Lim)")
        let result = Float(self.maxCount).truncatingRemainder(dividingBy: Float(self.pageQty))
        if (result>0){
           // Lim = Lim + 1
            print("Lim = Lim + 1 :\(Lim)")
        }
        print("result:\(result)")
        for Jx in 0 ... Lim {
            tmpArr.add(Jx+1)
        }

        infoPage = tmpArr as NSArray
       // print (infoPage)
        
        /*
         {
             address = "\U65b0\U5317\U5e02\U677f\U6a4b\U5340\U5357\U96c5\U5357\U8def\U4e8c\U6bb5144\U5df775\U865f1\U6a13";
             "company_name" = "\U9a4a\U9054\U79d1\U6280\U80a1\U4efd\U6709\U9650\U516c\U53f8";
             id = 164;
             "tel_1" = "(02)8966-3918";
         }
         */
        
    }
    
    @objc func showInfo(){
        self.srcDict = BaseViewController.self.srcDictBase
        if ( self.srcDict == NSDictionary() ){
            return
        }

        infoData = self.srcDict.object(forKey: "outputObject") as! NSArray
        // print (infoData)
        let infoDataDict: NSDictionary = infoData[0] as! NSDictionary
        print(infoDataDict)
        
        // 第一筆，城市記錄
        urlCityString = (infoDataDict.object(forKey: "city") as! String)

            
        /*
        {
            city = "\U65b0\U5317\U5e02";
            content = "";
            "file_1" = "";
            id = 7;
            "parent_id" = 1;
            sequence = 8;
            status = 1;
            "time_create" = "2007-11-16 16:20:02";
            "type_name" = "\U65b0\U5317\U5e02";
        }
        */
    }
        
        
        @objc func closePage (SW : UIButton) {
            print("closePage")
            self.navigationController?.popViewController(animated: true)
        }
        
// MARK: - collectionView
    
    struct CustomData {
        var title: String
        var url: String
        var backgroundImage: UIImage
    }

    func deselectItem(at indexPath: IndexPath, animated: Bool){
        print (indexPath.row as Any)
    }
    
    func selectItem(at indexPath: IndexPath?, animated: Bool, scrollPosition: UICollectionView.ScrollPosition){
        print (indexPath?.row as Any)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // return CGSize(width: collectionView.frame.width/2.5, height: collectionView.frame.width/2)
        if (collectionView.tag == 1){
            return CGSize(width: collectionView.frame.width/3.8, height: collectionView.frame.height * 0.98)
        }
        
        return CGSize(width: collectionView.frame.width/5.3, height: collectionView.frame.height * 0.98)
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if (collectionView.tag == 1){
            return infoData.count
        }
        return infoPage.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        // print ( "collectionView" )
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CustomCell
        // cell.data = imageWith(name: "简书简书")
        // cell.text = "简书简书"
        
        if (collectionView.tag == 1){
            let infoOneRec : NSDictionary = infoData[indexPath.row] as! NSDictionary
            cell.text = (infoOneRec.object(forKey: "city") as! String)
        } else {
            cell.text = "\(infoPage [indexPath.row])"
        }
        
        let selectedBackgroundView = UIView()
        selectedBackgroundView.backgroundColor = .blue
        cell.selectedBackgroundView = selectedBackgroundView
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
         print ("didSelectItemAtA")
        if (collectionView.tag == 1){
            let infoOneRec : NSDictionary = infoData[indexPath.row] as! NSDictionary
            urlCityString = (infoOneRec.object(forKey: "city") as! String)
            
            self.updatePageSn = 0
            self.snPage = 1
            cityChange()
            return
        }
        // let urlString:String = String( "http://www.tteia.org.tw/api/index.php?mode=get_user_data_list&city=\(urlCityString.urlEncoded())&page=\(indexPath.row + 1)" )
        // print("getCit: \(urlString)")
        self.snPage = indexPath.row + 1
        // getCity(cityStr:urlCityString)
        cityView ()
    }
      
    func collectionView(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        print ("didDeselectItemAtB")
        if (collectionView.tag == 1){
            return
        }
         
    }
    
    
    // https://stackoverflow.com/questions/51100121/how-to-generate-an-uiimage-from-custom-text-in-swift
    func imageWith(name: String?) -> UIImage? {
         let frame = CGRect(x: 0, y: 0, width: 180, height: 180)
         let nameLabel = UILabel(frame: frame)
         nameLabel.textAlignment = .center
         nameLabel.backgroundColor =  UIColor(red: 0, green: 0.45806509256362915 , blue: 0.74563229084014893, alpha: 1)
         nameLabel.textColor = .white
         nameLabel.font = UIFont.systemFont(ofSize: 30)
         nameLabel.text = name
         UIGraphicsBeginImageContext(frame.size)
          if let currentContext = UIGraphicsGetCurrentContext() {
             nameLabel.layer.render(in: currentContext)
             let nameImage = UIGraphicsGetImageFromCurrentImageContext()
             return nameImage
          }
          return nil
    }
    
// MARK: - collectionView CustomCell
    
    class CustomCell: UICollectionViewCell {
        
        var text: String? {
            didSet {
                guard let data : String = text else { return }
                bg.text = data
                
            }
        }
        
        fileprivate let bg: UILabel = {
           let iv = UILabel()
            iv.translatesAutoresizingMaskIntoConstraints = false
            iv.contentMode = .scaleAspectFill
            iv.textAlignment = .center
            iv.textColor = .white
            iv.clipsToBounds = true
            iv.layer.cornerRadius = 0
            return iv
        }()
        
        
        /*
        var data: UIImage? {
            didSet {
                guard let data : UIImage = data else { return }
                bg.image = data
                
            }
        }
        
        fileprivate let bg: UIImageView = {
           let iv = UIImageView()
            iv.translatesAutoresizingMaskIntoConstraints = false
            iv.contentMode = .scaleAspectFill
            iv.clipsToBounds = true
            iv.layer.cornerRadius = 5
            return iv
        }()
        */
        
        override init(frame: CGRect) {
            super.init(frame: .zero)
            contentView.addSubview(bg)
            bg.topAnchor.constraint(equalTo: contentView.topAnchor , constant: 0).isActive = true
            bg.leftAnchor.constraint(equalTo: contentView.leftAnchor, constant: 0).isActive = true
            bg.rightAnchor.constraint(equalTo: contentView.rightAnchor, constant: 0).isActive = true
            bg.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: 0).isActive = true
        }
        
        required init?(coder aDecoder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }

    
    
// MARK: - tableView
    
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return infoCity.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            
           let cell = tableView.dequeueReusableCell(withIdentifier: "MenuViewCell") as! MenuViewCell
            
          //   let cell = UITableViewCell(style: UITableViewCell.CellStyle.subtitle , reuseIdentifier: "Cell")
            
            let infoOneRec : NSDictionary = infoCity[indexPath.row] as! NSDictionary
            // print(infoOneRec)
            //cell.textLabel?.text = (infoOneRec.object(forKey: "company_name") as! String)
           // cell.detailTextLabel?.text  = (infoOneRec.object(forKey: "address") as! String)
            
            cell.commonName.text = (infoOneRec.object(forKey: "company_name") as! String)
            cell.address.text = (infoOneRec.object(forKey: "address") as! String)
            cell.tel.text = (infoOneRec.object(forKey: "tel_1") as! String)
            
            cell.commonName.textColor = UIColor(red: 4 / 255.0, green: 176 / 255.0, blue: 254 / 255.0, alpha: 1)
            cell.address.textColor = UIColor(red: 51 / 255.0, green: 51 / 255.0, blue: 51 / 255.0, alpha: 1)
            cell.tel.textColor = UIColor(red: 51 / 255.0, green: 51 / 255.0, blue: 51 / 255.0, alpha: 1)
            
            let myFont = UIFont.systemFont(ofSize: 14)
            cell.address?.font = myFont
            cell.tel?.font = myFont
            print("cell.bounds.width\(cell.bounds.width)")
            
        
            return cell
        }
        
        func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
            
            let infoOneRec : NSDictionary = infoCity[indexPath.row] as! NSDictionary
            let id : String = (infoOneRec.object(forKey: "id") as! String)
            let urlString : String =  "http://www.tteia.org.tw/api/index.php?mode=get_user_data&id=\(id)"
            print(infoOneRec)
            print (urlString)
            let userDataViewController = UserDataViewController(nibName: "UserDataViewController", bundle: nil)
            userDataViewController.urlString = urlString
            self.navigationController?.pushViewController(userDataViewController, animated: true)
            
             return indexPath
        }
        
        
        /*
        // MARK: - Navigation

        // In a storyboard-based application, you will often want to do a little preparation before navigation
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            // Get the new view controller using segue.destination.
            // Pass the selected object to the new view controller.
        }
        */

    }
