//
//  TagCell.m
//  tteia
//
//  Created by RYANLIN on 2015/9/23.
//  Copyright (c) 2015年 tteia. All rights reserved.
//

#import "TagCell.h"

@implementation TagCell

- (void)awakeFromNib {
    // Initialization code
    self.isSelected = NO;
    
}

- (void)setIsSelected:(BOOL)isSelected
{
    //UIColor *color = (isSelected) ? RGBColor(255, 255, 255, 1.0f) : RGBColor(255, 255, 255, 255);
    //[self.titleLabel setBackgroundColor:color];
    [self.contentView setBackgroundColor:RGBColor(224.0f, 224.0f, 224.0f, 1.0f)];
    
    
    if(isSelected){self.arr.hidden=NO;}
    else{self.arr.hidden=YES;}
}
@end