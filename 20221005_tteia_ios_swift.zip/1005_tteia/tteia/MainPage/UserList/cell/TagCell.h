//
//  TagCell.h
//  tteia
//
//  Created by RYANLIN on 2015/9/23.
//  Copyright (c) 2015年 tteia. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TagCell : UICollectionViewCell

@property (assign, nonatomic) BOOL isSelected;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *arr;

@end