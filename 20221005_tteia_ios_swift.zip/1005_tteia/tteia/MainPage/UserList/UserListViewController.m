//
//  UserListViewController.m
//  tteia
//
//  Created by RYANLIN on 2015/9/23.
//  Copyright (c) 2015年 tteia. All rights reserved.
//


#import "UserListViewController.h"
#import "TagCell.h"
#define collectiIdentifier @"TagCell"

@interface UserListViewController ()
{
    NSArray *tabTitleArray;
    NSInteger selectedIndex;
}
@property (weak, nonatomic) IBOutlet UICollectionView *tabCollectionView;
@property (weak, nonatomic) IBOutlet UICollectionView *tabCollectionView2;
@end

@implementation UserListViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    [[NavigationHelper singleton] setTitleImage:[UIImage imageNamed:@"title.png"] Controller:self];
    [self setLeftBackButtonAndAction];
    
    tabTitleArray = [[NSArray alloc]init];
    tabTitleArray = @[@"第一區",@"第二區",@"第三區",@"第四區",@"第五區",@"第六區"];
    
    [[APIManager singleton].banner getNewBanner:NO CallBack:^(id JSON) {
        
        NSLog(@"%@",JSON);
    }];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




#pragma - UICollectionViewDataSource
- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    return 1;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return tabTitleArray.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView
                  cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UINib *nib = [UINib nibWithNibName:collectiIdentifier bundle:nil];
    [collectionView registerNib:nib forCellWithReuseIdentifier:collectiIdentifier];
    TagCell* cell = [collectionView dequeueReusableCellWithReuseIdentifier:collectiIdentifier forIndexPath:indexPath];
    
    cell.isSelected = (selectedIndex == indexPath.row) ? YES : NO;
    CGFloat count = tabTitleArray.count;
    CGFloat width = (count <= 3) ? [UIScreen mainScreen].bounds.size.width / count : [UIScreen mainScreen].bounds.size.width/3;
    
    CGRect rect = cell.frame;
    rect.size.width = width;
    
    cell.frame = rect;
    if (collectionView==self.tabCollectionView) {
        cell.titleLabel.text = tabTitleArray[indexPath.row];
    }
    
    return cell;
}

#pragma mark - UICollectionViewDelegate
- (void)updateTabMenu
{
    [_tabCollectionView reloadData];
    
    @try {
        [_tabCollectionView scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:selectedIndex inSection:0] atScrollPosition:UICollectionViewScrollPositionBottom animated:YES];
        
        
    }
    @catch (NSException *exception) {
        NSLog(@"%@",exception);
    }
    
    
    //    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:selectedIndex inSection:0];
    //
    //    for ( MenuTabCollectionViewCell *cell in self.tabCollectionView.visibleCells)
    //    {
    //        cell.isSelected = NO;
    //    }
    //    MenuTabCollectionViewCell* cell = (MenuTabCollectionViewCell*)[self.tabCollectionView cellForItemAtIndexPath:indexPath];
    //    cell.isSelected = YES;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    selectedIndex = indexPath.row;
    [self updateTabMenu];
}

-(UIEdgeInsets)collectionView:(UICollectionView *)cv layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(0.5,0,0.5,0);
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 0.5;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    return 0.5;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    CGFloat count  = tabTitleArray.count;
    CGFloat height = collectionView.frame.size.height;
    CGFloat width  = ((count <= 3) ? [UIScreen mainScreen].bounds.size.width / count : [UIScreen mainScreen].bounds.size.width/3) -1;
    
    return CGSizeMake(width, height);
}


@end
