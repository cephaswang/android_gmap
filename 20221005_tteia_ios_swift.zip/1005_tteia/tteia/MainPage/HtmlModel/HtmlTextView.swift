//
//  HtmlEducationView.swift
//  tteia
//
//  Created by admin on 2020/2/14.
//  Copyright © 2020 tteia. All rights reserved.
//

import UIKit
import WebKit

class HtmlTextView: BaseViewController {
    
    var srcDict:NSDictionary = NSDictionary()
    static var webData:String = String()
    var timer:Timer = Timer()
    
    @IBOutlet weak var webView: WKWebView!
    var urlString: String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // self.navigationController!.isNavigationBarHidden = true
        
        NSLog("/tteia/MainPage/HtmlModal/HtmlEducationView")

        // Do any additional setup after loading the view.
        
        NSLog("urlString: \(urlString)")
        super.getJsonBase(JsonUrlSting: urlString ,actionFunc: #selector(self.showInfo))
        
        // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
        self.timer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(updateView), userInfo: nil, repeats: true)
        
        setupRightOneNavItems(self , actionOne: #selector(closePage))
    }
    
    
    override func setupLeftNavItems(){
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: UIView())
    }
    
    
    override func setupNavTitleImage(){
        
    }
    
    

    @objc func closePage (SW : UIButton) {
        print("closePage")
        // self.navigationController!.isNavigationBarHidden = false
        self.navigationController?.popViewController(animated: true)

    }

    
    // https://medium.com/@mikru168/ios-timer-434d91529cdf
    // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
    @objc func updateView (){
        if ( HtmlTextView.webData == String()){
            return
        }
        
        NSLog("updateView")

        webView.loadHTMLString(HtmlTextView.webData, baseURL:  nil)
        self.timer.invalidate()
    }
    
    
    @objc func showInfo(){
        self.srcDict = BaseViewController.self.srcDictBase
 
        if ( self.srcDict == NSDictionary() ){
            return
        }
        
        // print (self.srcDict)

        let infoData :NSArray = self.srcDict.object(forKey: "outputObject") as! NSArray
       // print (infoData)
        let infoDataDict: NSDictionary = infoData[0] as! NSDictionary
        HtmlTextView.webData = infoDataDict.object(forKey: "content") as! String
        print(HtmlTextView.webData)
        
      //  webView.loadHTMLString(webData, baseURL:  nil)

    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
