//
//  TempWebViewController.swift
//  tteia
//
//  Created by admin on 2020/2/13.
//  Copyright © 2020 tteia. All rights reserved.
//

import UIKit
import WebKit

class TempWebViewController: BaseViewController {

    @IBOutlet weak var webView: WKWebView!
    //   @IBOutlet weak var webView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()

        print("MainPage/RearView/TempWebViewController")
        
        // https://www.tteia.org.tw/app/contact_us/
        // Do any additional setup after loading the view.
        
        //   setupRightOneNavItems(self , actionOne: #selector(CalendarView.newBackHome))
          setupRightOneNavItems(self , actionOne: #selector(super.backHome))
        //   setupRightTwoNavItems(self , actionOne: #selector(CalendarView.newBackHome), actionTwo: #selector(super.backHome))
        
        webView.load(NSURLRequest(url:NSURL.init(string:"https://www.tteia.org.tw/app/contact_us/")! as URL) as URLRequest)

    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
