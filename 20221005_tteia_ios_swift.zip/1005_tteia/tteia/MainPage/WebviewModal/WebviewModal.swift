//
//  WebviewModal.swift
//  tteia
//
//  Created by admin on 2020/2/14.
//  Copyright © 2020 tteia. All rights reserved.
//

import UIKit
import WebKit

class WebviewModal: BaseViewController {

    var urlString: String = ""
    
    @IBOutlet weak var webView: WKWebView!
    //    @IBOutlet weak var webView: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()

        print("MainPage/WebviewModal/WebviewModal")
        // Do any additional setup after loading the view.
        
        //   setupRightOneNavItems(self , actionOne: #selector(CalendarView.newBackHome))
         // setupRightOneNavItems(self , actionOne: #selector(super.backHome))
        //   setupRightTwoNavItems(self , actionOne: #selector(CalendarView.newBackHome), actionTwo: #selector(super.backHome))
        
        webView.load(NSURLRequest(url:NSURL.init(string:urlString)! as URL) as URLRequest)
        setupRightOneNavItems(self , actionOne: #selector(closePage))
        
        print("urlString: \(urlString)")
        
       // webView.scalesPageToFit = true
    }
        
        
    override func setupLeftNavItems(){
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: UIView())
    }
        
        
    override func setupNavTitleImage(){
            
    }
    
    @objc func closePage (SW : UIButton) {
        print("closePage")
        // self.navigationController!.isNavigationBarHidden = false
        self.navigationController?.popViewController(animated: true)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
