//
//  CalendarView.swift
//  tteia
//
//  Created by admin on 2020/2/12.
//  Copyright © 2020 tteia. All rights reserved.
//
// MainPage/Calender/CalendarView
// 簡單日曆 (使用 Swift 4)
// https://medium.com/@Wei_Wei/%E7%B0%A1%E5%96%AE%E6%97%A5%E6%9B%86-%E4%BD%BF%E7%94%A8-swift-4-af9ef5a570f7
// Swift tutorial : How to create a fully working Calendar with a view lines of code
// https://www.youtube.com/watch?v=0o06EIPY0JI

import UIKit



class CalendarView: BaseViewController {

    struct eventDay {
        var intYear:Int32
        var intMonth:Int32
        var intDay:Int32
    }
    
    @IBOutlet weak var timeLabel: UILabel!
    @IBOutlet weak var collectionWeek: UICollectionView!
    @IBOutlet weak var collectionDays: UICollectionView!
    
    var eventRec:[eventDay]=[]
    var fixRadius:CGFloat = 0
    
    // 當前月份日期
    var currentYear  = Calendar.current.component(.year, from: Date())
    var currentMonth = Calendar.current.component(.month, from: Date())
    
    var months = ["1月", "2月", "3月", "4月", "5月", "6月", "7月", "8月", "9月", "10月", "11月", "12月"]
    var weekss = ["週日", "週一", "週二", "週三", "週四", "週五", "週六"]
    var timer : Timer = Timer()
    
    var numberOfDaysInThisMonth:Int{
        // 傳回當月天數
        let dateComponents = DateComponents(year: currentYear , month: currentMonth)
        let date = Calendar.current.date(from: dateComponents)!
        let range = Calendar.current.range(of: .day, in: .month,for: date)
        return range?.count ?? 0
    }
    
    var whatDayIsIt:Int{
        // 傳回星期幾
        let dateComponents = DateComponents(year: currentYear , month: currentMonth)
        let date = Calendar.current.date(from: dateComponents)!
        return Calendar.current.component(.weekday, from: date)
    }
    
    // 傳回上一個月的天數
    var howManyItemsShouldIAdd:Int{
        return whatDayIsIt - 1
    }
    
    
    var srcDict:NSDictionary = NSDictionary()
    
// MARK: - viewDidLoad
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("MainPage/Calender/CalendarView")

      //  print(srcDict)
        
        
        // Do any additional setup after loading the view.
     //   setupRightOneNavItems(self , actionOne: #selector(CalendarView.newBackHome))
        setupRightOneNavItems(self , actionOne: #selector(super.backHome))
      //  setupRightTwoNavItems(self , actionOne: #selector(CalendarView.newBackHome), actionTwo: #selector(super.backHome))

        //let A1 = 2020 , B1 = 2
        //let jsonUrlSting = String(format:"http://www.tteia.org.tw/api/index.php?mode=get_calendar&year=%d&month=%d", A1,B1)
        //super.getJsonBase(JsonUrlSting: jsonUrlSting ,actionFunc: #selector(self.showInfo))
        
        collectionWeek.register (CustomCell.self, forCellWithReuseIdentifier: "cell")
        collectionDays.register (CustomCell.self, forCellWithReuseIdentifier: "cell")
        
        collectionWeek.backgroundColor = .lightGray
        collectionDays.backgroundColor = .white
        collectionWeek.tag = 1
        collectionDays.tag = 2
        
        setup()
        
       // showInfo()
        
        apiLodaer_b7(intYear: Int(currentYear), intMon: Int(currentMonth))
        
        checkState () // 檢查是否有登入
    }
    
    @objc func setup (){
        timeLabel.text = months[currentMonth - 1] + " \(currentYear)"
        collectionDays.reloadData()
    }
    
    @IBAction func nextMonth(_ sender: UIButton) {
        currentMonth += 1
        if currentMonth == 13{
            currentMonth = 1
            currentYear += 1
        }
        apiLodaer_b7(intYear: Int(currentYear), intMon: Int(currentMonth))
        //setup()
    }
    
    @IBAction func lastMonth(_ sender: UIButton) {
        currentMonth -= 1
        if currentMonth == 0{
            currentMonth = 12
            currentYear -= 1
        }
        apiLodaer_b7(intYear: Int(currentYear), intMon: Int(currentMonth))
       // setup()
    }
    
    //公會行事曆
    func apiLodaer_b7 (intYear: Int, intMon: Int){

        let jsonUrlSting = String(format:"http://www.tteia.org.tw/api/index.php?mode=get_calendar&year=%d&month=%d", intYear,intMon)
        print("apiLodaer_b7 ()")
        
        BaseViewController.self.srcDictBase =  NSDictionary()
        super.getJsonBase(JsonUrlSting: jsonUrlSting , actionFunc: #selector(self.showInfo) )
        
        // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
        self.timer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(setup), userInfo: nil, repeats: true)
    }
        
    @objc func showInfo(){
        eventRec = []
        self.srcDict = BaseViewController.self.srcDictBase

        if ( self.srcDict == NSDictionary() ){
            return
        }

        print(self.srcDict)
        
        let allkeys : NSArray = self.srcDict.allKeys as NSArray

        if (allkeys.count < 2){
            return
        }

        guard let infoDataSrc = self.srcDict.object(forKey: "outputObject") else {return}
        
        let infoData : NSArray = infoDataSrc as! NSArray
        

       //  let infoOneDay : NSDictionary = infoData[0] as! NSDictionary
        // print(infoOneDay) // date = "2020-02-01";
        // print(infoOneDay.object(forKey: "date") as! String )
        
        // 有事件的日期，加入數組
        eventRec = []
        for Ix in 0 ... infoData.count - 1 {
            let infoOneDay : NSDictionary = infoData[Ix] as! NSDictionary
            let strRecO:NSString=infoOneDay.object(forKey: "date") as! NSString
            let strYear:NSString=strRecO.substring(with: NSMakeRange(0,4)) as NSString
            // print ("strYear\(strYear)")
            let strMont:NSString=strRecO.substring(with: NSMakeRange(5,2)) as NSString
            // print ("strMont\(strMont)")
            let strDate:NSString=strRecO.substring(with: NSMakeRange(8,2)) as NSString
            print ("strDate: \(strDate)")
            eventRec.append(CalendarView.eventDay(intYear: strYear.intValue,intMonth: strMont.intValue,intDay: strDate.intValue))
        }

    }
    

    @objc  func newBackHome (){
        
        print ("CalendarView : backHome")
           
       /*
           let homePage = HomeViewController(nibName: "HomeViewController", bundle: nil)
           let frontNav = UINavigationController(rootViewController: homePage)

           let mainMenuController = MainMenuController(nibName: "MainMenuController", bundle: nil)
           let rearView = UINavigationController(rootViewController: mainMenuController)

           let SWReveal = SWRevealViewController(rearViewController: rearView, frontViewController: frontNav)
           SWReveal!.modalPresentationStyle = .overFullScreen // 由下而上，全部頁面
           SWReveal?.rearViewRevealDisplacement = 0
           
           let revealController : SWRevealViewController  = self.revealViewController()

           revealController.setFront(SWReveal, animated: true)
        */

    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}


// MARK: - UICollectionViewDelegate
extension CalendarView: UICollectionViewDelegate , UICollectionViewDataSource , UICollectionViewDelegateFlowLayout  {
    
    // 檢查有事件的日期，有為真
    func inEvent (dayInt:Int32) -> Bool {
        if eventRec.count == 0 {
            return false
        }
        for Ix in 0 ... eventRec.count - 1 {
            if eventRec[Ix].intDay == dayInt {
                return true
            }
        }
        return false
    }
    
    
    // 用戶選取事件
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if (collectionView.tag == 2) {

            let cell = collectionView.cellForItem(at: indexPath) as! CustomCell
            let clkStr:String = cell.textLabel.text!
            if (clkStr == ""){
                    return
            }
            
            if #available(iOS 13.0, *) {
                let didSelectColor:CGColor = CGColor(srgbRed:  137 / 255.0, green: 182 / 255.0, blue:  219 / 255.0, alpha: 1)
                cell.textLabel.layer.backgroundColor = didSelectColor
            } else {
                // Fallback on earlier versions
            }

            print("indexPath\(indexPath)")
            
            print("cell.textLabel.text: \(clkStr)")
            let dayNum = Int32(clkStr as String)
            if ( inEvent(dayInt:dayNum!) ){
                let strYear = String(currentYear)
                let strMonth = String(currentMonth)
                let strDay = clkStr
                let urlString : String = "http://www.tteia.org.tw/api/index.php?mode=get_calendar&year=\(strYear)&month=\(strMonth)&day=\(strDay)&type=2"
                print(urlString)
                let calendarTableView = CalendarTableView(nibName: "CalendarTableView", bundle: nil)
                           calendarTableView.urlString = urlString
                self.navigationController?.pushViewController(calendarTableView, animated: true)
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        if (collectionView.tag == 1) {
            return 7 // numberOfDaysInThisMonth + howManyItemsShouldIAdd + 14
        }
        
        return 42
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! CustomCell
        
        cell.isUserInteractionEnabled = true
        
        if (collectionView.tag == 1) {
            //cell.isUserInteractionEnabled = false
            cell.text = weekss[indexPath.row]
            
           // cell.backgroundColor = .lightGray
            cell.textLabel.textColor = .black
            cell.textLabel.layer.cornerRadius = 0
          //  cell.textLabel.layer.backgroundColor = UIColor.gray.cgColor
            
            return cell
        }
        
       // cell.isUserInteractionEnabled = true
        
        let itemColor:CGColor = CGColor(srgbRed:  0 / 255.0, green: 178 / 255.0, blue:  255 / 255.0, alpha: 1)
        let orisColor:CGColor = CGColor(srgbRed:  255 / 255.0, green: 255 / 255.0, blue:  255 / 255.0, alpha: 1)
        
        cell.textLabel.layer.backgroundColor = orisColor
        
        // 響應點擊事件
        

        
        let selectedBackgroundView = UIView()
        selectedBackgroundView.backgroundColor = .lightGray
        cell.selectedBackgroundView = selectedBackgroundView
       

       // cell.backgroundColor = .white
        cell.textLabel.textColor = .black
        cell.textLabel.layer.cornerRadius = 0
      //  cell.textLabel.layer.backgroundColor = UIColor.white.cgColor
        
        if indexPath.row < howManyItemsShouldIAdd {
            cell.text = ""
            return cell
        }else{
            let dayNum = (indexPath.row + 1 - howManyItemsShouldIAdd)
            if ( dayNum <= numberOfDaysInThisMonth){
                
                if ( inEvent(dayInt:Int32(dayNum)) ){
                // if (dayNum == 3 || dayNum == 5 || dayNum == 7 ){
                    // 響應點擊事件
                   
                    cell.textLabel.layer.backgroundColor = itemColor

                    cell.textLabel.layer.cornerRadius = fixRadius
                    cell.textLabel.textColor = .white
                }

                cell.text = "\(dayNum)"
                return cell
            } else {
                cell.text = ""
                return cell
            }
        }
       // return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let sumWidth:CGFloat = CGFloat(collectionView.frame.width)
        let widthRow = sumWidth/7
            
        fixRadius = CGFloat( widthRow / 2 - 0 )
        
        if (collectionView.tag == 1) {
            return CGSize(width: widthRow , height: 40)
        } else {
            return CGSize(width: widthRow, height: widthRow)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }

   
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
         return 0
    }
 
    // 當轉向時重新佈局
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        collectionDays.collectionViewLayout.invalidateLayout()
        collectionDays.reloadData()
    }
}



// MARK: - collectionView CustomCell

class CustomCell: UICollectionViewCell {
    
    var text: String? {
        didSet {
            guard let data : String = text else { return }
            textLabel.text = data
            
        }
    }
    
    var textLabel: UILabel = {
       let iv = UILabel()
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.contentMode = .scaleAspectFill
        iv.textAlignment = .center
        iv.textColor = .black
        iv.clipsToBounds = true
        iv.layer.cornerRadius = 0
        return iv
    }()
    
    
    /*
    var data: UIImage? {
        didSet {
            guard let data : UIImage = data else { return }
            bg.image = data
            
        }
    }
    
    fileprivate let bg: UIImageView = {
       let iv = UIImageView()
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.contentMode = .scaleAspectFill
        iv.clipsToBounds = true
        iv.layer.cornerRadius = 5
        return iv
    }()
    */
    
    override init(frame: CGRect) {
        super.init(frame: .zero)
        contentView.addSubview(textLabel)
        textLabel.topAnchor.constraint(equalTo: contentView.topAnchor , constant: 0).isActive = true
        textLabel.leftAnchor.constraint(equalTo: contentView.leftAnchor, constant: 0).isActive = true
        textLabel.rightAnchor.constraint(equalTo: contentView.rightAnchor, constant: 0).isActive = true
        textLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor, constant: 0).isActive = true
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
