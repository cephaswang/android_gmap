//
//  CalendarTableView.swift
//  tteia
//
//  Created by admin on 2020/2/18.
//  Copyright © 2020 tteia. All rights reserved.
//

import UIKit

class CalendarTableView: BaseViewController , UITableViewDataSource, UITableViewDelegate {

    var srcDict:NSDictionary = NSDictionary()
    var infoData:NSArray = NSArray()
    var timer : Timer = Timer()
    var urlString:String=String()
    var ThisRowhight:CGFloat = 0
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        //   setupRightOneNavItems(self , actionOne: #selector(CalendarView.newBackHome))
        setupRightOneNavItems(self , actionOne: #selector(closePage))
        //   setupRightTwoNavItems(self , actionOne: #selector(CalendarView.newBackHome), actionTwo: #selector(super.backHome))
        
        // let jsonUrlSting = "http://www.tteia.org.tw/api/index.php?mode=get_area"
         super.getJsonBase(JsonUrlSting: urlString ,actionFunc: #selector(self.showInfo))

        // Do any additional setup after loading the view.
        self.tableView.register(UINib(nibName: "CalendarCell", bundle: nil), forCellReuseIdentifier: "CalendarCell")
        
        // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
        self.timer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(updateTable), userInfo: nil, repeats: true)
    }
    
    // https://medium.com/@mikru168/ios-timer-434d91529cdf
    // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
    @objc func updateTable (){
        if ( self.srcDict == NSDictionary()){
            return
        }
        
        self.tableView.reloadData()
        self.timer.invalidate()
    }
    
    
    @objc func closePage (SW : UIButton) {
        print("closePage")
        // self.navigationController!.isNavigationBarHidden = false
        self.navigationController?.popViewController(animated: true)
    }


    @objc func showInfo(){
        self.srcDict = BaseViewController.self.srcDictBase
        // print(self.srcDict)
        
        if ( self.srcDict == NSDictionary() ){
            return
        }
        guard let infoDataSrc = self.srcDict.object(forKey: "outputObject")  else {return}
        infoData = infoDataSrc as! NSArray
        print(infoData)
        /*
         {
               address = "\U53f0\U4e2d\U5e02\U5317\U5c6f\U5340\U5d07\U5fb7\U8def2\U6bb5345\U865f";
               date = "2020-02-01";
               location = "\U5bf6\U9e97\U91d1\U9910\U98f2\U96c6\U5718\U5d07\U5fb7\U5ef3";
               time = "12:00";
               title = "\U7b2c4\U5340\U59d4\U54e1\U6703\U8fa6\U7406109\U5e74\U5ea6\U59d4\U54e1\U6703\U65b0\U6625\U5718\U62dc";
           },
         */
    }
        
 // MARK: - tavleView

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat{
        if(ThisRowhight<1){
            ThisRowhight = 114
        }
        return ThisRowhight
    }
    
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return (infoData.count - 0)
        }

        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            
            
            let cell = tableView.dequeueReusableCell(withIdentifier: "CalendarCell") as! CalendarCell
            
            cell.backgroundColor = .white
            
            cell.date.textColor = .lightGray
            cell.label.textColor = UIColor(displayP3Red: 0, green: 178 / 255.0, blue: 255 / 255.0, alpha: 1)
            cell.location.textColor = .lightGray
            cell.label.numberOfLines = 0
            cell.location.numberOfLines = 0
            
            // CGColor(srgbRed:  0 / 255.0, green: 178 / 255.0, blue:  255 / 255.0, alpha: 1)
            
            let infoOneRec : NSDictionary = infoData[indexPath.row] as! NSDictionary
            
            
            cell.date.text = "\(infoOneRec.object(forKey: "date") as! String) \(infoOneRec.object(forKey: "time") as! String)"
            cell.label.text = "\(infoOneRec.object(forKey: "title") as! String)"
            cell.location.text = "\(infoOneRec.object(forKey: "address") as! String)"
            
            
            var MyFont = cell.label.font
            //MyFont = UIFont.systemFont(ofSize: 18)
            var targetStr = (infoOneRec.object(forKey: "title") as! String)
            let rowHA = getHeight(withLabelText: targetStr,
                                                     width: cell.label.frame.size.width ,
                                                     font: MyFont!)
            print("targetStr\(targetStr)")
            
            MyFont = cell.location.font
            //MyFont = UIFont.systemFont(ofSize: 18)
            targetStr = (infoOneRec.object(forKey: "address") as! String) + "0"
            let rowHB = getHeight(withLabelText: targetStr,
                                                     width: cell.location.frame.size.width ,
                                                     font: MyFont!)
            
            print("targetStr\(targetStr)")
            print("\(rowHA) + \(rowHB) + 53")
            ThisRowhight = rowHA + rowHB + 53
            print(ThisRowhight)
          
            return cell
        }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}

