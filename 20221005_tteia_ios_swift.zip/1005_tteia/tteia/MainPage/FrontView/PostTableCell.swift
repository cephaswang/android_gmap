//
//  PostTableCell.swift
//  tteia
//
//  Created by admin on 2020/2/17.
//  Copyright © 2020 tteia. All rights reserved.
//

import UIKit

class PostTableCell: UITableViewCell {
    
    @IBOutlet weak var time: UILabel!
    @IBOutlet weak var time1: UILabel!
    @IBOutlet weak var label: UILabel!
    @IBOutlet weak var nl: UILabel!
    
    @IBOutlet weak var viewFirst: UIView!
  
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
       if selected {
           viewFirst.backgroundColor = UIColor(red: 31 / 255.0, green: 178 / 255.0, blue: 170 / 255.0, alpha: 1)
       } else {
           viewFirst.backgroundColor = UIColor(red: 0 / 255.0, green: 0 / 255.0, blue: 0 / 255.0, alpha: 0.5)
       }
    }
    
    override func setHighlighted(_ highlighted: Bool, animated: Bool) {
        super.setHighlighted(highlighted, animated: animated)
        
        // iOS Cell高亮(highlighted)和选中(selected)效果
        // https://www.jianshu.com/p/0668ce0b46b8
        self.selectedBackgroundView = UIView()

        if (highlighted){
            viewFirst.backgroundColor = UIColor(red: 31 / 255.0, green: 178 / 255.0, blue: 170 / 255.0, alpha: 1)
        } else {
            viewFirst.backgroundColor = UIColor(red: 0 / 255.0, green: 0 / 255.0, blue: 0 / 255.0, alpha: 0.5)
        }
    }

}
