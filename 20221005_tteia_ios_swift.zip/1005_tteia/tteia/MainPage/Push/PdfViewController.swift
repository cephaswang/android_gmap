//
//  PdfViewController.swift
//  tteia
//
//  Created by admin on 2020/2/14.
//  Copyright © 2020 tteia. All rights reserved.
//

import UIKit
import WebKit

class PdfViewController: BaseViewController {

    var srcDict:NSDictionary = NSDictionary()
    var urlString:String = ""
    var urlPdfString:String = String()
    var timer:Timer = Timer()
    
    @IBOutlet weak var webView: WKWebView!
    //   @IBOutlet weak var webView: WKWebView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print("MainPage/Push/PdfViewController")
        // Do any additional setup after loading the view.
        print(urlString)
        super.getJsonBase(JsonUrlSting: urlString ,actionFunc: #selector(self.showInfo))
        
        setupRightOneNavItems(self , actionOne: #selector(closePage))
        
        // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
        self.timer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(updateView), userInfo: nil, repeats: true)
        
        // webView.scalesPageToFit = true
    }
    
    // https://medium.com/@mikru168/ios-timer-434d91529cdf
    // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
    @objc func updateView (){
        if ( urlPdfString == String()){
            return
        }
        
        NSLog("updateView")

        webView.load(NSURLRequest(url:NSURL.init(string:urlPdfString)! as URL) as URLRequest)
        self.timer.invalidate()
    }

    @objc func showInfo(){
        self.srcDict = BaseViewController.self.srcDictBase
        if ( self.srcDict == NSDictionary() ){
            return
        }

        let infoData :NSArray = self.srcDict.object(forKey: "outputObject") as! NSArray
        let infoDataDict: NSDictionary = infoData[0] as! NSDictionary
        print(infoDataDict)
        let pdfName : String = infoDataDict.object(forKey: "file_1") as! String
        urlPdfString = String("http://www.tteia.org.tw/archive/\(pdfName)")
        print(urlPdfString)
    }

    
    @objc func closePage (SW : UIButton) {
        print("closePage")
        // self.navigationController!.isNavigationBarHidden = false
        self.navigationController?.popViewController(animated: true)

    }
    
    override func setupLeftNavItems(){
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: UIView())
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
