//
//  PushMsgEdit.swift
//  tteia
//
//  Created by admin on 2020/2/14.
//  Copyright © 2020 tteia. All rights reserved.
//

import UIKit

class PushMsgEdit: BaseViewController , UITableViewDelegate, UITableViewDataSource {

    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var labtitle: UILabel!
    
    var srcDict:NSDictionary = NSDictionary()
    var infoData:NSArray = NSArray()
    var urlString:String = ""
    var timer:Timer = Timer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("MainPage/Push/PushMsgEdit")
        print(urlString)

        // Do any additional setup after loading the view.
        NSLog("urlString: \(urlString)")
        super.getJsonBase(JsonUrlSting: urlString ,actionFunc: #selector(self.showInfo))
        
        
        setupRightOneNavItems(self , actionOne: #selector(closePage))
        
        // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
        self.timer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(updateView), userInfo: nil, repeats: true)
        
        self.tableView.register(UINib(nibName: "PushCell", bundle: nil), forCellReuseIdentifier: "PushCell")

        self.tableView.rowHeight = 50
    }
    
    // https://medium.com/@mikru168/ios-timer-434d91529cdf
    // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
    @objc func updateView (){
        if ( self.srcDict == NSDictionary()){
            return
        }
        
        NSLog("updateView")

        self.tableView.reloadData()
        self.timer.invalidate()
    }

       
    @objc func showInfo(){
           self.srcDict = BaseViewController.self.srcDictBase
           if ( self.srcDict == NSDictionary() ){
               return
           }

           infoData = self.srcDict.object(forKey: "outputObject") as! NSArray
           // print (infoData)
           let infoDataDict: NSDictionary = infoData[0] as! NSDictionary
           print(infoDataDict)
    }
    
    
    @objc func closePage (SW : UIButton) {
        print("closePage")
        self.navigationController?.popViewController(animated: true)
    }
    

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return infoData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        
        let cell = tableView.dequeueReusableCell(withIdentifier: "PushCell") as! PushCell
        let infoOneRec : NSDictionary = infoData[indexPath.row] as! NSDictionary
        cell.label?.text = (infoOneRec.object(forKey: "folder_name") as! String)
        cell.label.numberOfLines = 0
        cell.label.textColor = .black
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
           NSLog("willSelectRowAt indexPath:\(indexPath)")
           
           let infoOneRec : NSDictionary = infoData[indexPath.row] as! NSDictionary
           let id : String = (infoOneRec.object(forKey: "id") as! String)
           let urlString : String =  "http://www.tteia.org.tw/api/magazine.php?mode=magazine_delite&folder_id=\(id)"
           
           let pdfViewController = PdfViewController(nibName: "PdfViewController", bundle: nil)
            pdfViewController.urlString = urlString
 
           self.navigationController?.pushViewController(pdfViewController, animated: true)
    
           return indexPath
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
