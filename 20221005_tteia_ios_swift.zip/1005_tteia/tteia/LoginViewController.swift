//
//  LoginViewController.swift
//  tteia
//
//  Created by admin on 2020/2/13.
//  Copyright © 2020 tteia. All rights reserved.
//

import UIKit

class LoginViewController: BaseViewController {

    var srcDict:NSDictionary = NSDictionary()
    var infoData:NSDictionary = NSDictionary()
    var timer : Timer = Timer()
    var status : String = String()
    var myUserDefaults :UserDefaults!
    
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var txtAccount: UITextField!
    @IBOutlet weak var txtPwd: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        print("MainPage/FrontView/LoginView/LoginViewController")
        
        // Do any additional setup after loading the view.
        //   setupRightOneNavItems(self , actionOne: #selector(CalendarView.newBackHome))
          setupRightOneNavItems(self , actionOne: #selector(super.backHome))
        //   setupRightTwoNavItems(self , actionOne: #selector(CalendarView.newBackHome), actionTwo: #selector(super.backHome))
        
        
    }
    
    @IBAction func loginAction(_ sender: Any) {
        
        status = String()
        
        // http://www.tteia.org.tw/api/index.php?mode=login&username=60401&password=123&xid=5585307E-F8F0-47F3-B321-D014F694F54A
        let uuID : String = UUID().uuidString
        //print(uuID)
        let username : String  = txtAccount.text!
        //print(username)
        let password : String  = txtPwd.text!
        
        if ( NSString(string: "\(username)").length == 0 || NSString(string: "\(password)").length == 0 ){
            
            let alert = UIAlertController(title: "請輸入帳號、密碼", message: nil , preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "確認", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
            
            return
        }
        
        //print(password)
        let jsonUrlSting : String = "http://www.tteia.org.tw/api/index.php?mode=login&username=\(username)&password=\(password)&xid=\(uuID)"
        // print(jsonUrlSting)
        super.getJsonBase(JsonUrlSting: jsonUrlSting ,actionFunc: #selector(self.showInfo))
        
        // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
        self.timer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(showInfoStatus), userInfo: nil, repeats: true)
             
    }
    
    @objc func showInfoStatus (){
        
        copyFileToDocumentsFolder(nameForFile: "LoginViewController",extForFile: "swift")
        
        print("showInfoStatus")
        
        if ( status == String() ){
            return
        }
        
        self.timer.invalidate()
        
        var message = "登入成功"
        if ( status != "1" ){
            message = "登入失敗"
        }
        let alert = UIAlertController(title: message, message: nil , preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "確認",  style: .default, handler:{ (_) in
                   
            if ( self.status == "1" ){
                   self.myUserDefaults = UserDefaults.standard
                   self.myUserDefaults.setValue("1", forKey: "showLoginStatus")
                
                   let openView = HomeViewController(nibName: "HomeViewController", bundle: nil)
                   let frontNav = UINavigationController(rootViewController: openView)

                   let mainMenuController = MainMenuController(nibName: "MainMenuController", bundle: nil)
                   let rearView = UINavigationController(rootViewController: mainMenuController)

                   let SWReveal = SWRevealViewController(rearViewController: rearView, frontViewController: frontNav)
                   SWReveal!.modalPresentationStyle = .overFullScreen // 由下而上，全部頁面
                   SWReveal?.rearViewRevealDisplacement = 0
                   
                   let revealController : SWRevealViewController  = self.revealViewController()
                   revealController.setFront(SWReveal, animated: true)
            }
                   
        }))
        
        present(alert, animated: true, completion: nil)
        
    }
    
    @objc func showInfo (){
        self.srcDict = BaseViewController.self.srcDictBase
        if ( self.srcDict == NSDictionary() ){
            return
        }
        
        // print(self.srcDict)
        // let allkeys : NSArray = self.srcDict.allKeys as NSArray
        // print(allkeys[2])
        // Data is NSArray
        infoData = self.srcDict.object(forKey: "outputObject") as! NSDictionary
        status = self.srcDict.object(forKey: "status") as! String
        // print(infoData)
        print("Login status: \(status)")
        
        
    }
    
    func copyFileToDocumentsFolder(nameForFile: String, extForFile: String) {

        let documentsURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first
        let destURL = documentsURL!.appendingPathComponent(nameForFile).appendingPathExtension(extForFile)
        guard let sourceURL = Bundle.main.url(forResource: nameForFile, withExtension: extForFile)
            else {
                print("Source File not found.")
                return
        }
            let fileManager = FileManager.default
            do {
                try fileManager.copyItem(at: sourceURL, to: destURL)
            } catch {
                print("Unable to copy file")
            }
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
