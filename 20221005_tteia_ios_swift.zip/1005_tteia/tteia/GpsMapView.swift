//
//  GpsMapView.swift
//  tteia
//
//  Created by admin on 2020/2/13.
//  Copyright © 2020 tteia. All rights reserved.
//

import UIKit
import MapKit

class GpsMapView: BaseViewController , MKMapViewDelegate , CLLocationManagerDelegate  , UIGestureRecognizerDelegate{
    

    @IBOutlet weak var mapView: MKMapView!

    var infoData:NSArray = NSArray()
    var signData:NSMutableArray = NSMutableArray()
    
    let locationManager=CLLocationManager()
    var srcDict:NSDictionary=NSDictionary()

    override func viewDidLoad() {
        super.viewDidLoad()

        print("MainPage/Map/GpsMapView")

        showInfo()

        setupRightOneNavItems(self , actionOne: #selector(super.backHome))
        
        // Do any additional setup after loading the view.

        mapView.delegate = self
        mapView.showsUserLocation = true
        
        /*
        let longPressed = UILongPressGestureRecognizer(target: self, action: #selector(addPin(sender:)))
        longPressed.delegate = self
        longPressed.minimumPressDuration = 1
        mapView.addGestureRecognizer(longPressed)
        */
        
        checkState () // 檢查是否有登入
        
    }

    func showInfo(){
        print("showInfo()")
           if ( self.srcDict == NSDictionary() ){
               return
           }
        
          // print(self.srcDict)
        let allkeys : NSArray = self.srcDict.allKeys as NSArray
        print(allkeys)
        // Data is NSArray
        guard self.srcDict.object(forKey: "outputObject") != nil  else {return}
        
        infoData = self.srcDict.object(forKey: "outputObject") as! NSArray

        //for Ix  in 0 ... (UserAreaViewController.infoData.count - 1) {
        for Ix  in 0 ... 0 {
            let infoOneRec : NSDictionary = infoData[Ix] as! NSDictionary
            print(infoOneRec) // date = "2020-02-01";
        }
    }
    

        
    @IBAction func onNowLocacion(_ sender: UIButton) {
        print("onNowLocacion")
        locationManager.desiredAccuracy = kCLLocationAccuracyBest // Show Best Zoom Rate Mode
        locationManager.requestWhenInUseAuthorization() // Request Right
        locationManager.startUpdatingLocation() // Update Pos
        
        let mylatitude  = locationManager.location?.coordinate.latitude
        let mylongitude = locationManager.location?.coordinate.longitude
        
        guard (locationManager.location?.coordinate.latitude) != nil else {
            return
        }
        
        print("mylatitude:\(String(describing: mylatitude)) mylongitude:\(String(describing: mylongitude)) ")
        
        let lagDelta : CLLocationDegrees = 0.0018 // Zoom rate
        let lonDelta : CLLocationDegrees = 0.0018 // Zoom rate
        
        let span: MKCoordinateSpan = MKCoordinateSpan(latitudeDelta: lagDelta, longitudeDelta: lonDelta)
        let location:CLLocationCoordinate2D = CLLocationCoordinate2D(latitude: mylatitude!, longitude: mylongitude!)
        let region:MKCoordinateRegion = MKCoordinateRegion(center: location, span: span)
        
        mapView.setRegion(region, animated: true)
    }
    
    @IBAction func reLoadButton(_ sender: UIButton) {
        // mapView.reload()
        mapView.removeAnnotations(mapView.annotations)
        signData = NSMutableArray()
        
        var Max_X:CGFloat = 0
        var Max_Y:CGFloat = 0
        var Min_X:CGFloat = 99999
        var Min_Y:CGFloat = 99999
        
        let screenSize = UIScreen.main.bounds
        let screenWidth = screenSize.width
        let screenHeight = screenSize.height
        
        var  touchPoint:CGPoint = CGPoint(x: 0,y: 0)
        //print("touchPoint :\(touchPoint)")
        var locationCoordinatate:CLLocationCoordinate2D = mapView.convert(touchPoint, toCoordinateFrom: mapView)
        // addPin(location: locationCoordinatate)
        //print("locationCoordinatate A:\(locationCoordinatate)")
        Max_X = compareValue(src: Max_X,ref: CGFloat(locationCoordinatate.latitude), big: true)
        Min_X = compareValue(src: Min_X,ref: CGFloat(locationCoordinatate.latitude), big: false)
        Max_Y = compareValue(src: Max_Y,ref: CGFloat(locationCoordinatate.longitude), big: true)
        Min_Y = compareValue(src: Min_Y,ref: CGFloat(locationCoordinatate.longitude), big: false)
        
        touchPoint = CGPoint(x: 0,y: screenHeight )
        //print("touchPoint :\(touchPoint)")
        locationCoordinatate = mapView.convert(touchPoint, toCoordinateFrom: mapView)
        // addPin(location: locationCoordinatate)
        //print("locationCoordinatate B:\(locationCoordinatate)")
        Max_X = compareValue(src: Max_X,ref: CGFloat(locationCoordinatate.latitude), big: true)
        Min_X = compareValue(src: Min_X,ref: CGFloat(locationCoordinatate.latitude), big: false)
        Max_Y = compareValue(src: Max_Y,ref: CGFloat(locationCoordinatate.longitude), big: true)
        Min_Y = compareValue(src: Min_Y,ref: CGFloat(locationCoordinatate.longitude), big: false)
        
        touchPoint = CGPoint(x: screenWidth,y: screenHeight )
        //print("touchPoint :\(touchPoint)")
        locationCoordinatate = mapView.convert(touchPoint, toCoordinateFrom: mapView)
        // addPin(location: locationCoordinatate)
        //print("locationCoordinatate C:\(locationCoordinatate)")
        Max_X = compareValue(src: Max_X,ref: CGFloat(locationCoordinatate.latitude), big: true)
        Min_X = compareValue(src: Min_X,ref: CGFloat(locationCoordinatate.latitude), big: false)
        Max_Y = compareValue(src: Max_Y,ref: CGFloat(locationCoordinatate.longitude), big: true)
        Min_Y = compareValue(src: Min_Y,ref: CGFloat(locationCoordinatate.longitude), big: false)
        
        touchPoint = CGPoint(x: screenWidth,y: 0 )
        //print("touchPoint :\(touchPoint)")
        locationCoordinatate = mapView.convert(touchPoint, toCoordinateFrom: mapView)
        // addPin(location: locationCoordinatate)
        //print("locationCoordinatate D:\(locationCoordinatate)")
        Max_X = compareValue(src: Max_X,ref: CGFloat(locationCoordinatate.latitude), big: true)
        Min_X = compareValue(src: Min_X,ref: CGFloat(locationCoordinatate.latitude), big: false)
        Max_Y = compareValue(src: Max_Y,ref: CGFloat(locationCoordinatate.longitude), big: true)
        Min_Y = compareValue(src: Min_Y,ref: CGFloat(locationCoordinatate.longitude), big: false)
        
        print("Max_X:\(Max_X),Max_Y:\(Max_Y),\nMin_X:\(Min_X),Min_Y:\(Min_Y),")
        
        for Ix  in 0 ... infoData.count - 1 {
            let infoOneRec : NSDictionary = infoData[Ix] as! NSDictionary
            let lat:CGFloat = CGFloat( (infoOneRec.object(forKey: "lat") as! NSString).floatValue )
            let lng:CGFloat = CGFloat( (infoOneRec.object(forKey: "lng") as! NSString).floatValue )
            
            if ( lat < Max_X && lat > Min_X ){
                if ( lng < Max_Y && lng > Min_Y ){
                    let posInfo : CLLocationCoordinate2D = CLLocationCoordinate2D(latitude: CLLocationDegrees(lat),longitude: CLLocationDegrees(lng))
                    let address:String = infoOneRec.object(forKey: "address") as! String
                    let company:String = infoOneRec.object(forKey: "company_name") as! String
                    addPin(location: posInfo , company: company , address: address )
                    signData.add(infoOneRec)
                }
            }
            // print(infoOneRec) // date = "2020-02-01";
        }
    }
    
    
    func compareValue(src:CGFloat,ref:CGFloat, big: Bool)-> CGFloat{
        if (big){
            if (ref > src) { return ref }
            return src
        } else {
            if (ref < src) { return ref }
            return src
        }
    }
    
    
    @objc func addPin(location:CLLocationCoordinate2D , company:String , address:String ){
            print ("addPin")
            let annotation = MKPointAnnotation()
            annotation.title = company
            annotation.subtitle = address
            annotation.coordinate = location
            mapView.addAnnotation(annotation)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView?{
        
        if ( mapView.userLocation.coordinate.longitude == annotation.coordinate.longitude &&
            mapView.userLocation.coordinate.latitude == annotation.coordinate.latitude ){
            print ("mapView.userLocation")
            return nil
        }
        
        print("----------")
        print("annotation.coordinate:  \(annotation.coordinate)")
        print("----------")

         let identifier = "MyPin"
         // 重複使用地圖標註
         var annotationView:MKPinAnnotationView? = mapView.dequeueReusableAnnotationView(withIdentifier: identifier) as? MKPinAnnotationView
         if annotationView == nil {
             annotationView = MKPinAnnotationView(annotation: annotation, reuseIdentifier: identifier)
             annotationView?.canShowCallout = true
             annotationView?.animatesDrop = false
         }
  
        let rightButton = UIButton(frame: CGRect(x: 0, y: 0, width: 80, height: 50))
        rightButton.backgroundColor = UIColor.gray
        rightButton.setTitle("詳細資訊", for: .normal)
        rightButton.tag = 123456
        annotationView!.rightCalloutAccessoryView = rightButton
  
         return annotationView
     }
    
      func mapView(_ mapView: MKMapView, annotationView view: MKAnnotationView, calloutAccessoryControlTapped control: UIControl){
        
        guard let capitalSrc = view.annotation  else {return}

        if ( mapView.userLocation.coordinate.longitude == view.annotation?.coordinate.longitude &&
            mapView.userLocation.coordinate.latitude == view.annotation?.coordinate.latitude ){
            print ("mapView.userLocation")
            return
        }
        
        let capital = capitalSrc as! MKPointAnnotation
        
        // signData
        for Ix in 0 ... signData.count - 1 {
            let infoOneRec : NSDictionary = signData[Ix] as! NSDictionary
            let address:String = infoOneRec.object(forKey: "address") as! String
            let company:String = infoOneRec.object(forKey: "company_name") as! String
            if ( capital.subtitle == address  && capital.title == company ) {
                let name:String = infoOneRec.object(forKey: "name") as! String
                let tel_1:String = infoOneRec.object(forKey: "tel_1") as! String
                let str = "\(company)\n負責人:\(name)\n電話:\(tel_1)\n地址:\(address)"
                let controller = UIAlertController(title: nil, message: str, preferredStyle: .alert)
                let okAction = UIAlertAction(title: "確定", style: .default, handler: nil)
                controller.addAction(okAction)
                present(controller, animated: true, completion: nil)
            }
        }
     }
    
    // trace user Pos
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        /*
            print(locations)

            let userLocation : CLLocation = locations[0]
            let latitude:CLLocationDegrees = userLocation.coordinate.latitude  // Pos
            let longitude:CLLocationDegrees = userLocation.coordinate.longitude  // Pos
            let span: MKCoordinateSpan = MKCoordinateSpan(latitudeDelta: 0.0018, longitudeDelta: 0.0018)
            let location:CLLocationCoordinate2D = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
            let region:MKCoordinateRegion = MKCoordinateRegion(center: location, span: span)
        
            print("latitude:   \(latitude)")
            print("longitude:  \(longitude)")

            mapView.setRegion(region, animated: true)
        */

    }

}
