//
//  HomeViewController.swift
//  tteia
//
//  Created by Cephas Wang Line ID cephaswangtw on  2020/2/12.
//  Copyright © 2020 tteia. All rights reserved.
//
//  https://www.youtube.com/watch?v=i4L69sxj2Ng


import UIKit

// class HomeViewController: UIViewController {
class HomeViewController: BaseViewController, SWRevealViewControllerDelegate {
    
    static var action_1_Dict : NSDictionary = NSDictionary() //活動訊息
    static var action_2_Dict : NSDictionary = NSDictionary() //會務報導
    static var action_3_Dict : NSDictionary = NSDictionary() //招標訊息
    static var action_4_Dict : NSDictionary = NSDictionary() //目前位置查詢
    static var action_6_Dict : NSDictionary = NSDictionary() //電信月刊
    static var action_7_Dict : NSDictionary = NSDictionary() //公會行事曆
    static var action_x_Dict : NSDictionary = NSDictionary() //教育訓練
    
    static var action_1_Logs : NSMutableDictionary = NSMutableDictionary() //活動訊息
    static var action_2_Logs : NSMutableDictionary = NSMutableDictionary() //會務報導
    static var action_3_Logs : NSMutableDictionary = NSMutableDictionary() //招標訊息
    static var action_x_Logs : NSMutableDictionary = NSMutableDictionary() //教育訓練
    
    @IBOutlet weak var b1_count: UILabel! //活動訊息
    @IBOutlet weak var b2_count: UILabel! //會務報導
    @IBOutlet weak var b3_count: UILabel! //招標訊息
    @IBOutlet weak var bx_count: UILabel! //教育訓練
    var noReadSum : Int = 0
    var noReadSum1 : Int = 0
    var noReadSum2 : Int = 0
    var noReadSum3 : Int = 0
    var noReadSum4 : Int = 0
    
    var myUserDefaults :UserDefaults!
    
    @IBOutlet weak var b1: UIButton!
    @IBOutlet weak var b2: UIButton!
    @IBOutlet weak var b3: UIButton!
    @IBOutlet weak var b5: UIButton!
    @IBOutlet weak var b6: UIButton!
    @IBOutlet weak var b7: UIButton!
    @IBOutlet weak var b9: UIButton!
    @IBOutlet weak var b11: UIButton!
    @IBOutlet weak var b12: UIButton!
    
    var timer : Timer = Timer()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("MainPage/Home/HomeViewControllerr")
        

        b2.imageView?.contentMode = .scaleAspectFit
        b3.imageView?.contentMode = .scaleAspectFit
        b5.imageView?.contentMode = .scaleAspectFit
        b6.imageView?.contentMode = .scaleAspectFit
        b7.imageView?.contentMode = .scaleAspectFit
        b9.imageView?.contentMode = .scaleAspectFit
        b11.imageView?.contentMode = .scaleAspectFit
        b12.imageView?.contentMode = .scaleAspectFit
        
        initAct ()
        
        
        let queue = DispatchQueue(label: "sync.run")

        queue.sync {
            // print ("queue.sync")
            apiLodaer_b1()
            apiLodaer_b2()
            apiLodaer_b3()
            apiLodaer_b4()
            apiLodaer_b6()
            // apiLodaer_b7()
            apiLodaer_b12()
        }
        

        
    }
    
    func showBadgeNumber() {
        
        noReadSum = noReadSum1 + noReadSum2 + noReadSum3 + noReadSum4
        print ("\(noReadSum1) + \(noReadSum2) + \(noReadSum3) + \(noReadSum4) = \(noReadSum)")

        if ( noReadSum < 1 ){
            noReadSum = -1
        }

        let badgeCount: Int = noReadSum
        let application = UIApplication.shared
        let center = UNUserNotificationCenter.current()
        center.requestAuthorization(options:[.badge]) { (granted, error) in
            // Enable or disable features based on authorization.
        }
        
        application.registerForRemoteNotifications()
        application.applicationIconBadgeNumber = badgeCount
    }
    
    override func viewWillAppear(_ animated: Bool) {
        // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
        noReadSum = 0
        self.timer = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(updateTable), userInfo: nil, repeats: true)
    }
    
    // https://medium.com/@mikru168/ios-timer-434d91529cdf
    // 設定計時器，檢查是否完成下載，下載後更新表單，並停止計時器
    @objc func updateTable (){
        
        print ("updateTable")
        //活動訊息
        if ( HomeViewController.action_1_Logs != NSMutableDictionary() ){
            print ("updateTable 1")
            let noRead:Int = checkLog(srcInt: 1,keyStr: "act_1")
            noReadSum1 = noRead
            if(noRead>0){
                b1_count.text = String(noRead)
                b1_count.isHidden = false
                b1_count.clipsToBounds = true
                b1_count.layer.cornerRadius = b1_count.bounds.width / 2
            }
        }
        
        //會務報導
        if ( HomeViewController.action_2_Logs != NSMutableDictionary() ){
            print ("updateTable 2")
            let noRead:Int = checkLog(srcInt: 2,keyStr: "act_2")
            noReadSum2 = noRead
            if(noRead>0){
                b2_count.text = String(noRead)
                b2_count.isHidden = false
                b2_count.clipsToBounds = true
                b2_count.layer.cornerRadius = b2_count.bounds.width / 2
            }
        }
        
        //招標訊息
        if ( HomeViewController.action_3_Logs != NSMutableDictionary()  ){
            print ("updateTable 3")
            let noRead:Int = checkLog(srcInt: 3,keyStr: "act_3")
            noReadSum3 = noRead
            if(noRead>0){
                b3_count.text = String(noRead)
                b3_count.isHidden = false
                b3_count.clipsToBounds = true
                b3_count.layer.cornerRadius = b3_count.bounds.width / 2
            }
        }
        
        //教育訓練
        if ( HomeViewController.action_x_Logs != NSMutableDictionary()  ){
            print ("updateTable x")
            let noRead:Int = checkLog(srcInt: 4,keyStr: "act_x")
            noReadSum4 = noRead
            if(noRead>0){
                bx_count.text = String(noRead)
                bx_count.isHidden = false
                bx_count.clipsToBounds = true
                bx_count.layer.cornerRadius = bx_count.bounds.width / 2
            }
        }
        
        if ( HomeViewController.action_1_Logs.count > 0 &&
             HomeViewController.action_2_Logs.count > 0 &&
             HomeViewController.action_3_Logs.count > 0 &&
             HomeViewController.action_x_Logs.count > 0  ){
             self.timer.invalidate()

            showBadgeNumber()
        }
    }
    
    func checkLog (srcInt:Int, keyStr:String) -> Int{
        
        var srcDict = NSMutableDictionary()
        switch srcInt{
        case 1: //活動訊息
             print("checkLog 1a")
            srcDict = HomeViewController.action_1_Logs
            break
        case 2://會務報導
             print("checkLog 2a")
            srcDict = HomeViewController.action_2_Logs
            break
        case 3://招標訊息
             print("checkLog 3a")
            srcDict = HomeViewController.action_3_Logs
            break
        case 4://教育訓練
            print("checkLog 4a")
            srcDict = HomeViewController.action_x_Logs
            break
        default:
            break
        }
        

        var noRead:Int = 0
        let action_Ary:NSArray = srcDict.allKeys as NSArray
        if (action_Ary.count > 0){
            for Ix in 0 ... action_Ary.count - 1 {
                let keyString:String = "\(keyStr)_\(action_Ary[Ix])"
                // print("Chec keyString \(keyString)")
               
                myUserDefaults = UserDefaults.standard
                if let _:String = myUserDefaults.object(forKey: keyString) as? String {
                    // isRead = String()
                    // print("isRead: \(isRead)")
                } else {
                    // print("checkLog keyStr: \(keyStr)")
                    noRead += 1
                }
            }
        }
        print("keyStr: \(keyStr) noRead: \(noRead)")
        return noRead
    }
    
    
    //活動訊息
    func apiLodaer_b1 (){
        let jsonUrlSting = "http://www.tteia.org.tw/api/api_1_0_37.php?mode=get_news_tag&type=1"
        getJson(JsonUrlSting: jsonUrlSting , actionFunc: "showInfo_b1" )
    }
    
    //會務報導
    func apiLodaer_b2 (){
        let jsonUrlSting = "http://www.tteia.org.tw/api/api_1_0_37.php?mode=get_news_tag&type=2"
        getJson(JsonUrlSting: jsonUrlSting , actionFunc: "showInfo_b2" )
    }
    
    //招標訊息
    func apiLodaer_b3 (){
        let jsonUrlSting = "http://www.tteia.org.tw/api/api_1_0_37.php?mode=get_action_2"
        getJson(JsonUrlSting: jsonUrlSting , actionFunc: "showInfo_b3" )
    }
    
    //目前位置查詢
    func apiLodaer_b4 (){
        let jsonUrlSting = String(format:"http://www.tteia.org.tw/api/index.php?mode=map_list")
        print("apiLodaer_b4 ()")
        getJson(JsonUrlSting: jsonUrlSting , actionFunc: "showInfo_b4" )
    }
    
    //電信月刊
    func apiLodaer_b6 (){
        let jsonUrlSting = "http://www.tteia.org.tw/api/magazine.php?mode=magazine_type"
        getJson(JsonUrlSting: jsonUrlSting , actionFunc: "showInfo_b6" )
    }
    
    //公會行事曆
    func apiLodaer_b7 (){
        let A1 = 2020 , B1 = 2
        let jsonUrlSting = String(format:"http://www.tteia.org.tw/api/index.php?mode=get_calendar&year=%d&month=%d", A1,B1)
        print("apiLodaer_b7 ()")
        getJson(JsonUrlSting: jsonUrlSting , actionFunc: "showInfo_b7" )
    }
    

    //教育訓練
    func apiLodaer_b12 (){
        let jsonUrlSting = "http://www.tteia.org.tw/api/api_1_0_37.php?mode=get_action"
        getJson(JsonUrlSting: jsonUrlSting , actionFunc: "showInfo_bx" )
    }
    
    //活動訊息
    @objc func showInfo_b1 (){
        MainMenuController.self.action_1_Dict = HomeViewController.self.action_1_Dict
    }
    
    //會務報導
    @objc func showInfo_b2 (){
        MainMenuController.self.action_2_Dict = HomeViewController.self.action_2_Dict
    }
    
    //目前位置查詢
    @objc func showInfo_b4 (){
        MainMenuController.self.action_4_Dict = HomeViewController.self.action_4_Dict
    }
    
    //招標訊息
    @objc func showInfo_b3 (){
        MainMenuController.self.action_3_Dict = HomeViewController.self.action_3_Dict
    }
    
    //電信月刊
    @objc func showInfo_b6 (){
        MainMenuController.self.action_6_Dict = HomeViewController.self.action_6_Dict
    }
    
    //公會行事曆
    @objc func showInfo_b7 (){
        MainMenuController.self.action_7_Dict = HomeViewController.self.action_7_Dict
    }

    //教育訓練
    @objc func showInfo_bx (){
        MainMenuController.self.action_x_Dict = HomeViewController.self.action_x_Dict
    }
    
// ==============================================================================================================
    // 讀取遠端JSON
    // https://tommy60703.gitbooks.io/swift-language-traditional-chinese/content/chapter2/06_Functions.html#Function_Parameters_and_Return_Values
    // 定義一個輸入輸出參數時，在參數定義前加 inout 關鍵字。一個輸入輸出參數有傳入函式的值，這個值被函式修改，然後被傳出函式，替換原來的值。
    func getJson (JsonUrlSting : String , actionFunc : String )  {
        var jsonDict = NSDictionary()
        // self.action_2_Dict = jsonDict
        
        // Parse JSON
        // https://www.udemy.com/course/ios11swift4/learn/lecture/8103546
        guard URL(string: JsonUrlSting) != nil else { return }
        let urlRequest = URLRequest(url: URL(string: JsonUrlSting)!)
        let task = URLSession.shared.dataTask(with: urlRequest) {(data , resopnse , error ) in
            if error != nil { print(error as Any)  }
            guard let data = data else {return}
            do {
                jsonDict = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as! NSDictionary
                if jsonDict !=  NSDictionary() {
                    print ("json ->OK \(actionFunc)")
                    switch actionFunc {
                        case "showInfo_b1": //活動訊息
                            HomeViewController.self.action_1_Dict = jsonDict
                            
                            guard jsonDict.object(forKey: "outputObject") != nil else{break}
                            self.gen_log(jsonDict: jsonDict,action_Logs: 1)
                            
                            break
                        case "showInfo_b2": //會務報導
                            HomeViewController.self.action_2_Dict = jsonDict
                            guard jsonDict.object(forKey: "outputObject") != nil else{break}
                            self.gen_log(jsonDict: jsonDict,action_Logs: 2)
                            
                            break
                        case "showInfo_b3": //招標訊息
                            HomeViewController.self.action_3_Dict = jsonDict
                            guard jsonDict.object(forKey: "outputObject") != nil else{break}
                            self.gen_log(jsonDict: jsonDict,action_Logs: 3)
                            
                            break
                        
                        case "showInfo_b4": //目前位置查詢
                            HomeViewController.self.action_4_Dict = jsonDict
                            // guard jsonDict.object(forKey: "outputObject") != nil else{break}
                            // self.gen_log(jsonDict: jsonDict,action_Logs: 3)
                            
                            break
                        
                        case "showInfo_b6":
                            HomeViewController.self.action_6_Dict = jsonDict
                            break
                        case "showInfo_b7":
                            HomeViewController.self.action_7_Dict = jsonDict
                            break
                        case "showInfo_bx": //教育訓練
                            HomeViewController.self.action_x_Dict = jsonDict
                            guard jsonDict.object(forKey: "outputObject") != nil else{break}
                            self.gen_log(jsonDict: jsonDict,action_Logs: 4)
                            
                            break
                        default:
                            break
                    }
                }
            } catch let jsonErr {
                print (jsonErr)
            }
           
            // 執行指定的函式
            self.perform(Selector((actionFunc)))
        }
        task.resume()
    }

    func gen_log ( jsonDict:NSDictionary ,action_Logs:Int ){
        guard jsonDict.object(forKey: "outputObject") != nil else{return}
        let srcDic:NSArray = jsonDict.object(forKey: "outputObject") as! NSArray
        for Ix in 0 ... srcDic.count - 1 {
            let oneRow:NSDictionary = srcDic.object(at: Ix) as! NSDictionary
            let id_Val:String = oneRow.object(forKey: "id") as! String
            
            switch action_Logs{
                case 1:
                    HomeViewController.action_1_Logs.setValue("0", forKey: "\(id_Val)")
                    
                    break
                case 2:
                    HomeViewController.action_2_Logs.setValue("0", forKey: "\(id_Val)")
                    break
                case 3:
                    HomeViewController.action_3_Logs.setValue("0", forKey: "\(id_Val)")
                    break
                case 4:
                    HomeViewController.action_x_Logs.setValue("0", forKey: "\(id_Val)")
                break
            default:
                break
            }
        }
    
        print("HomeViewController.action_1_Logs.count\(HomeViewController.action_1_Logs.count)")
       // b1_count.text = String(HomeViewController.action_1_Logs.count)
       // b1_count.isHidden = false
    }
    
    
    func initAct (){

        // Swift 中的 Selector
        // https://www.jianshu.com/p/f3f2c663115d
        b1.addTarget(self,   action: #selector(openPage as (UIButton) -> ()) ,  for: .touchUpInside)
        b2.addTarget(self,   action: #selector(openPage as (UIButton) -> ()) ,  for: .touchUpInside)
        b3.addTarget(self,   action: #selector(openPage as (UIButton) -> ()) ,  for: .touchUpInside)
        b5.addTarget(self,   action: #selector(openPage as (UIButton) -> ()) ,  for: .touchUpInside)
        b6.addTarget(self,   action: #selector(openPage as (UIButton) -> ()) ,  for: .touchUpInside)
        b7.addTarget(self,   action: #selector(openPage as (UIButton) -> ()) ,  for: .touchUpInside)
        b9.addTarget(self,   action: #selector(openPage as (UIButton) -> ()) ,  for: .touchUpInside)
        b11.addTarget(self,  action: #selector(openPage as (UIButton) -> ()) ,  for: .touchUpInside)
        b12.addTarget(self,  action: #selector(openPage as (UIButton) -> ()) ,  for: .touchUpInside)
    }
    

    @objc func openPage(SW : UIButton){
        print("backHome SW.tag: \(SW.tag)")
        
        var openView : UIViewController = UIViewController()
        switch SW.tag {
        case 1:// 活動訊息 MainPage/FrontView/PostTableViewController
            // 1 活動訊息  2會務報導
            let outVX : PostTableViewController =  PostTableViewController(nibName: "PostTableViewController", bundle: nil)
            outVX.srcDict = HomeViewController.self.action_1_Dict
            openView = outVX
            openView.title = "1"
            break
            
        case 2: // 會務報導 MainPage/FrontView/PostTableViewController
            // 1 活動訊息  2會務報導
            let outVX : PostTableViewController =  PostTableViewController(nibName: "PostTableViewController", bundle: nil)
            outVX.srcDict = HomeViewController.self.action_2_Dict
            openView = outVX
            openView.title = "2"
            break
            
        case 3: // 招標訊息 MainPage/FrontView/ActionTableViewController
            let outVX : ActionTableViewController =  ActionTableViewController(nibName: "ActionTableViewController", bundle: nil)
            outVX.srcDict = HomeViewController.self.action_3_Dict
            openView = outVX
            break
            
        case 5: // 聯絡我們 MainPage/RearView/TempWebViewController
            openView = TempWebViewController(nibName: "TempWebViewController", bundle: nil)
            break
             

        case 6: // 電信月刊 MainPage/Push/MagazineFolderView
            let outVX : MagazineFolderView =  MagazineFolderView(nibName: "MagazineFolderView", bundle: nil)
            outVX.srcDict = HomeViewController.self.action_6_Dict
            openView = outVX
            break
            
        case 7: // 公會行事曆 MainPage/Calender/CalendarView
            let outVX : CalendarView =  CalendarView(nibName: "CalendarView", bundle: nil)
            outVX.srcDict = HomeViewController.self.action_7_Dict
            openView = outVX
            break
                
        case 9: // 目前位置查詢 MainPage/Map/GpsMapView
            let outVX : GpsMapView =  GpsMapView(nibName: "GpsMapView", bundle: nil)
            outVX.srcDict = HomeViewController.self.action_4_Dict
            openView = outVX
            break
            
        case 11: // 會員資料查詢 MainPage/UserList/UserAreaViewController
            openView = UserAreaViewController(nibName: "UserAreaViewController", bundle: nil)
            break
            
        case 12: // 教育訓練 MainPage/FrontView/EducationTableViewController
            let outVX : EducationTableViewController =  EducationTableViewController(nibName: "EducationTableViewController", bundle: nil)
            outVX.srcDict = HomeViewController.self.action_x_Dict
            openView = outVX
            break
            
        default:
            openView = HomeViewController(nibName: "HomeViewController", bundle: nil)
            break
            
        }
        
        GotoPage(destView: openView)
    }
    
    func GotoPage (destView : UIViewController){
        
        let frontNav = UINavigationController(rootViewController: destView)

        let mainMenuController = MainMenuController(nibName: "MainMenuController", bundle: nil)
        let rearView = UINavigationController(rootViewController: mainMenuController)

        let SWReveal = SWRevealViewController(rearViewController: rearView, frontViewController: frontNav)
        SWReveal!.modalPresentationStyle = .overFullScreen // 由下而上，全部頁面
        SWReveal?.rearViewRevealDisplacement = 0
        
        let revealController : SWRevealViewController  = self.revealViewController()
        revealController.setFront(SWReveal, animated: true)
 
    }
    
    
    /*
    // https://medium.com/@mikru168/ios-%E5%8F%96%E5%BE%97%E6%96%87%E5%AD%97%E9%AB%98%E5%BA%A6%E7%9A%84%E6%96%B9%E5%BC%8F-d338893aedee
    // 利用UILabel來取得文字的高度
    // 详解UIView的frame、bounds和center属性
    // https://www.jianshu.com/p/c16c32c45862
    func getHeight(withLabelText text: String, width: CGFloat, font: UIFont) -> CGFloat {
        let label: UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: width, height: CGFloat(MAXFLOAT)))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        label.sizeToFit()
        return label.frame.height
    }
    */
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
