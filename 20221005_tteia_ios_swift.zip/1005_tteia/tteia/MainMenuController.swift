//
//  MenuController.swift
//  tteia
//
//  Created by Cephas Wang Line ID cephaswangtw on  2020/2/12.
//  Copyright © 2020 tteia. All rights reserved.
//  REF MainPage/RearView/AccountViewController

import UIKit

class MainMenuController: UIViewController , UITableViewDelegate, UITableViewDataSource   {
    
    static var action_1_Dict : NSDictionary = NSDictionary() //活動訊息
    static var action_2_Dict : NSDictionary = NSDictionary() //會務報導
    static var action_3_Dict : NSDictionary = NSDictionary() //招標訊息
    static var action_4_Dict : NSDictionary = NSDictionary() //目前位置查詢
    static var action_6_Dict : NSDictionary = NSDictionary() //電信月刊
    static var action_7_Dict : NSDictionary = NSDictionary() 
    static var action_8_Dict : NSDictionary = NSDictionary() //公會行事曆
    static var action_x_Dict : NSDictionary = NSDictionary() //教育訓練
    // 電信月刊
    
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var btnHome: UIButton!
    var homeViewController: UINavigationController?
    
    let menuOptions = ["首頁","會員資料查詢","教育訓練","會務報導","目前位置查詢",
                       "活動訊息","招標訊息","公會行事曆","電信月刊","聯絡我們",
                       "其他會員查詢","登入/登出"]
    let imgArr = ["nav_home.png","nav_user.png","nav_education.png","nav_report.png","nav_nearby.png",
                  "nav_news.png","nav_bidding.png","nav_calendar","nav_read.png","nav_contact.png",
                  "nav_otheruser.png","nav_profile.png"]
    
    var _previouslySelectedRow : NSInteger = -1
    

    // How to fill background image of an UIView
    // https://stackoverflow.com/questions/8077740/how-to-fill-background-image-of-an-uiview
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        UIGraphicsBeginImageContext(view.frame.size)
        UIImage(named: "nav_bg.jpg")?.draw(in: self.view.bounds)
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        view.backgroundColor = UIColor.init(patternImage: image!)
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.tableView.delegate = self
        self.tableView.dataSource = self
       // self.tableView.backgroundColor = .clear
        
        // 不顯示導航條
        // self.navigationController?.isNavigationBarHidden = true
        
        
        // https://www.jianshu.com/p/8fac2006dbe5
        // iOS navigationBar小技巧-隐藏灰线与设置背景图片
        // 導航條去背顯示背景圖
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: UIBarMetrics.default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        
        
        /*
        btnHome.addTarget(self.revealViewController(),
                             action: #selector(SWRevealViewController.revealToggle(_:)) ,
                             for: .touchUpInside)
        */
        
        // https://www.jianshu.com/p/f3f2c663115d
        // Swift 中的 Selector
        btnHome.addTarget(self,
                          action: #selector(MainMenuController.backHome) ,
                        for: .touchUpInside)

    }

    @objc func backHome(){
        let homeView = HomeViewController(nibName: "HomeViewController", bundle: nil)
        GotoPage(destView: homeView)
    }
    
    func GotoPage (destView : UIViewController){
        
        let frontNav = UINavigationController(rootViewController: destView)

        let mainMenuController = MainMenuController(nibName: "MainMenuController", bundle: nil)
        let rearView = UINavigationController(rootViewController: mainMenuController)

        let SWReveal = SWRevealViewController(rearViewController: rearView, frontViewController: frontNav)
        SWReveal!.modalPresentationStyle = .overFullScreen // 由下而上，全部頁面
        SWReveal?.rearViewRevealDisplacement = 0
        
        let revealController : SWRevealViewController  = self.revealViewController()
        revealController.setFront(SWReveal, animated: true)
        revealController.revealToggle(animated: true)
    }
    
    
    // MARK: - Table view data source

     func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
         _previouslySelectedRow = -1;
         return menuOptions.count
     }
     
     func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
         
         let cell = UITableViewCell(style: UITableViewCell.CellStyle.subtitle , reuseIdentifier: "Cell")
         cell.textLabel?.text = menuOptions[indexPath.row]
         cell.textLabel?.textColor = .white
         let image : UIImage = UIImage(named: imgArr[indexPath.row])!
         cell.imageView?.image = image
         cell.backgroundColor = .clear
         
         // 彼得潘的-swift-ios-app-開發問題解答集/設定表格-cell-點選時的背景顏色
         // https://medium.com/%E5%BD%BC%E5%BE%97%E6%BD%98%E7%9A%84-swift-ios-app-%E9%96%8B%E7%99%BC%E5%95%8F%E9%A1%8C%E8%A7%A3%E7%AD%94%E9%9B%86/%E8%A8%AD%E5%AE%9A%E8%A1%A8%E6%A0%BC-cell-%E9%BB%9E%E9%81%B8%E6%99%82%E7%9A%84%E8%83%8C%E6%99%AF%E9%A1%8F%E8%89%B2-b59d0abe4b9d
         let selectedBackgroundView = UIView()
         selectedBackgroundView.backgroundColor = .black
         cell.selectedBackgroundView = selectedBackgroundView
         
         return cell
     }
     
    
    func tableView(_ tableView: UITableView, willSelectRowAt indexPath: IndexPath) -> IndexPath? {
        NSLog("willSelectRowAt indexPath:\(indexPath)")
        

        let row : NSInteger  = indexPath.row
        
        /*
        let revealController : SWRevealViewController  = self.revealViewController()
        
        if ( row == _previouslySelectedRow ){
            revealController.revealToggle(animated: true)
        }
        */
        
        NSLog("indexPath.row:\(row)")
        
        var openView : UIViewController = UIViewController()
        
        openView = HomeViewController(nibName: "HomeViewController", bundle: nil)

        switch row {
            
        case 0: // 首頁 MainPage/Home/HomeViewController
            openView = HomeViewController(nibName: "HomeViewController", bundle: nil)
            break
            
        case 1:// 會員資料查詢 MainPage/UserList/UserAreaViewController
            openView = UserAreaViewController(nibName: "UserAreaViewController", bundle: nil)
            break
            
        case 2: // 教育訓練 MainPage/FrontView/EducationTableViewController
            let outVX : EducationTableViewController =  EducationTableViewController(nibName: "EducationTableViewController", bundle: nil)
            outVX.srcDict = MainMenuController.self.action_x_Dict
            openView = outVX
            break
            
        case 3:// 會務報導 MainPage/FrontView/PostTableViewController
            // 1 活動訊息  2會務報導
            let outVX : PostTableViewController =  PostTableViewController(nibName: "PostTableViewController", bundle: nil)
            outVX.srcDict = MainMenuController.self.action_2_Dict
            openView = outVX
            openView.title = "2"
            break
            
        case 4:  // 目前位置查詢 MainPage/Map/GpsMapView
            let outVX : GpsMapView = GpsMapView(nibName: "GpsMapView", bundle: nil)
            outVX.srcDict = MainMenuController.self.action_4_Dict
            openView = outVX
            break
                    
        case 5:// 活動訊息 MainPage/FrontView/PostTableViewController
            // 1 活動訊息  2會務報導
            let outVX : PostTableViewController =  PostTableViewController(nibName: "PostTableViewController", bundle: nil)
            outVX.srcDict = MainMenuController.self.action_1_Dict
            openView = outVX
            openView.title = "1"
            break
            
        case 6:// 招標訊息 MainPage/FrontView/ActionTableViewController
            let outVX : ActionTableViewController =  ActionTableViewController(nibName: "ActionTableViewController", bundle: nil)
            outVX.srcDict = MainMenuController.self.action_3_Dict
            openView = outVX
            break
                
        case 7: // 公會行事曆 MainPage/Calender/CalendarView
            let outVX : CalendarView =  CalendarView(nibName: "CalendarView", bundle: nil)
            outVX.srcDict = MainMenuController.self.action_7_Dict
            openView = outVX
            break
                
        case 8: // 電信月刊 MainPage/Push/MagazineFolderView
            let outVX : MagazineFolderView =  MagazineFolderView(nibName: "MagazineFolderView", bundle: nil)
            outVX.srcDict = MainMenuController.self.action_6_Dict
            openView = outVX
            break
                
        case 9: // 聯絡我們 MainPage/RearView/TempWebViewController
            openView = TempWebViewController(nibName: "TempWebViewController", bundle: nil)
            break
            
        case 10: // 其他會員查詢 /MainPage/UserList/UserSearch/UserSearchViewController
            openView = UserSearchViewController(nibName: "UserSearchViewController", bundle: nil)
            break
                
        case 11:// 登入/登出 MainPage/FrontView/LoginView/LogoutViewController
            let myUserDefaults : UserDefaults = UserDefaults.standard
            
            guard (myUserDefaults.object(forKey: "showLoginStatus") != nil) else {
                print("showLoginStatus: nil")
                openView = LoginViewController(nibName: "LoginViewController", bundle: nil)
                break
            }
            
            let showLoginStatus: String = myUserDefaults.object(forKey: "showLoginStatus") as! String
            if ( showLoginStatus == "0" ){
                print("showLoginStatus: \(showLoginStatus)")
                openView = LoginViewController(nibName: "LoginViewController", bundle: nil)
            } else {
                print("showLoginStatus: \(showLoginStatus)")
                openView = LogoutViewController(nibName: "LogoutViewController", bundle: nil)
            }
            break

        default:
            break
        }
        
        GotoPage(destView: openView)
        
        return indexPath;
    }
    

     
    /*
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "reuseIdentifier", for: indexPath)

        // Configure the cell...

        return cell
    }
    */

    /*
    // Override to support conditional editing of the table view.
    override func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            // Delete the row from the data source
            tableView.deleteRows(at: [indexPath], with: .fade)
        } else if editingStyle == .insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(_ tableView: UITableView, moveRowAt fromIndexPath: IndexPath, to: IndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(_ tableView: UITableView, canMoveRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
