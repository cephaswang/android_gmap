//
//  LogoutViewController.swift
//  tteia
//
//  Created by admin on 2020/2/13.
//  Copyright © 2020 tteia. All rights reserved.
//

import UIKit

class LogoutViewController: BaseViewController , UITableViewDataSource, UITableViewDelegate {

    var myUserDefaults :UserDefaults!
    
    let menuOptions = ["首頁","會員資料查詢","教育訓練","會務報導","目前位置查詢",
                       "活動訊息","招標訊息","公會行事曆","電信月刊","聯絡我們",
                       "其他會員查詢","登入/登出"]
    
    @IBOutlet weak var switchPush: UISwitch!
    @IBOutlet weak var logout: UIButton!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var image: UIImageView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        print("MainPage/FrontView/LoginView/LogoutViewController")
        
        // Do any additional setup after loading the view.

        setupRightOneNavItems(self , actionOne: #selector(super.backHome))

    }
    
    
    @IBAction func LogOutAction(_ sender: Any) {
        print("LogOutAction")
        
        self.myUserDefaults = UserDefaults.standard
        self.myUserDefaults.setValue("0", forKey: "showLoginStatus")
        
        let openView = HomeViewController(nibName: "HomeViewController", bundle: nil)
        let frontNav = UINavigationController(rootViewController: openView)

        let mainMenuController = MainMenuController(nibName: "MainMenuController", bundle: nil)
        let rearView = UINavigationController(rootViewController: mainMenuController)

        let SWReveal = SWRevealViewController(rearViewController: rearView, frontViewController: frontNav)
        SWReveal!.modalPresentationStyle = .overFullScreen // 由下而上，全部頁面
        SWReveal?.rearViewRevealDisplacement = 0
        
        let revealController : SWRevealViewController  = self.revealViewController()
        revealController.setFront(SWReveal, animated: true)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return menuOptions.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell(style: UITableViewCell.CellStyle.subtitle , reuseIdentifier: "Cell")
        cell.textLabel?.text = menuOptions[indexPath.row]
        //cell.textLabel?.textColor = .white
        //let image : UIImage = UIImage(named: imgArr[indexPath.row])!
        //cell.imageView?.image = image
        // cell.backgroundColor = .clear
        
        // 彼得潘的-swift-ios-app-開發問題解答集/設定表格-cell-點選時的背景顏色
        // https://medium.com/%E5%BD%BC%E5%BE%97%E6%BD%98%E7%9A%84-swift-ios-app-%E9%96%8B%E7%99%BC%E5%95%8F%E9%A1%8C%E8%A7%A3%E7%AD%94%E9%9B%86/%E8%A8%AD%E5%AE%9A%E8%A1%A8%E6%A0%BC-cell-%E9%BB%9E%E9%81%B8%E6%99%82%E7%9A%84%E8%83%8C%E6%99%AF%E9%A1%8F%E8%89%B2-b59d0abe4b9d
        let selectedBackgroundView = UIView()
        selectedBackgroundView.backgroundColor = .black
        cell.selectedBackgroundView = selectedBackgroundView
        
        return cell
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
