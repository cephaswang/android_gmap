//
//  BaseViewController.swift
//  tteia
//
//  Created by admin on 2020/2/13.
//  Copyright © 2020 tteia. All rights reserved.
//

import UIKit
import SystemConfiguration

// https://www.hangge.com/blog/cache/detail_1583.html
extension String {
     
    //将原始的url编码为合法的url
    func urlEncoded() -> String {
        let encodeUrlString = self.addingPercentEncoding(withAllowedCharacters:
            .urlQueryAllowed)
        return encodeUrlString ?? ""
    }
     
    //将编码后的url转换回原始的url
    func urlDecoded() -> String {
        return self.removingPercentEncoding ?? ""
    }
}


class BaseViewController: UIViewController {
    
    static var srcDictBase:NSDictionary = NSDictionary()
    var Network:Int = 0 // 1 ok , 2 error
    var timerBase  :Timer = Timer()

    override func viewDidLoad() {
        super.viewDidLoad()

        setupLeftNavItems()
        
        setupNavTitleImage()
        
        isConnectedToNetwork()
        
        self.timerBase = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(checkNetWork), userInfo: nil, repeats: true)
        
        // noNetAlert()
        // setupRightOneNavItems(self , actionOne: #selector(backHome))
        // setupRightOneNavItems(action: Selector(("backHome")))
    }
    
    @objc func checkNetWork () {
        
        if (Network == 1){
            self.timerBase.invalidate()
            return
        }
        
        if (Network == 2){
            let alert = UIAlertController(title: "無法取得網路連線", message: "部份功能必需在網路連線狀態下執行，請確定您是否巳連線上網！" , preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "確認", style: .default, handler: nil))
            present(alert, animated: true, completion: nil)
            self.timerBase.invalidate()
        }
    }
    
 
    // ==============================================================================================================
    // 讀取遠端JSON
    // https://tommy60703.gitbooks.io/swift-language-traditional-chinese/content/chapter2/06_Functions.html#Function_Parameters_and_Return_Values
    // 定義一個輸入輸出參數時，在參數定義前加 inout 關鍵字。一個輸入輸出參數有傳入函式的值，這個值被函式修改，然後被傳出函式，替換原來的值。
    func getJsonBase (JsonUrlSting : String , actionFunc : Selector )  {
        var jsonDict = NSDictionary()

        // print ("getJsonBase JsonUrlSting: \(JsonUrlSting)")
        
        // Parse JSON
        // https://www.udemy.com/course/ios11swift4/learn/lecture/8103546
        guard URL(string: JsonUrlSting) != nil else { return }
        let urlRequest = URLRequest(url: URL(string: JsonUrlSting)!)
        let task = URLSession.shared.dataTask(with: urlRequest) {(data , resopnse , error ) in
            // print ("resopnse:---> \(String(describing: resopnse))")
            // print ("data:-->\r\n\(String(describing: data))\r\n")
            
            if error != nil { print(error as Any)  }
            guard let data = data else {return}
            do {
                jsonDict = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as! NSDictionary
                if jsonDict != NSDictionary() {
                    print ("json ->OK")
                    // print(jsonDict)
                }
            } catch let jsonErr {
                print ("jsonErr\(jsonErr)")
            }
           
            BaseViewController.self.srcDictBase = jsonDict
            // 執行指定的函式
            self.perform(actionFunc)
        }
        task.resume()
    }

    func checkState () {
        let myUserDefaults : UserDefaults = UserDefaults.standard
        
        guard (myUserDefaults.object(forKey: "showLoginStatus") != nil) else {
            print("showLoginStatus: nil")
            CheckLogin()
            return
        }
        
        let showLoginStatus: String = myUserDefaults.object(forKey: "showLoginStatus") as! String
        if ( showLoginStatus == "0" ){
            print("showLoginStatus: \(showLoginStatus)")
            CheckLogin()
        } else {
            print("showLoginStatus: \(showLoginStatus)")
        }
    }

    // Check for internet connection availability in Swift
    // https://stackoverflow.com/questions/25398664/check-for-internet-connection-availability-in-swift
    
    func isConnectedToNetwork() {

       // 创建一个会话，这个会话可以复用
        let session = URLSession(configuration: .default)
        // 设置URL
        let url = "http://google.com/"
        let UrlRequest = URLRequest(url: URL(string: url)!)
        // 创建一个网络任务
        let task = session.dataTask(with: UrlRequest) {(data, response, error) in
            if let httpResponse = response as? HTTPURLResponse {
                print("statusCode \(httpResponse.statusCode)")
                self.Network = 1
            }
            
             // 1 ok , 2 error
            if ( error != nil ){
                self.Network = 2
                print("error xx nil")
            }
        }
        // 运行此任务
        task.resume()
    }
    
    func CheckLogin_01(){
    }
    
    func CheckLogin(){
        let alert = UIAlertController(title: "請先登入", message: nil , preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "確認", style: .default, handler:{ (_) in
            
            let openView = LoginViewController(nibName: "LoginViewController", bundle: nil)
            let frontNav = UINavigationController(rootViewController: openView)

            let mainMenuController = MainMenuController(nibName: "MainMenuController", bundle: nil)
            let rearView = UINavigationController(rootViewController: mainMenuController)

            let SWReveal = SWRevealViewController(rearViewController: rearView, frontViewController: frontNav)
            SWReveal!.modalPresentationStyle = .overFullScreen // 由下而上，全部頁面
            SWReveal?.rearViewRevealDisplacement = 0
                   
            let revealController : SWRevealViewController  = self.revealViewController()
            revealController.setFront(SWReveal, animated: true)
            
        }))
        
        present(alert, animated: true, completion: nil)
    }
    
    
    func setupRightTwoNavItems(_ target: Any?  , actionOne: Selector , actionTwo: Selector){
        
         let resetButton = UIButton(type:.system)
         resetButton.addTarget(target ,  action: actionOne ,for: .touchUpInside)
         resetButton.setImage(UIImage(named:"icon_read")?.withRenderingMode(.alwaysOriginal), for: .normal)
         resetButton.frame =  CGRect(x: 0, y: 0, width: 34, height: 34)
         resetButton.contentMode = .scaleToFill
        
         let backButton = UIButton(type:.system)
         backButton.addTarget(target ,  action: actionTwo ,for: .touchUpInside)
         backButton.setImage(UIImage(named:"icon_arrow")?.withRenderingMode(.alwaysOriginal), for: .normal)
         backButton.frame =  CGRect(x: 0, y: 0, width: 34, height: 34)
         backButton.contentMode = .scaleToFill

         navigationItem.rightBarButtonItems = [UIBarButtonItem(customView: backButton),
                                               UIBarButtonItem(customView: resetButton)]
    }
    
    func setupRightOneNavItems( _ target: Any?  , actionOne: Selector){

         let backButton = UIButton(type:.system)
         backButton.addTarget(target ,  action: actionOne ,for: .touchUpInside)
         backButton.setImage(UIImage(named:"icon_arrow")?.withRenderingMode(.alwaysOriginal), for: .normal)
         backButton.frame =  CGRect(x: 0, y: 0, width: 34, height: 34)
         backButton.contentMode = .scaleToFill

         navigationItem.rightBarButtonItem =  UIBarButtonItem(customView: backButton)
    }
    

    @objc func backHome (){
        
          print ("BaseViewController: backHome")

           let homePage = HomeViewController(nibName: "HomeViewController", bundle: nil)
           let frontNav = UINavigationController(rootViewController: homePage)

           let mainMenuController = MainMenuController(nibName: "MainMenuController", bundle: nil)
           let rearView = UINavigationController(rootViewController: mainMenuController)

           let SWReveal = SWRevealViewController(rearViewController: rearView, frontViewController: frontNav)
           SWReveal!.modalPresentationStyle = .overFullScreen // 由下而上，全部頁面
           SWReveal?.rearViewRevealDisplacement = 0
           
           let revealController : SWRevealViewController  = self.revealViewController()

           revealController.setFront(SWReveal, animated: true)
    }
    
    
    func setupLeftNavItems(){
            
        let memuButton = UIButton(type:.system)
        memuButton.addTarget(self.revealViewController(),
                                action: #selector(SWRevealViewController.revealToggle(_:)) ,
                                for: .touchUpInside)
        memuButton.setImage(UIImage(named:"icon_menu.png")?.withRenderingMode(.alwaysOriginal), for: .normal)
        memuButton.frame =  CGRect(x: 0, y: 0, width: 34, height: 34)
        memuButton.contentMode = .scaleToFill
        navigationItem.leftBarButtonItem = UIBarButtonItem(customView: memuButton)
            
    }
    
    func setupNavTitleImage(){
        /*
        // How can I change height of Navigation Bar - Swift 3
        // https://stackoverflow.com/questions/40751366/how-can-i-change-height-of-navigation-bar-swift-3
        let boundsS = self.navigationController!.navigationBar.bounds
        print("bounds: \(String(describing: boundsS))")
        
        let bounds = self.navigationController!.navigationBar.bounds

        let backImage:UIImage = UIImage(named: "title")!
        let deviceName:String = UIDevice.modelName

        print("UIDevice.modelName: \(UIDevice.modelName)")
        
        
        var rate : CGFloat = 1
        switch (deviceName){
            case "iPhone 7" , "Simulator iPhone 7":
                rate = 1.7
                break
            case "iPhone 7 Plus" , "Simulator iPhone 7 Plus":
                rate = 1.7
                break
            case "iPhone 8" , "Simulator iPhone 8":
                rate = 1.7
                break
            case "iPhone 8 Plus" , "Simulator iPhone 8 Plus":
                rate = 1.7 // ok
                break
            case "iPhone X" , "Simulator iPhone X":
                rate = 2.6
                break
            case "iPhone X Plus" , "Simulator iPhone X Plus":
                rate = 2.6
                break
            
            case "iPhone XS" , "Simulator iPhone XS":
                rate = 2.6
                break
            case "iPhone XS Max" , "Simulator iPhone XS Max":
                rate = 2.6
                break
            
            case "iPhone 11" , "Simulator iPhone 11":
                rate = 2.6
                break
            case "iPhone 11 Pro" , "Simulator iPhone 11 Pro":
                rate = 2.5
                break
            case "iPhone 11 Pro Max" , "Simulator iPhone 11 Pro Max":
                rate = 2.6
                break

            default:
                rate = 1.4
        }
        print("rate :\(rate)")
        
        
        let bounds_height = bounds.height * rate
        let UpdateImage = resizeImage(image: backImage , targetSize: CGSize( width: bounds.width , height:bounds_height ) )
         */

        
        // https://stackoverflow.com/questions/26052454/ios-8-navigationbar-backgroundimage
        // iOS 8 NavigationBar BackgroundImage
        // If you want to fill the image in navigation bar just use the code:
        navigationController?.navigationBar.setBackgroundImage(UIImage(named: "title2020.jpg")!.resizableImage(withCapInsets: UIEdgeInsets.zero, resizingMode: .stretch), for: .default)
        
        // let cubeIcon = UIImageView(image: UIImage(named: "title123")! )
        // cubeIcon.contentMode = .scaleAspectFit
        // self.navigationItem.backBarButtonItem?.image = cubeIcon.image

    }
    
    


     func resizeImage(image: UIImage, targetSize: CGSize) -> UIImage {
        let size = image.size

        let widthRatio  = targetSize.width  / size.width
        let heightRatio = targetSize.height / size.height

        // Figure out what our orientation is, and use that to form the rectangle
        var newSize: CGSize
        if(widthRatio > heightRatio) {
            newSize = CGSize(width: size.width * heightRatio, height: size.height * heightRatio)
        } else {
            newSize = CGSize(width: size.width * widthRatio,  height: size.height * widthRatio)
        }

        newSize = CGSize(width: size.width * widthRatio,  height: size.height * heightRatio)
        
        // This is the rect that we've calculated out and this is what is actually used below
        let rect = CGRect(x: 0, y: 0, width: newSize.width, height: newSize.height)

        // Actually do the resizing to the rect using the ImageContext stuff
        UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
        image.draw(in: rect)
        let newImage = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        return newImage!
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */
    
    // https://medium.com/@mikru168/ios-%E5%8F%96%E5%BE%97%E6%96%87%E5%AD%97%E9%AB%98%E5%BA%A6%E7%9A%84%E6%96%B9%E5%BC%8F-d338893aedee
    // 利用UILabel來取得文字的高度
    // 详解UIView的frame、bounds和center属性
    // https://www.jianshu.com/p/c16c32c45862
    func getHeight(withLabelText text: String, width: CGFloat, font: UIFont) -> CGFloat {
        let label: UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: width, height: CGFloat(MAXFLOAT)))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        label.sizeToFit()
        let currentHeight : CGFloat = label.frame.height
        label.removeFromSuperview()
        return currentHeight
    }
    

    
    
    // 將 Plist 寫入檔案
    func writeDocuDict (destFileName:String , dictSource : NSDictionary ){
        // 將 Plist 寫入檔案
        // print ( verseDict )
        // Write to plist file in Swift
        // https://stackoverflow.com/questions/24692746/write-to-plist-file-in-swift
        do {
            let plistpath = try FileManager.default.url(
                for: .documentDirectory,
                in: .userDomainMask,
                appropriateFor: nil,
                create: true
                ).appendingPathComponent(destFileName )
               print ( plistpath )
            dictSource.write(toFile: plistpath.path, atomically: false)
        } catch {
            print (error.localizedDescription)
        }
    }
    
    // 讀取 PLIST 文件
    func readDocuDict (fileName:String ) ->NSDictionary{
        var dataDict : NSDictionary = [:]
        do {
            let plistPath  = try FileManager.default.url(
                for: .documentDirectory,
                in: .userDomainMask,
                appropriateFor: nil,
                create: true
                ).appendingPathComponent(fileName )
            
              print ( plistPath )
            
            // https://codeday.me/bug/20170910/71349.html
            // 檔案不存在
            let fileManager = FileManager.default.fileExists(atPath: plistPath.path)
            if !fileManager {
                return [:]
            }
                // print ("plistXML\(plistXML)")
            var plistData: [String: AnyObject] = [:]
                // How do I get a plist as a Dictionary in Swift?
                // https://stackoverflow.com/questions/24045570/how-do-i-get-a-plist-as-a-dictionary-in-swift
            do {//convert the data to a dictionary and handle errors.
                
                var propertyListForamt = PropertyListSerialization.PropertyListFormat.xml //Format of the Property List.
                let plistXML = FileManager.default.contents(atPath: plistPath.path)!
                
                plistData = try PropertyListSerialization.propertyList(from: plistXML, options: .mutableContainersAndLeaves, format: &propertyListForamt) as! [String:AnyObject]
            } catch {
                //, format: \(propertyListForamt)"
                print("Error reading plist: \(error)")
            }
            dataDict = plistData as NSDictionary
        } catch {
            print (error.localizedDescription)
        }
        // print ("dataDict\(dataDict)")
        return dataDict
    }
    
    
}

// How to determine the current iPhone/device model?
// https://stackoverflow.com/questions/26028918/how-to-determine-the-current-iphone-device-model
extension UIDevice {

    static let modelName: String = {
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }

        func mapToDevice(identifier: String) -> String { // swiftlint:disable:this cyclomatic_complexity
            #if os(iOS)
            switch identifier {
            case "iPod5,1":                                 return "iPod touch (5th generation)"
            case "iPod7,1":                                 return "iPod touch (6th generation)"
            case "iPod9,1":                                 return "iPod touch (7th generation)"
            case "iPhone3,1", "iPhone3,2", "iPhone3,3":     return "iPhone 4"
            case "iPhone4,1":                               return "iPhone 4s"
            case "iPhone5,1", "iPhone5,2":                  return "iPhone 5"
            case "iPhone5,3", "iPhone5,4":                  return "iPhone 5c"
            case "iPhone6,1", "iPhone6,2":                  return "iPhone 5s"
            case "iPhone7,2":                               return "iPhone 6"
            case "iPhone7,1":                               return "iPhone 6 Plus"
            case "iPhone8,1":                               return "iPhone 6s"
            case "iPhone8,2":                               return "iPhone 6s Plus"
            case "iPhone9,1", "iPhone9,3":                  return "iPhone 7"
            case "iPhone9,2", "iPhone9,4":                  return "iPhone 7 Plus"
            case "iPhone8,4":                               return "iPhone SE"
            case "iPhone10,1", "iPhone10,4":                return "iPhone 8"
            case "iPhone10,2", "iPhone10,5":                return "iPhone 8 Plus"
            case "iPhone10,3", "iPhone10,6":                return "iPhone X"
            case "iPhone11,2":                              return "iPhone XS"
            case "iPhone11,4", "iPhone11,6":                return "iPhone XS Max"
            case "iPhone11,8":                              return "iPhone XR"
            case "iPhone12,1":                              return "iPhone 11"
            case "iPhone12,3":                              return "iPhone 11 Pro"
            case "iPhone12,5":                              return "iPhone 11 Pro Max"
            case "iPad2,1", "iPad2,2", "iPad2,3", "iPad2,4":return "iPad 2"
            case "iPad3,1", "iPad3,2", "iPad3,3":           return "iPad (3rd generation)"
            case "iPad3,4", "iPad3,5", "iPad3,6":           return "iPad (4th generation)"
            case "iPad6,11", "iPad6,12":                    return "iPad (5th generation)"
            case "iPad7,5", "iPad7,6":                      return "iPad (6th generation)"
            case "iPad7,11", "iPad7,12":                    return "iPad (7th generation)"
            case "iPad4,1", "iPad4,2", "iPad4,3":           return "iPad Air"
            case "iPad5,3", "iPad5,4":                      return "iPad Air 2"
            case "iPad11,4", "iPad11,5":                    return "iPad Air (3rd generation)"
            case "iPad2,5", "iPad2,6", "iPad2,7":           return "iPad mini"
            case "iPad4,4", "iPad4,5", "iPad4,6":           return "iPad mini 2"
            case "iPad4,7", "iPad4,8", "iPad4,9":           return "iPad mini 3"
            case "iPad5,1", "iPad5,2":                      return "iPad mini 4"
            case "iPad11,1", "iPad11,2":                    return "iPad mini (5th generation)"
            case "iPad6,3", "iPad6,4":                      return "iPad Pro (9.7-inch)"
            case "iPad6,7", "iPad6,8":                      return "iPad Pro (12.9-inch)"
            case "iPad7,1", "iPad7,2":                      return "iPad Pro (12.9-inch) (2nd generation)"
            case "iPad7,3", "iPad7,4":                      return "iPad Pro (10.5-inch)"
            case "iPad8,1", "iPad8,2", "iPad8,3", "iPad8,4":return "iPad Pro (11-inch)"
            case "iPad8,5", "iPad8,6", "iPad8,7", "iPad8,8":return "iPad Pro (12.9-inch) (3rd generation)"
            case "AppleTV5,3":                              return "Apple TV"
            case "AppleTV6,2":                              return "Apple TV 4K"
            case "AudioAccessory1,1":                       return "HomePod"
            case "i386", "x86_64":                          return "Simulator \(mapToDevice(identifier: ProcessInfo().environment["SIMULATOR_MODEL_IDENTIFIER"] ?? "iOS"))"
            default:                                        return identifier
            }
            #elseif os(tvOS)
            switch identifier {
            case "AppleTV5,3": return "Apple TV 4"
            case "AppleTV6,2": return "Apple TV 4K"
            case "i386", "x86_64": return "Simulator \(mapToDevice(identifier: ProcessInfo().environment["SIMULATOR_MODEL_IDENTIFIER"] ?? "tvOS"))"
            default: return identifier
            }
            #endif
        }

        return mapToDevice(identifier: identifier)
    }()

}
